/**
 * VFXSystem — reusable effect graph driven by data/system/vfx.json.
 * Subscribes to combat events; combat never spawns particles itself.
 * Every effect declares a budget; emitters degrade gracefully under load (LOD).
 */
export class VFXSystem {
  init(engine){
    this.e=engine; this.lib=engine.res.json('vfx');
    this.particles=[]; this.rings=[]; this.comics=[]; this.lines=[];
    this.aberration=0; this.flash=0; this.shake=0;
    this.quality=1;                 // 1 = full, lowered by PerfMonitor
    const bus=engine.bus;
    bus.on('combat:hit', e=>this.onHit(e));
    bus.on('combat:block', e=>this.spawn('sparks',{x:e.defender.x-e.defender.facing*28,y:e.defender.y-90,color:'#7fd4e8',count:5}));
    bus.on('combat:perfectGuard', e=>{
      this.comic(e.defender.x,e.defender.y-235,'PERFECT!','#57c8ff');
      this.ring(e.defender.x,e.defender.y-100,'#57c8ff');
      this.spawn('sparks',{x:e.defender.x,y:e.defender.y-100,color:'#57c8ff',count:10}); });
    bus.on('combat:counter', e=>{
      this.comic(e.defender.x,e.defender.y-245,'COUNTER!','#ff3fa4');
      this.speedLines(e.defender.x,e.defender.y-100); this.aberration=8; });
    bus.on('combat:burst', e=>{
      this.ring(e.fighter.x,e.fighter.y-100,'#57c8ff'); this.ring(e.fighter.x,e.fighter.y-100,'#ff3fa4');
      this.comic(e.fighter.x,e.fighter.y-235,'BURST!','#57c8ff'); this.shake=10; });
    bus.on('combat:flareBreak', e=>{
      this.ring(e.fighter.x,e.fighter.y-100,'#ff3fa4');
      this.comic(e.fighter.x,e.fighter.y-231,'FLARE BREAK','#ff3fa4'); engine.slowmo=8; });
    bus.on('combat:otg', e=>this.comic(e.defender.x,e.defender.y-225,'OTG','#8ee041'));
    bus.on('physics:wallBounce', e=>{ this.comic(e.fighter.x,e.fighter.y-225,'BOUNCE!','#57c8ff');
      this.spawn('sparks',{x:e.fighter.x,y:e.fighter.y-110,color:'#57c8ff',count:12}); this.shake=9; });
    bus.on('physics:groundBounce', e=>{ this.comic(e.fighter.x,e.fighter.y-209,'BOUNCE!','#ff3fa4'); this.shake=8; });
    bus.on('combat:ko', e=>{ this.comic(e.loser.x,e.loser.y-235,'K.O.!','#ffd24a');
      this.aberration=12; this.flash=10; this.shake=15; });
    bus.on('combat:shake', e=>{ this.shake=Math.max(this.shake,e.amount); });
    bus.on('combat:flash', e=>{ this.flash=Math.max(this.flash,e.frames); });
    bus.on('render:aberration', e=>{ this.aberration=Math.max(this.aberration,e.frames); });
    bus.on('vfx:play', e=>this.play(e.name, e.fighter, e.anchor));
  }
  onHit({attacker,defender,heavy}){
    this.spawn('sparks',{x:defender.x,y:defender.y-100,color:'#ffd24a',count:10});
    this.burst(defender.x,defender.y-100,attacker.accent);
    this.spawn('ink',{x:defender.x,y:defender.y-100});
    if(heavy){ const words=['CRACK!','SLAM!','BANG!','WHAM!'];
      this.comic(defender.x,defender.y-239,words[(Math.random()*words.length)|0],attacker.accent);
      this.speedLines(defender.x,defender.y-100); this.aberration=Math.max(this.aberration,5); }
  }
  play(name, f, anchorName){
    if(!f) return;
    const S=this.e.cfg.sprite, img=this.e.res.img(f.def.sprite.key);
    const fb=f.anchor(anchorName||'hand',S.displayHeight,img.width,img.height);
    const ax=(f.handX!==undefined)?f.handX:fb[0], ay=(f.handY!==undefined)?f.handY:fb[1];
    if(name==='greenTrail') this.spawn('greenTrail',{x:ax,y:ay});
    else if(name==='wireZap'){ const d=this.lib.wireZap;
      for(let i=0;i<d.count;i++) this.particles.push({x:ax+f.facing*(6+i*d.spacing),
        y:ay+(Math.random()-.5)*26,vx:0,vy:0,life:d.life,col:d.color,r:d.size,g:0}); }
    else if(name==='glitch') f.glitchT=Math.max(f.glitchT,12);
  }
  spawn(name, o){
    const d=this.lib[name]; if(!d) return;
    const n=Math.max(1, Math.round((o.count||d.count||1)*this.quality));
    if(this.particles.length > 900) return;   // hard performance budget
    for(let i=0;i<n;i++){
      const sp=Array.isArray(d.speed)? d.speed[0]+Math.random()*(d.speed[1]-d.speed[0]) : 3;
      const sz=Array.isArray(d.size)? d.size[0]+Math.random()*(d.size[1]-d.size[0]) : 2;
      const life=Array.isArray(d.life)? d.life[0]+Math.random()*(d.life[1]-d.life[0]) : d.life;
      const col=o.color || d.color || (d.colors ? d.colors[(Math.random()*d.colors.length)|0] : '#fff');
      this.particles.push({x:o.x+(name==='greenTrail'?(Math.random()-.5)*20:0),
        y:o.y+(name==='greenTrail'?(Math.random()-.5)*16:0),
        vx:(Math.random()-.5)*sp*2, vy:(Math.random()-.7)*sp*1.6,
        life, col, r:sz, g:d.gravity!=null?d.gravity:0.18});
    }
  }
  burst(x,y,col){ for(let i=0;i<8;i++){ const a=i/8*Math.PI*2;
    this.particles.push({x,y,vx:Math.cos(a)*4.5,vy:Math.sin(a)*4.5,life:12,col,r:2.2,g:0.18}); } }
  ring(x,y,col){ if(this.rings.length<this.lib.ringPulse.budget) this.rings.push({x,y,r:10,life:14,col}); }
  comic(x,y,str,col){ if(this.comics.length<this.lib.comicText.budget)
    this.comics.push({x,y,str,col,life:26,rot:(Math.random()-.5)*0.3}); }
  speedLines(x,y){ if(this.lines.length<this.lib.speedLines.budget) this.lines.push({x,y,life:8}); }
  update(){
    for(const p of this.particles){ p.x+=p.vx; p.y+=p.vy; p.vy+=p.g; p.life--; }
    this.particles=this.particles.filter(p=>p.life>0);
    for(const r of this.rings){ r.life--; r.r+=this.lib.ringPulse.growth; }
    this.rings=this.rings.filter(r=>r.life>0);
    for(const c of this.comics) c.life--;
    this.comics=this.comics.filter(c=>c.life>0);
    for(const l of this.lines) l.life--;
    this.lines=this.lines.filter(l=>l.life>0);
    this.shake*=0.86; if(this.flash>0)this.flash--; if(this.aberration>0)this.aberration--;
  }
  snapshot(){ return {}; }
  restore(){}
}
