/**
 * CameraSystem — cinematic director. Profiles live in data/system/cameras.json.
 * Modes: fight | cinematic | ko | intro | training | replay | spectator.
 * Frame data triggers camera events via the bus; camera knows nothing of combat rules.
 */
export class CameraSystem {
  init(engine){
    this.e=engine; this.p=engine.res.json('cameras'); this.cfg=engine.cfg;
    this.x=this.cfg.view.w/2; this.z=1; this.tx=this.x; this.tz=1;
    this.punch=0; this.mode='fight'; this.modeT=0; this.focus=null;
    engine.bus.on('combat:cameraEvent', ({kind,fighter,frames})=>this.play(kind,fighter,frames));
    engine.bus.on('combat:counter', ({defender})=>{ this.punch=Math.max(this.punch,this.p.counter.impulse); });
    engine.bus.on('combat:hit', ({heavy})=>{ if(heavy) this.punch=Math.max(this.punch,this.p.punch.impulse); });
    engine.bus.on('combat:ko', ({loser})=>{ this.play('ko',loser,150); });
  }
  play(kind, fighter, frames){
    if(kind==='punch'){ this.punch=Math.max(this.punch,this.p.punch.impulse); return; }
    this.mode=kind; this.modeT=frames||60; this.focus=fighter;
  }
  update(){
    const s=this.e.state; if(!s) return;
    const [a,b]=s.fighters, F=this.p.fight;
    let fx=(a.x+b.x)/2, dist=Math.abs(a.x-b.x);
    let tz=Math.max(F.minZoom, Math.min(F.maxZoom, F.distanceBias/(dist+F.distanceOffset)));
    if(this.modeT>0) this.modeT--; else if(this.mode!=='fight') this.mode='fight';
    if(this.mode==='cinematic' && this.focus){
      const C=this.p.cinematic; tz=C.zoom; fx=this.focus.x+this.focus.facing*C.facingOffset; }
    else if(this.mode==='ko' && this.focus){ tz=this.p.ko.zoom; fx=this.focus.x; }
    else if(this.mode==='training'){ tz=this.p.training.zoom; }
    if(Math.min(a.y,b.y) < this.cfg.physics.ground-150) tz=Math.min(tz,F.airZoomCap);
    this.tz=tz; this.tx=fx;
    this.z += (this.tz-this.z)*F.zoomLerp;
    this.x += (this.tx-this.x)*F.followLerp;
    this.punch *= this.p.punch.decay;
    const vw=this.cfg.view.w/(this.z*(1+this.punch));
    this.x=Math.max(vw/2, Math.min(this.cfg.view.w-vw/2, this.x));
  }
  view(){
    const V=this.cfg.view, z=this.z*(1+this.punch);
    const vw=V.w/z, vh=V.h/z;
    return {x:this.x-vw/2, y:V.h-vh, vw, vh, z};
  }
  toScreen(wx,wy){ const v=this.view(); return [(wx-v.x)*v.z, (wy-v.y)*v.z]; }
  snapshot(){ return {x:this.x,z:this.z,mode:this.mode,modeT:this.modeT}; }
  restore(s){ Object.assign(this,s); }
}
