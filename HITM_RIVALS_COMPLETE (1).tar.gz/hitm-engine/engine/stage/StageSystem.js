/**
 * StageSystem — stages are data (data/stages/<id>/stage.json).
 * Ambient layers (rain, lightning), grading, floor, reflections all declared.
 * Adding a stage = adding a folder. No engine code.
 */
export class StageSystem {
  init(engine){ this.e=engine; this.load(engine.res.json('stage')); }
  load(def){
    this.def=def; this.floor=def.floor;
    this.rain=[]; this.lightning=0; this.lightT=200;
    for(const a of def.ambient||[]){
      if(a.type==='rain'){ this.rainDef=a;
        for(let i=0;i<a.count;i++) this.rain.push({x:Math.random()*this.e.cfg.view.w,
          y:Math.random()*this.e.cfg.view.h, s:a.speedMin+Math.random()*(a.speedMax-a.speedMin),
          l:10+Math.random()*14}); }
      if(a.type==='lightning') this.lightDef=a;
    }
  }
  reflectionsEnabled(){ return !!(this.floor.reflection && this.floor.reflection.enabled); }
  update(){
    if(this.lightDef){
      if(--this.lightT<=0){ this.lightning=this.lightDef.frames;
        this.lightT=this.lightDef.minGap+Math.random()*(this.lightDef.maxGap-this.lightDef.minGap); }
      if(this.lightning>0) this.lightning--;
    }
  }
  drawBackground(c){
    const V=this.e.cfg.view, img=this.e.res.img(this.def.art);
    const sc=Math.max(V.w/img.width, V.h/img.height);
    const sw=img.width*sc, sh=img.height*sc;
    c.drawImage(img,(V.w-sw)/2,(V.h-sh)*this.def.parallax,sw,sh);
    const g=c.createLinearGradient(0,0,0,V.h);
    for(const s of this.def.grade) g.addColorStop(s.stop,s.color);
    c.fillStyle=g; c.fillRect(0,0,V.w,V.h);
    if(this.lightning>0){ c.fillStyle=this.lightDef.color.replace(/[\d.]+\)$/,
      (this.lightning/this.lightDef.frames*0.12)+')'); c.fillRect(0,0,V.w,V.h); }
    const G=this.def.ground;
    c.fillStyle=this.floor.stripColor; c.fillRect(0,G+6,V.w,V.h-G-6);
    c.fillStyle=this.floor.dashColor;
    for(let x=24;x<V.w;x+=84) c.fillRect(x,G+30,46,4);
    c.fillStyle='rgba(0,0,0,0.5)'; c.fillRect(0,G+6,V.w,3);
  }
  drawForeground(c){
    if(!this.rainDef) return;
    const V=this.e.cfg.view;
    c.strokeStyle=this.rainDef.color; c.lineWidth=1;
    for(const r of this.rain){ r.y+=r.s; r.x-=r.s*0.25;
      if(r.y>V.h){ r.y=-20; r.x=Math.random()*V.w; }
      c.beginPath(); c.moveTo(r.x,r.y); c.lineTo(r.x+r.l*0.25,r.y-r.l); c.stroke(); }
  }
}
