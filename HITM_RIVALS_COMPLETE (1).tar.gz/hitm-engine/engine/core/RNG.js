/**
 * RNG — seeded, deterministic (mulberry32).
 * ALL simulation randomness (AI decisions, opponent picks) must use this,
 * never Math.random, so replays and future rollback stay deterministic.
 * Cosmetic-only randomness (particle jitter) may use Math.random.
 */
export class RNG {
  constructor(seed=1){ this.seed(seed); }
  seed(s){ this._s = s >>> 0; }
  next(){
    let t = this._s += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  }
  range(a,b){ return a + this.next()*(b-a); }
  int(a,b){ return Math.floor(this.range(a,b+1)); }
  pick(arr){ return arr[Math.floor(this.next()*arr.length)]; }
  chance(p){ return this.next() < p; }
}
