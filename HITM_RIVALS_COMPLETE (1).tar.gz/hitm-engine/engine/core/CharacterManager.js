/**
 * CharacterManager — loads fighters from data folders and registers them
 * with every interested system. Adding a 30th fighter = adding a folder
 * and one roster entry in data/system/game.json. Zero engine code.
 */
export class CharacterManager {
  constructor(){ this.defs=new Map(); }
  async init(engine){
    this.e=engine;
    for(const id of engine.cfg.roster){
      const def = engine.res.json('char_'+id);
      const moves = engine.res.json('moves_'+id);
      const ai = engine.res.json('ai_'+id);
      this.defs.set(id, def);
      engine.sys('framedata').registerCharacter(id, moves);
      engine.sys('sprite').register(id, def);
      engine.sys('skeleton').register(id,
        engine.res.json('parts_'+id), engine.res.json('anim_'+id));
      engine.sys('ai').registerCharacter(id, ai);

      /* Alternate combat states (Volume 17). A fighter may declare additional
         move/AI tables under derived ids. They share the body — same sprite,
         same skeleton — and differ only in how that body is used. Not roster
         entries: they never appear on the select screen. */
      for(const sid of (def.states||[])){
        const key = id+'_'+sid;
        engine.sys('framedata').registerCharacter(key, engine.res.json('moves_'+key));
        engine.sys('ai').registerCharacter(key, engine.res.json('ai_'+key));
        engine.sys('sprite').register(key, def);
        engine.sys('skeleton').register(key,
          engine.res.json('parts_'+id), engine.res.json('anim_'+id));
        this.defs.set(key, def);
      }
    }
  }
  def(id){ return this.defs.get(id); }
  all(){ return [...this.defs.values()]; }
}
