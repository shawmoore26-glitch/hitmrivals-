/**
 * SaveSystem — settings + progression persistence.
 * Adapter order: window.storage (Claude artifacts) -> localStorage -> memory.
 */
export class SaveSystem {
  constructor(key='hitm-rivals-engine'){ this.key = key; this._mem = null; }
  async load(){
    try{ if(typeof window!=='undefined' && window.storage){
      const r = await window.storage.get(this.key); return r?JSON.parse(r.value):null; } }catch(e){}
    try{ const v = localStorage.getItem(this.key); if(v) return JSON.parse(v); }catch(e){}
    return this._mem;
  }
  async save(obj){
    this._mem = obj;
    const s = JSON.stringify(obj);
    try{ if(typeof window!=='undefined' && window.storage){ await window.storage.set(this.key,s); return; } }catch(e){}
    try{ localStorage.setItem(this.key,s); }catch(e){}
  }
}
