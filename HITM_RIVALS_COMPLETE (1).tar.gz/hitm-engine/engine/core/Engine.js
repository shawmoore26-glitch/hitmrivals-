import { EventBus } from './EventBus.js';
import { RNG } from './RNG.js';
import { Resources } from './Resources.js';
/**
 * Engine — system registry + fixed-timestep loop.
 * Owns: bus, rng, resources, config (data/system/game.json), shared match state.
 * Systems implement optional hooks:
 *   init(engine) · update() [sim, fixed 60Hz] · render() [every rAF] ·
 *   snapshot():obj · restore(obj) · onMatchStart() · onMatchEnd()
 * Update order is the registration order — declared once in main.js.
 */
export class Engine {
  constructor(canvas){
    this.canvas = canvas;
    this.bus = new EventBus();
    this.rng = new RNG(1);
    this.res = new Resources();
    this.systems = new Map();
    this.cfg = null;          // data/system/game.json
    this.state = null;        // shared match state, owned by CombatSystem
    this.running = false;
    this.paused = false;      // debug pause (frame advance)
    this.stepOnce = false;
    this.hitstop = 0;         // impact freeze frames (render continues)
    this.slowmo = 0;          // frames of 1/3-speed sim
    this._acc = 0; this._last = 0; this._frame = 0;
  }
  register(name, sys){ this.systems.set(name, sys); sys.engine = this; return sys; }
  sys(name){ return this.systems.get(name); }
  async init(){
    for(const s of this.systems.values()) if(s.init) await s.init(this);
  }
  start(){
    if(this.running) return;
    this.running = true; this._last = performance.now();
    requestAnimationFrame(t=>this._tick(t));
  }
  _tick(t){
    if(!this.running) return;
    requestAnimationFrame(tt=>this._tick(tt));
    const dt = Math.min(50, t - this._last); this._last = t;
    this._acc += dt;
    const STEP = 1000/60;
    while(this._acc >= STEP){
      this._acc -= STEP;
      this._frame++;
      if(this.paused && !this.stepOnce) break;
      this.stepOnce = false;
      if(this.hitstop > 0){ this.hitstop--; break; }
      if(this.slowmo > 0){ this.slowmo--; if(this._frame % 3 !== 0) break; }
      for(const s of this.systems.values()) if(s.update) s.update();
      this.bus.emit('engine:postUpdate', this._frame);
    }
    for(const s of this.systems.values()) if(s.render) s.render();
  }
  get frame(){ return this._frame; }
  snapshot(){
    const snap = {};
    for(const [n,s] of this.systems) if(s.snapshot) snap[n] = s.snapshot();
    return JSON.parse(JSON.stringify(snap));
  }
  restore(snap){
    for(const [n,s] of this.systems) if(s.restore && snap[n]) s.restore(JSON.parse(JSON.stringify(snap[n])));
  }
}
