/**
 * Resources — async loader for images and JSON.
 * In a dist (single-file) build, window.__EMBEDDED__ provides
 * {images:{key:dataURI}, json:{key:object}} and no network is used.
 */
export class Resources {
  constructor(){ this.images = {}; this.jsons = {}; }
  async load(manifest){
    const emb = (typeof window!=='undefined' && window.__EMBEDDED__) || null;
    const imgJobs = Object.entries(manifest.images||{}).map(([k,url])=>
      this._img(emb && emb.images[k] ? emb.images[k] : url).then(im=>{this.images[k]=im;}));
    const jsonJobs = Object.entries(manifest.json||{}).map(async ([k,url])=>{
      if(emb && emb.json[k]!==undefined){ this.jsons[k]=emb.json[k]; return; }
      const r = await fetch(url); this.jsons[k] = await r.json();});
    await Promise.all([...imgJobs, ...jsonJobs]);
  }
  _img(src){ return new Promise((res,rej)=>{
    const im=new Image(); im.onload=()=>res(im); im.onerror=rej; im.src=src;});}
  img(k){ return this.images[k]; }
  json(k){ return this.jsons[k]; }
}
