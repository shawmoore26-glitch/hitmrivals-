import { Engine } from './Engine.js';
import { CharacterManager } from './CharacterManager.js';
import { InputSystem } from '../input/InputSystem.js';
import { FrameDataSystem } from '../combat/FrameData.js';
import { PhysicsSystem } from '../physics/PhysicsSystem.js';
import { CombatSystem } from '../combat/CombatSystem.js';
import { SpriteSystem } from '../render/SpriteSystem.js';
import { SkeletonSystem } from '../render/SkeletonSystem.js';
import { AnimationSystem } from '../render/AnimationSystem.js';
import { CameraSystem } from '../camera/CameraSystem.js';
import { VFXSystem } from '../vfx/VFXSystem.js';
import { AudioSystem } from '../audio/AudioSystem.js';
import { AISystem } from '../ai/AISystem.js';
import { StageSystem } from '../stage/StageSystem.js';
import { UISystem } from '../ui/UISystem.js';
import { Renderer } from '../render/Renderer.js';
import { ReplaySystem } from '../replay/ReplaySystem.js';
import { DebugSystem } from '../debug/DebugSystem.js';

/**
 * Boot — the ONLY place system wiring is declared.
 * Update order is registration order. Render is separate.
 */
export async function boot(canvas, manifest){
  const engine = new Engine(canvas);
  await engine.res.load(manifest);
  engine.cfg = engine.res.json('game');

  engine.register('input',     new InputSystem());
  engine.register('framedata', new FrameDataSystem());
  engine.register('physics',   new PhysicsSystem());
  engine.register('sprite',    new SpriteSystem());
  engine.register('skeleton',  new SkeletonSystem());
  engine.register('animation', new AnimationSystem());
  engine.register('ai',        new AISystem());
  engine.register('combat',    new CombatSystem());
  engine.register('stage',     new StageSystem());
  engine.register('camera',    new CameraSystem());
  engine.register('vfx',       new VFXSystem());
  engine.register('audio',     new AudioSystem());
  engine.register('ui',        new UISystem());
  engine.register('replay',    new ReplaySystem());
  engine.register('debug',     new DebugSystem());
  engine.register('renderer',  new Renderer());
  engine.register('characters',new CharacterManager());

  await engine.init();

  /* projectile spawn is the one cross-system message combat can't own alone */
  engine.bus.on('combat:spawnProjectile', p=>{
    engine.sys('combat').addProjectile({
      owner:p.owner, def:p.def, kind:p.kind, x:p.x, y:p.y, vx:p.vx, vy:p.vy,
      damage:p.damage, life:p.life, cosmetic:p.cosmetic, spin:0, grav:p.def.gravity||0 });
  });
  return engine;
}
