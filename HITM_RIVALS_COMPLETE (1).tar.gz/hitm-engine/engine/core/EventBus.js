/**
 * EventBus — the only communication channel between systems.
 * Systems never call each other directly; they emit and subscribe.
 * Contract: emit() is synchronous and re-entrant safe (snapshot of listeners).
 */
export class EventBus {
  constructor(){ this._l = new Map(); }
  on(type, fn){
    if(!this._l.has(type)) this._l.set(type, new Set());
    this._l.get(type).add(fn);
    return () => this.off(type, fn);
  }
  off(type, fn){ const s = this._l.get(type); if(s) s.delete(fn); }
  emit(type, payload){
    const s = this._l.get(type);
    if(!s) return;
    for(const fn of [...s]) fn(payload);
  }
}
