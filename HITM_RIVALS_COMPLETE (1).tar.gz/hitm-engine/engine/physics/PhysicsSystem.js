/**
 * PhysicsSystem — gravity, ground, walls, wall/ground bounce resolution.
 * Pure: mutates fighter bodies only; announces bounces on the bus so
 * VFX/camera/audio can react without physics knowing they exist.
 */
export class PhysicsSystem {
  init(engine){ this.e = engine; this.cfg = engine.cfg.physics; this.combat = engine.cfg.combat; }
  integrate(f){
    const P=this.cfg;
    f.vy += P.gravity; f.y += f.vy; f.x += f.vx;
    if(f.y > P.ground){ f.y = P.ground; f.vy = 0; return 'land'; }
    return null;
  }
  clampX(f){ f.x = Math.max(this.cfg.wallL, Math.min(this.cfg.wallR, f.x)); }
  atWall(f){ return f.x <= this.cfg.wallL + 2 || f.x >= this.cfg.wallR - 2; }
  tryWallBounce(f){
    if(f.wallUsed || !this.atWall(f) || Math.abs(f.vx) < this.combat.wallBounceMinVX) return false;
    f.wallUsed = true; f.vx = -f.vx*0.55; f.vy = -7.5;
    f.stun = Math.max(f.stun, 22);
    this.e.bus.emit('physics:wallBounce', {fighter:f});
    return true;
  }
  tryGroundBounce(f){
    if(!f.spiked || f.groundUsed || f.vy <= 5) return false;
    f.groundUsed = true; f.spiked = false; f.y = this.cfg.ground; f.vy = -6.5;
    f.stun = Math.max(f.stun, 20);
    this.e.bus.emit('physics:groundBounce', {fighter:f});
    return true;
  }
}
