/**
 * DebugSystem — developer tooling shipped inside the engine (not side scripts).
 * F1 overlay · F2 hitboxes · F3 pause · F4 frame advance · F5 frame-data table
 * Also hosts the PerfMonitor that drives VFX LOD.
 */
export class DebugSystem {
  init(engine){
    this.e=engine; this.overlay=false; this.table=false;
    this.samples=[]; this.fps=60;
    addEventListener('keydown',e=>{
      const k=e.key.toLowerCase();
      if(k==='f1'){ this.overlay=!this.overlay; e.preventDefault(); }
      if(k==='f2'){ engine.bus.emit('input:rawKey','h'); e.preventDefault(); }
      if(k==='f3'){ engine.paused=!engine.paused; e.preventDefault(); }
      if(k==='f4'){ engine.stepOnce=true; e.preventDefault(); }
      if(k==='f5'){ this.table=!this.table; e.preventDefault(); }
    });
    this._last=performance.now();
  }
  update(){
    const now=performance.now(); const dt=now-this._last; this._last=now;
    this.samples.push(dt); if(this.samples.length>60) this.samples.shift();
    const avg=this.samples.reduce((a,b)=>a+b,0)/this.samples.length;
    this.fps=Math.round(1000/Math.max(1,avg));
    const vfx=this.e.sys('vfx');
    if(vfx) vfx.quality = this.fps<45 ? 0.5 : (this.fps<55 ? 0.75 : 1);   // LOD
  }
  render(){
    if(!this.overlay && !this.table) return;
    const c=this.e.canvas.getContext('2d'), s=this.e.state;
    c.save(); c.font='11px monospace'; c.textAlign='left';
    if(this.overlay && s){
      const lines=[
        'FPS '+this.fps+'  frame '+this.e.frame+'  particles '+this.e.sys('vfx').particles.length,
        'hitstop '+this.e.hitstop+'  slowmo '+this.e.slowmo+'  cam z '+this.e.sys('camera').z.toFixed(2),
        ...s.fighters.map(f=>`${f.id.padEnd(9)} ${f.state.padEnd(8)} hp:${String(f.hp).padStart(4)} `+
          `mtr:${String(Math.round(f.meter)).padStart(3)} mv:${(f.move?f.move.id+'@'+f.move.t:'-').padEnd(14)} `+
          `combo:${f.combo} inv:${f.invulnT}`)
      ];
      c.fillStyle='rgba(8,5,20,0.8)'; c.fillRect(8,110,470,14*lines.length+10);
      c.fillStyle='#8ee041'; lines.forEach((l,i)=>c.fillText(l,14,126+i*14));
    }
    if(this.table && s){
      const fd=this.e.sys('framedata'), rows=fd.table(s.fighters[0].id);
      c.fillStyle='rgba(8,5,20,0.88)'; c.fillRect(8,200,470,14*(rows.length+2)+10);
      c.fillStyle='#57c8ff'; c.fillText('MOVE          START ACT REC TOT  DMG  ONBLK',14,216);
      c.fillStyle='#efe9dc';
      rows.forEach((r,i)=>c.fillText(
        `${(r.name||r.id).slice(0,13).padEnd(13)} ${String(r.startup).padStart(4)} `+
        `${String(r.active).padStart(3)} ${String(r.recovery).padStart(3)} ${String(r.total).padStart(4)} `+
        `${String(r.damage).padStart(4)} ${String(r.onBlock).padStart(5)}`, 14, 232+i*14));
    }
    c.restore();
  }
}
