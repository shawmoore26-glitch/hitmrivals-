/**
 * UISystem — HUD + screens. Reads state, emits intents on the bus.
 * Health bars use damage-ghosting; portraits are sampled from character art.
 */
export class UISystem {
  init(engine){
    this.e=engine;
    this.announce=null; this.announceT=0;
    engine.bus.on('combat:roundStart',({round})=>{ this.announce='ROUND '+round; this.announceT=120; });
    engine.bus.on('combat:fightStart',()=>{ this.announce='FIGHT'; this.announceT=44; });
    engine.bus.on('combat:blockbuster',({move})=>{ this.banner=move.name; this.bannerT=50; });
  }
  update(){ if(this.announceT>0)this.announceT--; if(this.bannerT>0)this.bannerT--; }
  draw(c){
    const s=this.e.state; if(!s) return;
    const V=this.e.cfg.view, M=this.e.cfg.meter, C=this.e.cfg.combat;
    const [p1,p2]=s.fighters;
    this._portrait(c,p1,37); this._portrait(c,p2,V.w-37);
    c.textAlign='left'; c.font='900 15px "Arial Narrow", Arial'; c.fillStyle='#efe9dc';
    c.fillText(p1.def.name.toUpperCase(),62,30);
    c.font='700 9px Arial'; c.fillStyle=p1.accent; c.fillText(p1.def.faction,62,42);
    c.textAlign='right'; c.font='900 15px "Arial Narrow", Arial'; c.fillStyle='#efe9dc';
    c.fillText(p2.def.name.toUpperCase()+(p2.isAI?' \u00b7 CPU':''),V.w-62,30);
    c.font='700 9px Arial'; c.fillStyle=p2.accent; c.fillText(p2.def.faction,V.w-62,42);
    this._health(c,p1,62,374,false); this._health(c,p2,V.w-62-374,374,true);
    this._bar(c,62,68,250,7,p1.meter/M.max,p1.meter>=M.bbCost?'#ff3fa4':'#a03f7a',false);
    this._bar(c,V.w-62-250,68,250,7,p2.meter/M.max,p2.meter>=M.bbCost?'#ff3fa4':'#a03f7a',true);
    c.font='700 9px Arial'; c.textAlign='left';
    c.fillStyle=p1.meter>=M.bbCost?'#ff3fa4':'#8f88a8';
    c.fillText(p1.meter>=M.bbCost?'FLARE READY':(p1.meter>=M.breakCost?'BREAK READY':'FLARE'),62,86);
    c.textAlign='right'; c.fillStyle=p2.meter>=M.bbCost?'#ff3fa4':'#8f88a8'; c.fillText('FLARE',V.w-62,86);
    for(let i=0;i<this.e.cfg.rounds.toWin;i++){
      this._pip(c,68+i*16,96,i<p1.rounds); this._pip(c,V.w-68-i*16,96,i<p2.rounds); }
    c.textAlign='center'; c.font='900 30px "Arial Narrow", Arial'; c.fillStyle='#efe9dc';
    c.fillText(String(Math.max(0,Math.ceil(s.timer/60))),V.w/2,56);
    c.font='700 9px Arial'; c.fillStyle='#8f88a8'; c.fillText('ROUND '+s.round,V.w/2,72);
    if(p1.combo>1){ c.textAlign='left'; c.font='900 27px "Arial Narrow", Arial';
      c.fillStyle='#ffd24a'; c.fillText(p1.combo+' HITS',46,140);
      c.font='700 9px Arial'; c.fillStyle='#c9d1dc';
      c.fillText('DMG SCALE '+Math.round(Math.max(C.scaleMin,1-C.scaleStep*(p1.combo-1))*100)+'%',46,154); }
    if(p2.combo>1){ c.textAlign='right'; c.font='900 27px "Arial Narrow", Arial';
      c.fillStyle='#c22b2b'; c.fillText(p2.combo+' HITS',V.w-46,140); }
    if(this.announceT>0 && s.phase==='roundIntro'||this.announceT>0&&this.announce==='FIGHT'){
      const k=this.announceT>96?1+(this.announceT-96)/24*0.6:1;
      c.save(); c.translate(V.w/2,V.h/2); c.scale(k,k); c.textAlign='center';
      c.font='900 46px "Arial Narrow", Arial'; c.lineWidth=8; c.strokeStyle='#0a0618';
      c.strokeText(this.announce,0,0); c.fillStyle='#efe9dc'; c.fillText(this.announce,0,0); c.restore(); }
    if(this.bannerT>0){ c.save(); c.textAlign='center'; c.globalAlpha=Math.min(1,this.bannerT/12);
      c.font='900 26px "Arial Narrow", Arial'; c.lineWidth=6; c.strokeStyle='#0a0618';
      c.strokeText(this.banner,V.w/2,190); c.fillStyle='#ff3fa4'; c.fillText(this.banner,V.w/2,190);
      c.restore(); }
  }
  _bar(c,x,y,w,h,pct,col,rtl){
    c.fillStyle='rgba(0,0,0,0.35)'; c.fillRect(x,y,w,h);
    c.fillStyle=col; const fw=w*Math.max(0,pct); c.fillRect(rtl?x+w-fw:x,y,fw,h);
    c.strokeStyle='rgba(239,233,220,0.4)'; c.lineWidth=1; c.strokeRect(x+.5,y+.5,w-1,h-1);
  }
  _health(c,f,x,w,rtl){
    f.dispHp += (f.hp-f.dispHp)*0.06; if(f.dispHp<f.hp) f.dispHp=f.hp;
    const gp=f.dispHp/f.maxhp, hp=f.hp/f.maxhp;
    c.fillStyle='rgba(0,0,0,0.35)'; c.fillRect(x,48,w,15);
    c.fillStyle='rgba(194,43,43,0.75)'; const gw=w*gp; c.fillRect(rtl?x+w-gw:x,48,gw,15);
    c.fillStyle=hp>0.3?'#d4af37':'#c22b2b'; const fw=w*hp; c.fillRect(rtl?x+w-fw:x,48,fw,15);
    c.strokeStyle='rgba(239,233,220,0.4)'; c.lineWidth=1; c.strokeRect(x+.5,48.5,w-1,14);
  }
  _portrait(c,f,x){
    const sh=this.e.sys('sprite').sheet(f.id);
    const size=Math.min(sh.w, sh.h*0.35);
    c.save(); c.beginPath(); c.arc(x,55,17,0,Math.PI*2); c.clip();
    c.fillStyle='#180f30'; c.fillRect(x-17,38,34,34);
    c.drawImage(sh.img,(sh.w-size)/2,0,size,size,x-17,38,34,34); c.restore();
    c.strokeStyle=f.accent; c.lineWidth=2; c.beginPath(); c.arc(x,55,17,0,Math.PI*2); c.stroke();
  }
  _pip(c,x,y,filled){
    c.beginPath(); c.arc(x,y,5,0,Math.PI*2);
    if(filled){ c.fillStyle='#ffd24a'; c.fill(); }
    else { c.strokeStyle='rgba(239,233,220,0.45)'; c.lineWidth=1.4; c.stroke(); }
  }
}
