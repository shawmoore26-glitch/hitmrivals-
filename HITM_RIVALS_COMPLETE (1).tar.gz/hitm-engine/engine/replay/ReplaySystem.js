/**
 * ReplaySystem — deterministic record/playback from (seed + inputs).
 * Also the rollback substrate: ring buffer of state snapshots lets us
 * rewind N frames and re-simulate when a remote input arrives late.
 */
export class ReplaySystem {
  init(engine){
    this.e=engine; this.recording=null; this.playing=null;
    this.ring=[]; this.ringSize=12;      // rollback window (frames)
  }
  startRecording(meta){
    this.recording={seed:this.e.rng._s, meta, inputs:[], startFrame:this.e.frame};
  }
  update(){
    const inp=this.e.sys('input');
    if(this.recording && inp.history[this.e.frame])
      this.recording.inputs.push(inp.history[this.e.frame]);
    this.ring.push({frame:this.e.frame, snap:this.e.snapshot()});
    if(this.ring.length>this.ringSize) this.ring.shift();
  }
  stopRecording(){ const r=this.recording; this.recording=null; return r; }
  /** Rollback: rewind to `frame` and re-simulate forward. */
  rollbackTo(frame){
    const entry=this.ring.find(r=>r.frame===frame);
    if(!entry) return false;
    this.e.restore(entry.snap);
    return true;
  }
  export(){ return JSON.stringify(this.recording); }
  import(json){ this.playing=JSON.parse(json); this.e.rng.seed(this.playing.seed);
    this.e.sys('input').playback=this.playing.inputs; }
}
