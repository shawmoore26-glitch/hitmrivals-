/**
 * SkeletonSystem — cutout skeletal animation.
 *
 * The simulation owns frames; this system only POSES. Given (character, clip,
 * frame) it resolves every bone's world transform by walking the hierarchy and
 * returns a flat draw list. It never advances its own clock, so a rollback or a
 * frame-advance step re-poses exactly, with no drift between visuals and hitboxes.
 *
 * Data in:  data/characters/<id>/parts.json  (atlas frames, pivots, bone tree)
 *           data/characters/<id>/anim.json   (integer-frame keyframe tracks)
 */
const DEG = Math.PI/180;

export class SkeletonSystem {
  constructor(){ this.rigs = new Map(); }
  init(engine){ this.e = engine; }

  register(charId, parts, anim){
    if(!this._follow) this._follow = new Map();
    const bones = {}, order = [];
    for(const b of parts.bones){ bones[b.name] = b; order.push(b.name); }
    this.rigs.set(charId, {
      parts: parts.parts, bones, order, drawOrder: parts.drawOrder,
      sourceSize: parts.sourceSize, atlasKey: parts.atlas,
      handBone: parts.handBone, handPoint: parts.handPoint, clips: anim
    });
  }
  rig(charId){ return this.rigs.get(charId); }
  clip(charId, name){ const r=this.rigs.get(charId); return r && r.clips[name] ? r.clips[name] : null; }

  /** Sample one track at a (possibly fractional) frame. Linear between integer keys. */
  _sample(track, f){
    if(!track || !track.length) return [0,0,0];
    if(f <= track[0][0]) return [track[0][1], track[0][2], track[0][3]];
    const last = track[track.length-1];
    if(f >= last[0]) return [last[1], last[2], last[3]];
    for(let i=0;i<track.length-1;i++){
      const a=track[i], b=track[i+1];
      if(f>=a[0] && f<=b[0]){
        const t = (b[0]===a[0]) ? 0 : (f-a[0])/(b[0]-a[0]);
        const s = t*t*(3-2*t);                       // smoothstep: eases contacts
        return [a[1]+(b[1]-a[1])*s, a[2]+(b[2]-a[2])*s, a[3]+(b[3]-a[3])*s];
      }
    }
    return [last[1], last[2], last[3]];
  }

  /* ── SECONDARY MOTION (Phase 4) ──────────────────────────────────────────
     A bone flagged 'follow' in rig.json is not animated. It is DRAGGED.
     Each frame it chases its parent's rotation through a spring/damper, so it
     arrives late and keeps moving after the parent stops. Volume 5's sentence
     law — "coat, dreads, chain travel a full beat after he stops" — is this
     function, applied to every clip of every fighter, forever.

     Spring constants are DNA-derived (rig_compiler): a heavy, inelastic body
     produces a stiff, well-damped coat; a light chaotic one produces a coat
     that never quite settles.

     GAMEPLAY SAFETY: this runs in the RENDER layer only. It reads no combat
     state and writes none. Hitboxes, frame data and physics are untouched.  */
  _secondary(charId, fighterKey, localPose, dt){
    const r = this.rigs.get(charId); if(!r) return localPose;
    let st = this._follow.get(fighterKey);
    if(!st){ st = {}; this._follow.set(fighterKey, st); }
    for(const name of r.order){
      const b = r.bones[name]; const f = b && b.follow; if(!f) continue;
      const parentRot = (localPose[b.parent] || {rot:0}).rot || 0;
      const target = parentRot * (f.lagBeats || 1);
      let s0 = st[name]; if(!s0){ s0 = st[name] = {a:target, v:0}; }
      // spring toward the parent's angle, damped
      s0.v += (target - s0.a) * (f.stiffness || 0.2);
      if(f.gravity) s0.v += f.gravity * 0.6 * Math.sin((s0.a) * Math.PI/180);
      s0.v *= (f.damping || 0.7);
      s0.a += s0.v * (dt || 1);
      const m = f.maxAngle || 30;
      if(s0.a >  m){ s0.a =  m; s0.v *= -0.35; }
      if(s0.a < -m){ s0.a = -m; s0.v *= -0.35; }
      localPose[name] = { rot: s0.a - parentRot, dx:0, dy:0 };
    }
    return localPose;
  }

  /** Clear follow state — call on round reset so replays stay deterministic. */
  resetFollow(fighterKey){ this._follow.delete(fighterKey); }

  /** Local pose (rotation + offset) for every bone at this clip frame. */
  pose(charId, clipName, frame, blend){
    const r = this.rigs.get(charId);
    const clip = r.clips[clipName] || r.clips.idle;
    const f = clip.loop ? (frame % clip.len) : Math.min(frame, clip.len);
    const out = {};
    for(const name of r.order){
      const s = this._sample(clip.tracks[name], f);
      out[name] = {rot:s[0], dx:s[1], dy:s[2]};
    }
    if(blend && blend.from && blend.t < 1){
      const prev = this.pose(charId, blend.from, blend.frame, null);
      const k = blend.t*blend.t*(3-2*blend.t);
      for(const name of r.order){
        const a=prev[name], b=out[name];
        out[name] = {rot:a.rot+(b.rot-a.rot)*k, dx:a.dx+(b.dx-a.dx)*k, dy:a.dy+(b.dy-a.dy)*k};
      }
    }
    return out;
  }

  /**
   * Resolve world transforms and return a back-to-front draw list.
   * Coordinates are in fighter-local space: origin at the feet, +y downward.
   */
  build(charId, localPose, displayH){
    const r = this.rigs.get(charId);
    const [SW, SH] = r.sourceSize;
    const spriteW = SW/SH*displayH;
    const world = {};
    const partSize = pName => {
      const m = r.parts[pName];
      return [m.normW*spriteW, m.normH*displayH];
    };
    for(const name of r.order){
      const b = r.bones[name], lp = localPose[name] || {rot:0,dx:0,dy:0};
      if(!b.parent){
        world[name] = { x:(b.at[0]-0.5)*spriteW + lp.dx*displayH,
                        y:(b.at[1]-1.0)*displayH + lp.dy*displayH,
                        rot: lp.rot*DEG };
        continue;
      }
      const p = world[b.parent], pb = r.bones[b.parent];
      let ox, oy;
      if(!pb.part){
        // parent is a control bone: 'at' is in source-sprite normalized space
        ox = (b.at[0]-0.5)*spriteW - ((pb.at[0]-0.5)*spriteW);
        oy = (b.at[1]-1.0)*displayH - ((pb.at[1]-1.0)*displayH);
      } else {
        const m = r.parts[pb.part], [pw,ph] = partSize(pb.part);
        ox = (b.at[0]-m.pivot[0])*pw;
        oy = (b.at[1]-m.pivot[1])*ph;
      }
      const c = Math.cos(p.rot), s = Math.sin(p.rot);
      world[name] = {
        x: p.x + ox*c - oy*s + lp.dx*displayH,
        y: p.y + ox*s + oy*c + lp.dy*displayH,
        rot: p.rot + lp.rot*DEG
      };
    }
    const list = [];
    for(const pName of r.drawOrder){
      const boneName = r.order.find(n => r.bones[n].part === pName);
      if(!boneName || !r.parts[pName]) continue;
      const m = r.parts[pName], w = world[boneName], [pw,ph] = partSize(pName);
      list.push({ frame:m.frame, x:w.x, y:w.y, rot:w.rot, w:pw, h:ph,
                  px:m.pivot[0]*pw, py:m.pivot[1]*ph });
    }
    return {list, world};
  }

  /** World-space point of the character's signature hand (VFX + projectile origin). */
  handAnchor(charId, built, displayH){
    const r = this.rigs.get(charId);
    if(!r.handBone) return {x:0,y:-displayH*0.5};
    const b = r.bones[r.handBone];
    const w = built.world[r.handBone];
    if(!w || !b || !b.part) return {x:0,y:-displayH*0.5};
    const [SW,SH]=r.sourceSize, spriteW=SW/SH*displayH;
    const m=r.parts[b.part], pw=m.normW*spriteW, ph=m.normH*displayH;
    const ox=(r.handPoint[0]-m.pivot[0])*pw, oy=(r.handPoint[1]-m.pivot[1])*ph;
    const c=Math.cos(w.rot), s=Math.sin(w.rot);
    return {x:w.x+ox*c-oy*s, y:w.y+ox*s+oy*c};
  }
}
