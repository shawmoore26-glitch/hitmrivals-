/**
 * SpriteSystem — sprite atlas + animation clip registry.
 * TODAY: one still per character (puppet mode).
 * TOMORROW: drop an atlas + frames.json per character and clips resolve to
 * real frames with zero changes elsewhere. Layer support (body/hair/cape/weapon/fx)
 * is declared here so multi-layer characters need no engine rewrite.
 */
export class SpriteSystem {
  constructor(){ this.sheets=new Map(); }  // charId -> {img, tints, atlas, clips}
  init(engine){ this.e=engine; }
  register(charId, def){
    const img=this.e.res.img(def.sprite.key);
    const mk=fill=>{ const c=document.createElement('canvas'); c.width=img.width; c.height=img.height;
      const cc=c.getContext('2d'); cc.drawImage(img,0,0);
      cc.globalCompositeOperation='source-in'; cc.fillStyle=fill; cc.fillRect(0,0,img.width,img.height); return c; };
    this.sheets.set(charId,{
      img, w:img.width, h:img.height,
      white:mk('#ffffff'), sil:mk(def.accent),
      atlas:def.sprite.atlas||null,          // future: {image, frames:{name:[x,y,w,h]}}
      clips:def.sprite.clips||null,          // future: {idle:{frames:[..],fps,loop}, ...}
      layers:def.sprite.layers||['body']     // future: hair/cape/weapon/fx layers
    });
  }
  sheet(charId){ return this.sheets.get(charId); }
  /**
   * Resolve the source rect for a state/frame.
   * Puppet mode returns the whole image; atlas mode returns the clip frame.
   */
  frame(charId, clipName, t){
    const s=this.sheets.get(charId);
    if(!s.clips || !s.clips[clipName]) return {img:s.img, sx:0, sy:0, sw:s.w, sh:s.h};
    const clip=s.clips[clipName];
    const idx=clip.loop ? Math.floor(t/ (60/clip.fps)) % clip.frames.length
                        : Math.min(clip.frames.length-1, Math.floor(t/(60/clip.fps)));
    const [sx,sy,sw,sh]=s.atlas.frames[clip.frames[idx]];
    return {img:this.e.res.img(s.atlas.image), sx, sy, sw, sh};
  }
}
