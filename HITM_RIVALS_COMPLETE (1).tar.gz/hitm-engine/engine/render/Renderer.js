import { STATE } from '../combat/Fighter.js';
/**
 * Renderer — two-pass pipeline.
 *  pass 1: world buffer (stage, reflections, fighters, projectiles, particles)
 *  pass 2: camera samples the buffer to screen, applies chromatic aberration,
 *          screen shake, comic/speed-line overlays, then UI draws on top.
 * Reads only state; mutates nothing. All poses come from AnimationSystem.
 */
export class Renderer {
  init(engine){
    this.e=engine; const V=engine.cfg.view;
    this.main=engine.canvas.getContext('2d');
    this.buf=document.createElement('canvas'); this.buf.width=V.w; this.buf.height=V.h;
    this.bctx=this.buf.getContext('2d');
    this.showBoxes=false;
    engine.bus.on('input:rawKey', k=>{ if(k==='h') this.showBoxes=!this.showBoxes; });
  }
  render(){
    const s=this.e.state; if(!s) return;
    const V=this.e.cfg.view, c=this.bctx;
    const stage=this.e.sys('stage'), vfx=this.e.sys('vfx'),
          cam=this.e.sys('camera'), anim=this.e.sys('animation'),
          spr=this.e.sys('sprite'), ui=this.e.sys('ui');
    /* ---- world pass ---- */
    c.setTransform(1,0,0,1,0,0);
    stage.drawBackground(c);
    if(stage.reflectionsEnabled()) for(const f of s.fighters) this.drawFighter(c,f,true);
    const order=[...s.fighters].sort((a,b)=>a.y-b.y);
    for(const f of order) this.drawFighter(c,f,false);
    for(const p of s.projectiles) this.drawProjectile(c,p);
    this.drawRings(c,vfx); this.drawParticles(c,vfx);
    stage.drawForeground(c);
    /* ---- screen pass ---- */
    const m=this.main; m.setTransform(1,0,0,1,0,0);
    m.fillStyle='#0a0618'; m.fillRect(0,0,V.w,V.h);
    let ox=0,oy=0;
    if(vfx.shake>0.4){ ox=(Math.random()-.5)*vfx.shake; oy=(Math.random()-.5)*vfx.shake; }
    const v=cam.view();
    if(vfx.aberration>0){
      const a=vfx.aberration; m.globalAlpha=0.5;
      m.drawImage(this.buf,v.x,v.y,v.vw,v.vh,ox-a*0.6,oy,V.w,V.h);
      m.drawImage(this.buf,v.x,v.y,v.vw,v.vh,ox+a*0.6,oy,V.w,V.h);
      m.globalAlpha=1;
    }
    m.drawImage(this.buf,v.x,v.y,v.vw,v.vh,ox,oy,V.w,V.h);
    this.drawSpeedLines(m,vfx,cam); this.drawComics(m,vfx,cam);
    ui.draw(m);
    if(vfx.flash>0){ m.fillStyle='rgba(239,233,220,'+(vfx.flash/10*0.7)+')'; m.fillRect(0,0,V.w,V.h); }
  }
  drawFighter(c,f,reflection){
    const S=this.e.cfg.sprite, sk=this.e.sys('skeleton'), anim=this.e.sys('animation');
    const rig=sk.rig(f.id);
    const t=anim.playback(f);
    const pose=sk.pose(f.id, t.clip, t.frame,
      t.blend<1 ? {from:t.prev, frame:t.prevFrame, t:t.blend} : null);
    /* Phase 4: drag the follow bones after the animated ones. Render-only. */
    sk._secondary(f.id, f.slot!==undefined?f.slot:(f.baseId||f.id), pose, 1);
    const built=sk.build(f.id, pose, S.displayHeight);
    const atlas=this.e.res.img(rig.atlasKey);
    const G=this.e.cfg.physics.ground;

    if(reflection){
      const st=this.e.sys('stage').floor;
      c.save();
      c.translate(f.x, 2*G+22-f.y);
      c.scale(f.facing, -st.reflection.squash);
      c.globalAlpha=st.reflection.alpha;
      this._drawParts(c,atlas,built.list);
      c.restore(); c.globalAlpha=1; return;
    }

    /* contact shadow scales with height off the ground */
    c.fillStyle='rgba(0,0,0,0.55)'; c.beginPath();
    const sc=Math.max(0.4, 1-(G-f.y)/300);
    const [SW,SH]=rig.sourceSize, spriteW=SW/SH*S.displayHeight;
    c.ellipse(f.x, G+12, spriteW*0.34*sc, 8*sc, 0, 0, Math.PI*2); c.fill();

    /* dash afterimages + heavy-attack smears, posed the same as the body */
    for(const g of f.ghosts){
      c.save(); c.translate(g.x,g.y); c.scale(f.facing,1);
      c.globalAlpha=0.16*(g.life/12);
      this._drawParts(c,atlas,built.list,f.accent); c.restore(); c.globalAlpha=1; }
    for(const sm of f.smears){
      c.save(); c.translate(sm.x,sm.y); c.scale(f.facing,1);
      c.transform(1,0,-0.26,1,0,0); c.globalAlpha=0.13*(sm.life/8);
      this._drawParts(c,atlas,built.list,f.accent); c.restore(); c.globalAlpha=1; }

    const hidden = f.invulnT>0 && (this.e.frame%4<2);
    if(!hidden){
      c.save(); c.translate(f.x,f.y); c.scale(f.facing,1);
      /* breathing accent aura */
      c.save(); c.globalAlpha=0.10+0.05*Math.sin(this.e.frame/13); c.scale(1.05,1.04);
      this._drawParts(c,atlas,built.list,f.accent); c.restore(); c.globalAlpha=1;
      if(f.glitchT>0){
        for(let b=0;b<4;b++){
          c.save(); c.translate((Math.random()-.5)*14,0);
          c.beginPath(); c.rect(-spriteW, -S.displayHeight*(1-b*0.25),
            spriteW*2, S.displayHeight*0.25); c.clip();
          this._drawParts(c,atlas,built.list); c.restore(); }
        c.globalAlpha=0.3; this._drawParts(c,atlas,built.list,f.accent); c.globalAlpha=1;
      } else {
        this._drawParts(c,atlas,built.list);
        if(f.state===STATE.HITSTUN && this.e.frame%4<2){
          c.globalAlpha=0.6; this._drawParts(c,atlas,built.list,'#ffffff'); c.globalAlpha=1; }
      }
      if(f.state===STATE.BLOCK){
        c.strokeStyle='rgba(87,200,255,0.5)'; c.lineWidth=3;
        c.beginPath(); c.arc(spriteW*0.42,-S.displayHeight*0.45,S.displayHeight*0.42,-0.9,0.9); c.stroke(); }
      c.restore();
    }
    /* cache the live hand position for VFX / projectile spawns */
    const ha=sk.handAnchor(f.id, built, S.displayHeight);
    f.handX = f.x + f.facing*ha.x; f.handY = f.y + ha.y;
    if(this.showBoxes) this.drawBoxes(c,f);
  }
  /** Draw a posed part list; `tint` renders silhouettes for ghosts/aura/flash. */
  _drawParts(c, atlas, list, tint){
    const tinted = tint ? this._tint(atlas, tint) : null;
    const img = tinted || atlas;
    for(const p of list){
      c.save();
      c.translate(p.x, p.y);
      c.rotate(p.rot);
      c.drawImage(img, p.frame[0], p.frame[1], p.frame[2], p.frame[3],
        -p.px, -p.py, p.w, p.h);
      c.restore();
    }
  }
  _tint(atlas, color){
    this._tintCache = this._tintCache || new Map();
    const key = (atlas.src ? atlas.src.length : atlas.width) + '|' + color;
    if(this._tintCache.has(key)) return this._tintCache.get(key);
    const cv=document.createElement('canvas'); cv.width=atlas.width; cv.height=atlas.height;
    const cc=cv.getContext('2d'); cc.drawImage(atlas,0,0);
    cc.globalCompositeOperation='source-in'; cc.fillStyle=color;
    cc.fillRect(0,0,cv.width,cv.height);
    this._tintCache.set(key,cv); return cv;
  }
  drawGlitch(c,sh,dw,dh){
    const bands=6, bh=sh.h/bands, dbh=dh/bands;
    for(let b=0;b<bands;b++){ const off=(Math.random()-.5)*16;
      c.drawImage(sh.img,0,b*bh,sh.w,bh,-dw/2+off,-dh+b*dbh,dw,dbh); }
    c.globalAlpha=0.28; c.drawImage(sh.sil,-dw/2+(Math.random()-.5)*10,-dh,dw,dh); c.globalAlpha=1;
  }
  drawBoxes(c,f){
    const fd=this.e.sys('framedata');
    c.strokeStyle='rgba(87,200,255,0.8)'; c.lineWidth=1.5;
    c.strokeRect(f.x-f.w/2, f.y-f.hgt, f.w, f.hgt);
    if(f.move){ const d=fd.move(f.id,f.move.id);
      if(d && d.isActive(f.move.t) && d.range){
        const hx=f.x+f.facing*(f.w/2+d.range/2);
        c.strokeStyle='rgba(255,63,164,0.9)';
        c.strokeRect(hx-d.range/2, f.y-140, d.range, 110); } }
  }
  drawProjectile(c,p){
    c.save(); c.translate(p.x,p.y); c.rotate(p.spin||0);
    c.shadowColor=p.def.trailColor||'#fff'; c.shadowBlur=6;
    c.fillStyle='#f2ecdf'; c.fillRect(-7,-10,14,20); c.shadowBlur=0;
    c.strokeStyle='#c22b2b'; c.lineWidth=1.4; c.strokeRect(-7,-10,14,20);
    c.fillStyle='#c22b2b'; c.font='900 11px Arial'; c.textAlign='center'; c.fillText('\u2660',0,4);
    c.restore();
  }
  drawParticles(c,vfx){ for(const p of vfx.particles){ c.fillStyle=p.col;
    c.beginPath(); c.arc(p.x,p.y,p.r,0,Math.PI*2); c.fill(); } }
  drawRings(c,vfx){ for(const r of vfx.rings){ c.strokeStyle=r.col; c.globalAlpha=r.life/14;
    c.lineWidth=3; c.beginPath(); c.arc(r.x,r.y,r.r,0,Math.PI*2); c.stroke(); c.globalAlpha=1; } }
  drawSpeedLines(m,vfx,cam){
    for(const l of vfx.lines){ const [sx,sy]=cam.toScreen(l.x,l.y);
      m.strokeStyle='rgba(239,233,220,'+(l.life/8*0.5)+')'; m.lineWidth=2;
      for(let i=0;i<10;i++){ const a=i/10*Math.PI*2+l.life;
        m.beginPath(); m.moveTo(sx+Math.cos(a)*46, sy+Math.sin(a)*46);
        m.lineTo(sx+Math.cos(a)*(86+l.life*6), sy+Math.sin(a)*(86+l.life*6)); m.stroke(); } }
  }
  drawComics(m,vfx,cam){
    for(const cm of vfx.comics){ const [sx,sy]=cam.toScreen(cm.x,cm.y);
      const k=cm.life>20?(26-cm.life)/6:1;
      m.save(); m.translate(sx,sy); m.rotate(cm.rot); m.scale(k,k);
      m.font='900 30px "Arial Narrow", Arial'; m.textAlign='center';
      m.lineWidth=6; m.strokeStyle='#0a0618'; m.strokeText(cm.str,0,0);
      m.fillStyle=cm.col; m.fillText(cm.str,0,0); m.restore(); }
  }
}
