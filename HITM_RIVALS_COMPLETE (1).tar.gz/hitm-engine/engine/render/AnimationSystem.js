import { STATE } from '../combat/Fighter.js';
/**
 * AnimationSystem — maps fighter state to (clip, frame) and manages crossfades.
 * The simulation owns the frame; this only decides WHICH clip is showing and
 * blends between clips when the state machine transitions.
 */
export class AnimationSystem {
  init(engine){ this.e = engine; this.tracks = new Map(); }   // fighter -> playback
  _track(f){
    if(!this.tracks.has(f)) this.tracks.set(f, {clip:'idle', frame:0, prev:null, prevFrame:0, blend:1});
    return this.tracks.get(f);
  }
  /** Clip name for the fighter's current state. Attack clips are named after the move. */
  clipFor(f){
    switch(f.state){
      case STATE.IDLE:    return f.landT>0 ? 'land' : 'idle';
      case STATE.WALK:    { const fwd=(f.vx>0)===(f.facing>0); return fwd?'walk':'walkBack'; }
      case STATE.JUMP:    return f.vy<0 ? 'jumpUp' : 'jumpDown';
      case STATE.BLOCK:   return 'block';
      case STATE.HITSTUN: return 'hurt';
      case STATE.DOWN:    return 'down';
      case STATE.KO:      return 'ko';
      case STATE.ATTACK:  return f.move ? f.move.id : 'idle';
      default:            return 'idle';
    }
  }
  /** Frame within the clip — always derived from sim state, never a wall clock. */
  frameFor(f, clip){
    if(f.state===STATE.ATTACK && f.move) return f.move.t;
    if(f.state===STATE.HITSTUN) return Math.max(0, 14 - f.stun);
    if(f.state===STATE.DOWN) return Math.max(0, 10 - f.downT);
    if(f.state===STATE.KO) return Math.min(30, f.animT - (f.koStart||0));
    if(f.dashT>0) return 9 - f.dashT;
    if(clip==='land') return 8 - f.landT;
    return f.animT;
  }
  update(){
    const s=this.e.state; if(!s) return;
    for(const f of s.fighters){
      const t=this._track(f);
      let clip = f.dashT>0 ? 'dash' : this.clipFor(f);
      const sk=this.e.sys('skeleton');
      if(!sk.clip(f.id, clip)) clip='idle';
      if(clip!==t.clip){ t.prev=t.clip; t.prevFrame=t.frame; t.blend=0; t.clip=clip; }
      t.frame = this.frameFor(f, clip);
      if(t.blend<1) t.blend=Math.min(1, t.blend + 0.24);   // ~4-frame crossfade
    }
  }
  playback(f){ return this._track(f); }
}
