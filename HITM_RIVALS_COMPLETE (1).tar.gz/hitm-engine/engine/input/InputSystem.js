/**
 * InputSystem — device abstraction + per-player buffered input.
 * Emits nothing; exposes read(playerIndex) -> InputState.
 * Rollback-ready: raw frames are recorded so a match can be replayed
 * from (seed + inputs) alone. Never read the DOM outside this system.
 */
const BLANK = () => ({left:false,right:false,up:false,down:false,
  light:false,heavy:false,special:false,meter:false,dash:false});

export class InputSystem {
  constructor(){
    this.keys = {};
    this.touch = BLANK();
    this.devices = [ {type:'keyboard'}, {type:'ai'} ];
    this.history = [];            // [frame][player] = state (replay/rollback source)
    this.recording = true;
    this.playback = null;         // set by ReplaySystem
  }
  init(engine){
    this.engine = engine;
    addEventListener('keydown', e=>{
      if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' '].includes(e.key)) e.preventDefault();
      this.keys[e.key.toLowerCase()] = true;
      engine.bus.emit('input:rawKey', e.key.toLowerCase());
    });
    addEventListener('keyup', e=>{ this.keys[e.key.toLowerCase()] = false; });
    this._bindTouch();
  }
  _bindTouch(){
    const map = {tLeft:'left',tRight:'right',tJump:'up',tBlock:'down',
      tDash:'dash',tL:'light',tH:'heavy',tS:'special',tBB:'meter'};
    for(const [id,prop] of Object.entries(map)){
      const el = document.getElementById(id); if(!el) continue;
      const on = e=>{ e.preventDefault(); this.touch[prop]=true; };
      const off= e=>{ e.preventDefault(); this.touch[prop]=false; };
      el.addEventListener('touchstart',on,{passive:false});
      el.addEventListener('touchend',off,{passive:false});
      el.addEventListener('touchcancel',off,{passive:false});
    }
    addEventListener('touchstart',()=>document.body.classList.add('touch'),{once:true,passive:true});
  }
  /** Human device state for this frame. */
  readHuman(){
    const k=this.keys,t=this.touch;
    return {
      left:  !!(k['a']||k['arrowleft']||t.left),
      right: !!(k['d']||k['arrowright']||t.right),
      up:    !!(k['w']||k['arrowup']||t.up),
      down:  !!(k['s']||k['arrowdown']||t.down),
      light: !!(k['j']||t.light),
      heavy: !!(k['k']||t.heavy),
      special:!!(k['l']||t.special),
      meter: !!(k[' ']||t.meter),
      dash:  !!t.dash
    };
  }
  record(frame, states){ if(this.recording) this.history[frame] = states.map(s=>({...s})); }
  playbackFrame(frame){ return this.playback ? this.playback[frame] : null; }
  snapshot(){ return {}; }
  restore(){}
}

/**
 * InputBuffer — per-fighter edge detection + N-frame command buffer.
 * Owned by each fighter so buffered specials survive landing/dash recovery.
 */
export class InputBuffer {
  constructor(bufferFrames=8){ this.n=bufferFrames; this.prev=BLANK(); this.buf={btn:null,t:-999}; }
  pressed(state, btn){ const was=this.prev[btn]; return state[btn] && !was; }
  commit(state){ this.prev = {...state}; }
  push(btn, frame){ this.buf = {btn, t:frame}; }
  consume(frame){
    if(this.buf.btn && frame - this.buf.t <= this.n){ const b=this.buf.btn; this.buf={btn:null,t:-999}; return b; }
    return null;
  }
  clear(){ this.buf={btn:null,t:-999}; }
}
