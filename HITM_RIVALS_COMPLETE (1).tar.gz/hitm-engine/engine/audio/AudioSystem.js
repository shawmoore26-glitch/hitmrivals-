/**
 * AudioSystem — event-driven WebAudio layers. Ships silent-safe:
 * with no audio assets it synthesizes impact layers procedurally, so
 * hit feel exists before a sound designer is hired. Character voice
 * banks slot in via data (voice/*.json) with zero engine changes.
 */
export class AudioSystem {
  init(engine){
    this.e=engine; this.ctx=null; this.enabled=true; this.master=null;
    const start=()=>{ if(this.ctx) return;
      try{ this.ctx=new (window.AudioContext||window.webkitAudioContext)();
        this.master=this.ctx.createGain(); this.master.gain.value=0.22;
        this.master.connect(this.ctx.destination);}catch(e){ this.enabled=false; } };
    addEventListener('pointerdown',start,{once:true});
    addEventListener('keydown',start,{once:true});
    const bus=engine.bus;
    bus.on('combat:hit',({heavy,counter})=>this.impact(heavy?'heavy':'light',counter));
    bus.on('combat:block',()=>this.impact('block'));
    bus.on('combat:perfectGuard',()=>this.tone(1400,0.06,'sine',0.18));
    bus.on('combat:ko',()=>this.impact('ko'));
    bus.on('combat:blockbuster',()=>this.impact('bb'));
    bus.on('combat:flareBreak',()=>this.tone(760,0.09,'sawtooth',0.14));
    bus.on('combat:burst',()=>this.impact('bb'));
  }
  impact(kind, counter){
    if(!this.ctx||!this.enabled) return;
    const P={light:{f:180,d:0.09,n:0.10},heavy:{f:110,d:0.16,n:0.20},
      block:{f:300,d:0.06,n:0.05},ko:{f:70,d:0.5,n:0.32},bb:{f:90,d:0.35,n:0.26}}[kind]||{f:150,d:0.1,n:0.1};
    this.tone(P.f,P.d,'triangle',0.3);            // bass layer
    this.noise(P.d*0.6,P.n);                      // crack layer
    if(counter) this.tone(P.f*3,0.12,'square',0.12);
  }
  tone(freq,dur,type,gain){
    if(!this.ctx) return;
    const o=this.ctx.createOscillator(),g=this.ctx.createGain();
    o.type=type||'sine'; o.frequency.setValueAtTime(freq,this.ctx.currentTime);
    o.frequency.exponentialRampToValueAtTime(Math.max(40,freq*0.5),this.ctx.currentTime+dur);
    g.gain.setValueAtTime(gain||0.2,this.ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001,this.ctx.currentTime+dur);
    o.connect(g); g.connect(this.master); o.start(); o.stop(this.ctx.currentTime+dur);
  }
  noise(dur,gain){
    if(!this.ctx) return;
    const n=Math.floor(this.ctx.sampleRate*dur);
    const buf=this.ctx.createBuffer(1,n,this.ctx.sampleRate), d=buf.getChannelData(0);
    for(let i=0;i<n;i++) d[i]=(Math.random()*2-1)*(1-i/n);
    const src=this.ctx.createBufferSource(); src.buffer=buf;
    const g=this.ctx.createGain(); g.gain.value=gain;
    const f=this.ctx.createBiquadFilter(); f.type='highpass'; f.frequency.value=900;
    src.connect(f); f.connect(g); g.connect(this.master); src.start();
  }
}
