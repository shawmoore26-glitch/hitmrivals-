/**
 * AISystem — personality-driven opponents. Behaviour lives in data
 * (characters/<id>/ai.json), so a designer tunes AI without touching code.
 * Uses engine RNG (deterministic) — never Math.random — so replays reproduce.
 * No input reading, no cheating: the AI only sees public fighter state.
 */
export class AISystem {
  init(engine){ this.e=engine; this.profiles=new Map(); }
  registerCharacter(id, profile){ this.profiles.set(id, profile); }
  decide(f, foe){
    const inp={left:false,right:false,up:false,down:false,
      light:false,heavy:false,special:false,meter:false,dash:false};
    const s=this.e.state;
    if(!s || s.phase!=='fight') return inp;
    const P=this.profiles.get(f.id)||{aggression:0.5,zoning:0.4,dashLove:0.4,whiffPunish:0.5};
    const R=this.e.rng, fd=this.e.sys('framedata');
    const dist=Math.abs(foe.x-f.x);
    f.aiT=(f.aiT||0)-1;
    /* whiff punish: opponent in recovery, in range */
    if(foe.move){ const fm=fd.move(foe.id, foe.move.id);
      if(fm && fm.isRecovery(foe.move.t) && dist<170 && f.state!=='attack' && R.chance(P.whiffPunish*0.6)){
        inp.light=true; return inp; } }
    if(f.aiT<=0){
      f.aiT=16+R.next()*26;
      const r=R.next();
      const guardRead = foe.blockedRecently>0 && R.chance(P.guardBreakRead||0.4);
      if(f.meter>=this.e.cfg.meter.bbCost && dist<220) f.aiPlan='bb';
      else if(foe.state==='down' && dist<140) f.aiPlan='light';
      else if(foe.state==='hitstun' && dist<150) f.aiPlan = r<0.45?'light':(r<0.8?'heavy':'smash');
      else if(guardRead && dist<170) f.aiPlan='smash';
      else if(dist>360) f.aiPlan = r<P.zoning?'special':(r<P.zoning+P.dashLove*0.4?'dash':'approach');
      else if(dist>180) f.aiPlan = r<P.dashLove*0.5?'dash':(r<0.6?'approach':(r<0.8?'special':'specialF'));
      else { const a=P.aggression;
        f.aiPlan = r<0.34*a+0.1?'light':(r<0.5*a+0.2?'heavy':(r<0.6*a+0.28?'smash':(r<0.86?'block':'retreat'))); }
      if(foe.state==='attack' && dist<190 && R.chance(0.44)) f.aiPlan='block';
      if(foe.y<this.e.cfg.physics.ground-60 && dist<180 && R.chance(0.5)) f.aiPlan='heavy';
    }
    const toward = foe.x<f.x?'left':'right', away = foe.x<f.x?'right':'left';
    switch(f.aiPlan){
      case 'approach': inp[toward]=true; break;
      case 'retreat':  inp[away]=true; break;
      case 'dash':     inp[toward]=true; inp.dash=true; break;
      case 'light':    inp.light=true; break;
      case 'heavy':    inp.heavy=true; break;
      case 'smash':    inp[toward]=true; inp.heavy=true; break;
      case 'special':  inp.special=true; break;
      case 'specialF': inp[toward]=true; inp.special=true; break;
      case 'block':    inp.down=true; break;
      case 'bb':       inp.meter=true; break;
    }
    return inp;
  }
}
