/**
 * FrameData — reads move definitions. The engine NEVER hardcodes move behavior.
 * Derives canonical phase boundaries from startup/active/recovery so designers
 * edit JSON, not code.
 */
export class MoveDef {
  constructor(id, raw){
    Object.assign(this, raw);
    this.id = id;
    this.startup  = raw.startup  ?? 5;
    this.active   = raw.active   ?? 2;
    this.recovery = raw.recovery ?? 8;
    this.total    = this.startup + this.active + this.recovery;
    this.hitFrame = this.startup;          // first active frame
    this.activeEnd= this.startup + this.active - 1;
  }
  isStartup(t){ return t < this.startup; }
  isActive(t){ return t >= this.startup && t <= this.activeEnd; }
  isRecovery(t){ return t > this.activeEnd; }
  /** Can this move cancel into target on frame t? */
  canCancel(target, t){
    const c = this.cancels; if(!c || !c.into) return false;
    if(!c.into.includes(target)) return false;
    const [a,b] = c.window || [0, this.total];
    return t >= a && t <= b;
  }
}
export class FrameDataSystem {
  constructor(){ this.sets = new Map(); }   // charId -> {moves, chains, projectiles}
  registerCharacter(charId, movesJson){
    const moves = {};
    for(const [id,raw] of Object.entries(movesJson.moves||{})) moves[id] = new MoveDef(id, raw);
    this.sets.set(charId, { moves, chains: movesJson.chains||{}, projectiles: movesJson.projectiles||{} });
  }
  move(charId, moveId){ const s=this.sets.get(charId); return s ? s.moves[moveId] : null; }
  chain(charId, name){ const s=this.sets.get(charId); return s ? (s.chains[name]||[]) : []; }
  projectile(charId, id){ const s=this.sets.get(charId); return s ? s.projectiles[id] : null; }
  /** Tooling: full frame table for the debug overlay / trials. */
  table(charId){
    const s=this.sets.get(charId); if(!s) return [];
    return Object.values(s.moves).map(m=>({
      id:m.id, name:m.name, startup:m.startup, active:m.active, recovery:m.recovery,
      total:m.total, damage:m.damage||0, onBlock:(m.blockstun||0)-(m.active+m.recovery)
    }));
  }
}
