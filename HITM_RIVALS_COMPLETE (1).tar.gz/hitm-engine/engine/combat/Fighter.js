import { InputBuffer } from '../input/InputSystem.js';
/**
 * Fighter — pure state container. Zero rendering, zero input reading.
 * Built entirely from character.json; the class knows nothing about
 * which character it is. Fully serializable for rollback/replay.
 */
export const STATE = Object.freeze({
  IDLE:'idle', WALK:'walk', JUMP:'jump', DASH:'dash', BLOCK:'block',
  ATTACK:'attack', HITSTUN:'hitstun', DOWN:'down', KO:'ko',
  /* Throw states (Phase 2 Part 4). GRAB is the attempt — whiffable and
     punishable. THROWN/THROWING is the confirmed lock: neither fighter may
     act, so there is no mash-out. */
  GRAB:'grab', THROWING:'throwing', THROWN:'thrown'
});
export class Fighter {
  constructor(def, opts){
    this.def = def;                     // character.json
    this.id = def.id;
    this.baseId = def.id;   // Volume 17: id may swap at runtime; this never does
    this.stateT = 0;
    this.index = opts.index;
    this.isAI = !!opts.isAI;
    const hp = Math.round(1000 * def.stats.healthMult);
    this.maxhp = hp; this.hp = hp; this.dispHp = hp;
    this.meter = 0;
    this.x = opts.x; this.y = opts.ground; this.vx=0; this.vy=0;
    this.facing = opts.facing;
    this.w = 52; this.hgt = 150;
    this.state = STATE.IDLE;
    this.move = null;                   // {id, t, chainIdx}
    this.hitDone = false;
    this.chainIdx = 0; this.chainBuf = null;
    this.stun = 0; this.specCd = 0; this.animT = 0;
    this.combo = 0; this.comboT = 0;
    this.dashT = 0; this.dashDir = 0; this.lastTap = {dir:0,t:-99};
    this.blockStartFrame = -999; this.blockedRecently = 0;
    this.wallUsed=false; this.groundUsed=false; this.otgUsed=false;
    this.spiked=false; this.pendingDown=false; this.downT=0; this.invulnT=0;
    this.landT=0; this.glitchT=0;
    this.rounds = 0; this.koStart = 0;
    this.handX = undefined; this.handY = undefined;
    this.buffer = new InputBuffer(opts.bufferFrames);
    this.ghosts = []; this.smears = [];     // cosmetic, not simulated state
  }
  get accent(){ return this.def.accent; }
  get power(){ return this.def.stats.power; }
  get speed(){ return this.def.stats.speed; }
  anchor(which, displayHeight, spriteW, spriteH){
    const s = displayHeight/spriteH, dw = spriteW*s;
    const fr = this.def.sprite.anchors[which] || this.def.sprite.anchors.hand;
    const fx = this.facing===1 ? fr[0] : 1-fr[0];
    return [this.x + (fx-0.5)*dw, this.y - displayHeight + fr[1]*displayHeight];
  }
  snapshot(){
    const {def,buffer,ghosts,smears,...rest} = this;
    return rest;
  }
  restore(s){ Object.assign(this, s); }
}
