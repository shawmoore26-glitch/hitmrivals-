import { Fighter, STATE } from './Fighter.js';
/**
 * CombatSystem — the rules engine. Owns match state and the fighter state machine.
 * Reads all behavior from FrameData (JSON); hardcodes no move.
 * Emits combat events; never touches renderer, camera, audio, or VFX directly.
 *
 * Events out:
 *  combat:hit {attacker,defender,move,damage,counter,heavy}
 *  combat:block / combat:perfectGuard / combat:otg / combat:counter
 *  combat:burst / combat:flareBreak / combat:blockbuster {fighter,move}
 *  combat:ko {loser,winner} · combat:roundStart/roundEnd · combat:matchEnd
 *  combat:spawnProjectile {owner,def,x,y,vx,vy,damage,life,cosmetic}
 *  combat:cameraEvent {kind,fighter} · combat:shake {amount} · combat:flash {frames}
 */
export class CombatSystem {
  init(engine){
    this.e = engine;
    this.cfg = engine.cfg;
    this.fd = engine.sys('framedata');
    this.phys = engine.sys('physics');
    this.state = null;
  }
  startMatch(defA, defB){
    const P=this.cfg.physics, C=this.cfg.combat;
    const mk=(def,i,x,facing,isAI)=>new Fighter(def,{index:i,x,facing,isAI,
      ground:P.ground,bufferFrames:C.inputBufferFrames});
    this.state = {
      fighters:[mk(defA,0,300,1,false), mk(defB,1,760,-1,true)],
      projectiles:[], scheduled:[],
      round:1, roundT:120, timer:this.cfg.rounds.timerSeconds*60,
      phase:'roundIntro'   // roundIntro | fight | ko | matchOver
    };
    this.e.state = this.state;
    this.e.bus.emit('combat:matchStart', {fighters:this.state.fighters});
    this.e.bus.emit('combat:roundStart', {round:1});
    return this.state;
  }
  resetRound(){
    const P=this.cfg.physics, s=this.state;
    s.fighters.forEach((f,i)=>{
      f.x = i===0?300:760; f.y=P.ground; f.vx=0; f.vy=0; f.facing = i===0?1:-1;
      f.hp=f.maxhp; f.dispHp=f.maxhp; f.state=STATE.IDLE; f.move=null;
      f.stun=0; f.specCd=0; f.combo=0; f.comboT=0; f.chainIdx=0; f.chainBuf=null;
      f.wallUsed=false; f.groundUsed=false; f.otgUsed=false; f.spiked=false;
      f.pendingDown=false; f.downT=0; f.invulnT=0; f.ghosts=[]; f.smears=[];
      f.buffer.clear();
    });
    s.projectiles=[]; s.scheduled=[];
    s.timer=this.cfg.rounds.timerSeconds*60; s.phase='roundIntro'; s.roundT=120;
    this.e.bus.emit('combat:roundStart',{round:s.round});
  }
  update(){
    const s=this.state; if(!s) return;
    if(s.phase==='roundIntro'){ if(--s.roundT<=0){ s.phase='fight'; this.e.bus.emit('combat:fightStart'); } return; }
    const inputs = this.e.sys('input') ? this._gatherInputs() : [];
    if(s.phase==='fight'){
      s.fighters.forEach((f,i)=>this._tickFighter(f, s.fighters[1-i], inputs[i]||{}));
      if(--s.timer<=0){
        const [a,b]=s.fighters;
        const w = a.hp/a.maxhp >= b.hp/b.maxhp ? a : b;
        this._ko(w===a?b:a, w);
      }
    } else if(s.phase==='ko'){
      s.fighters.forEach((f,i)=>this._tickFighter(f, s.fighters[1-i], {}));
      if(--s.koT<=0) this._endRound();
    }
    this._runScheduled();
    this._tickProjectiles();
  }
  _gatherInputs(){
    const inp=this.e.sys('input'), ai=this.e.sys('ai');
    const s=this.state;
    const out=s.fighters.map((f,i)=> f.isAI ? ai.decide(f, s.fighters[1-i]) : inp.readHuman());
    inp.record(this.e.frame, out);
    return out;
  }
  schedule(delay, fn){ this.state.scheduled.push({t:delay, fn}); }
  _runScheduled(){
    const s=this.state;
    for(const ev of s.scheduled) ev.t--;
    const fire=s.scheduled.filter(e=>e.t<=0);
    s.scheduled=s.scheduled.filter(e=>e.t>0);
    for(const ev of fire) ev.fn();
  }

  /* ---------------- fighter state machine ---------------- */
  _tickFighter(f, foe, input){
    const C=this.cfg.combat, P=this.cfg.physics;
    f.specCd=Math.max(0,f.specCd-1);
    if(f.invulnT>0) f.invulnT--;
    if(f.blockedRecently>0) f.blockedRecently--;
    if(f.comboT>0 && --f.comboT===0){ f.combo=0; foe.wallUsed=false; foe.groundUsed=false; foe.otgUsed=false; }
    f.animT++; if(f.landT>0)f.landT--; if(f.glitchT>0)f.glitchT--;

    /* VOLUME 18 — EVOLUTION TRIGGER (Option B). Brooklyn evolves by understanding,
       not by filling a bar. Conditions come from character.json; the engine only
       counts. Both must be met: enough damage survived to have studied them, and
       enough reads landed to have proven it. */
    /* reads decay — stand still and what he learned goes stale */
    const _re = f.def && f.def.readEngine;
    if(_re && f.reads>0){
      f.readT=(f.readT||0)+1;
      if(f.readT >= (_re.decay ? _re.decay.frames : 420)){
        f.reads=Math.max(0, f.reads-((_re.decay&&_re.decay.amount)||1)); f.readT=0;
        this.e.bus.emit('combat:readDecay',{fighter:f, reads:f.reads});
      }
    }
    const ev = f.def && f.def.evolution;
    if(ev && f.id===f.baseId){
      for(const [sid,rule] of Object.entries(ev)){
        if(rule.trigger!=='evolution') continue;
        const c=rule.conditions||{};
        if((f.dmgTaken||0) >= (c.damageSurvived||1e9) && (f.reads||0) >= (c.readsLanded||1e9)){
          const prev=f.id; f.id=f.baseId+'_'+sid; f.stateT=rule.duration||600;
          this.e.bus.emit('combat:evolve',{fighter:f, from:prev, to:f.id, state:sid,
            dmgTaken:f.dmgTaken, reads:f.reads});
          break;
        }
      }
    }
    if(f.stateT>0 && --f.stateT===0 && f.baseId && f.id!==f.baseId){
      const prev=f.id; f.id=f.baseId;
      this.e.bus.emit('combat:stateChange',{fighter:f, from:prev, to:f.id, state:'base'});
    }
    switch(f.state){
      case STATE.GRAB:     this._tickGrab(f,foe,input); break;
      case STATE.THROWING: this._tickThrowing(f,foe,input); break;
      case STATE.THROWN:   this._tickThrown(f,foe); break;
      case STATE.KO:      this._tickKO(f); break;
      case STATE.DOWN:    this._tickDown(f,input); break;
      case STATE.HITSTUN: this._tickHitstun(f,foe,input); break;
      case STATE.ATTACK:  this._tickAttack(f,foe,input); break;
      default:            this._tickFree(f,foe,input); break;
    }
    f.buffer.commit(input);
  }
  /* ── THROW STATE MACHINE ──────────────────────────────────────────────────
       neutral -> GRAB attempt
                    hit  -> THROW LOCK (attacker THROWING, defender THROWN)
                              -> scripted phases -> damage -> camera -> recovery
                    whiff -> punishable recovery
     Frame data comes from moves.json like every other move. No new balance
     numbers are invented here; the engine only executes what the data says. */
  _tickGrab(f,foe,input){
    const def=this.fd.move(f.id, f.move.id); if(!def){ f.state=STATE.IDLE; return; }
    f.move.t++;
    const t=f.move.t;
    if(t>=def.startup && t<def.startup+def.active && !f.grabDone){
      const range=def.range||70, height=def.height||110;
      const inRange = Math.abs(f.x-foe.x)<range && Math.abs(f.y-foe.y)<height;
      const grabbable = foe.state!==STATE.DOWN && foe.state!==STATE.KO
                        && foe.state!==STATE.THROWN && foe.invulnT<=0;
      if(inRange && grabbable){
        f.grabDone=true;
        f.state=STATE.THROWING; f.throwT=0; f.throwVictim=foe;
        foe.state=STATE.THROWN; foe.thrownBy=f; foe.stun=0; foe.vx=0; foe.vy=0;
        foe.facing=-f.facing;
        this.e.bus.emit('combat:grab',{attacker:f, defender:foe, move:f.move.id});
      }
    }
    if(t>=def.total){                       // WHIFF — punishable recovery
      f.state=STATE.IDLE; f.move=null; f.grabDone=false;
      this.e.bus.emit('combat:grabWhiff',{fighter:f});
    }
  }

  _tickThrowing(f,foe,input){
    const def=this.fd.move(f.id, f.move.id); if(!def){ f.state=STATE.IDLE; return; }
    f.throwT++;
    const ph=def.throwPhases||[];
    for(const step of ph){
      if(step.at!==f.throwT) continue;
      if(step.damage){
        const v=f.throwVictim;
        if(v){
          const final=Math.round(step.damage);
          v.hp=Math.max(0,v.hp-final); v.dmgTaken=(v.dmgTaken||0)+final;
          f.meter=Math.min(this.cfg.meter.max,f.meter+(step.meterGain||0));
          const HS=(this.cfg.combat&&this.cfg.combat.hitstop)||{};
          this.e.hitstop=Math.max(this.e.hitstop, HS[step.hitstop||'heavy']||8);
          this.e.bus.emit('combat:throwHit',
            {attacker:f, defender:v, damage:final, phase:step.phase});
        }
      }
      if(step.camera) this.e.bus.emit('combat:camera',
        {mode:step.camera, frames:step.cameraFrames||24, focus:f});
      if(step.vfx) this.e.bus.emit('combat:vfx',{kind:step.vfx, x:f.x, y:f.y});
      if(step.shake) this.e.bus.emit('combat:shake',{amount:step.shake});
    }
    const dur=def.throwDuration||def.total;
    if(f.throwT>=dur){
      const v=f.throwVictim;
      if(v){
        v.state=STATE.DOWN; v.downT=def.throwKnockdown||40; v.knockdownFromThrow=true;
        v.otgUsed=false; v.thrownBy=null;
        v.x = f.x + (def.throwPlace||60)*f.facing;
      }
      f.state=STATE.IDLE; f.move=null; f.throwVictim=null; f.grabDone=false;
      this.e.bus.emit('combat:throwEnd',{attacker:f, defender:v});
    }
  }

  /* The thrown fighter has no agency. Confirmed grab = confirmed outcome. */
  _tickThrown(f,foe){
    const t=f.thrownBy;
    if(!t || t.state!==STATE.THROWING){ f.state=STATE.DOWN; f.downT=30; f.thrownBy=null; return; }
    f.vx=0; f.vy=0;
    f.x = t.x + 34*t.facing;
    f.y = t.y;
  }

  _tickKO(f){ const P=this.cfg.physics;
    f.vy+=P.gravity; f.y+=f.vy; f.x+=f.vx*0.94;
    if(f.y>P.ground){ f.y=P.ground; f.vy=0; f.vx*=0.8; } }
  _tickDown(f,input){
    f.buffer.commit(input);
    if(--f.downT<=0){ f.state=STATE.IDLE; f.invulnT=this.cfg.combat.wakeupInvuln; } }
  _tickHitstun(f,foe,input){
    const C=this.cfg.combat, P=this.cfg.physics;
    if(f.buffer.pressed(input,'meter') && f.meter>=C.burstCost!==undefined && f.meter>=this.cfg.meter.burstCost){
      f.meter=0; f.state=STATE.IDLE; f.stun=0; f.invulnT=C.burstInvuln; f.vx=0; f.vy=0;
      this.e.bus.emit('combat:burst',{fighter:f, foe});
      if(Math.abs(foe.x-f.x)<170 && foe.state!==STATE.KO){
        foe.vx=8*Math.sign(foe.x-f.x||1); foe.vy=-5;
        if(foe.state===STATE.ATTACK){ foe.state=STATE.IDLE; foe.move=null; } }
      return; }
    f.stun--; f.vy+=P.gravity; f.y+=f.vy; f.x+=f.vx; f.vx*=0.93;
    this.phys.tryWallBounce(f);
    if(f.y>P.ground){
      if(!this.phys.tryGroundBounce(f)){
        const hard=f.pendingDown && f.vy>3;
        f.y=P.ground; f.vy=0; f.spiked=false;
        if(hard){ f.pendingDown=false; f.state=STATE.DOWN; f.downT=this.cfg.combat.downFrames; f.stun=0;
          this.phys.clampX(f); return; } } }
    if(f.stun<=0){ f.state=STATE.IDLE; f.pendingDown=false; }
    this.phys.clampX(f);
  }
  _tickAttack(f,foe,input){
    const C=this.cfg.combat, P=this.cfg.physics, M=this.cfg.meter;
    const def=this.fd.move(f.id, f.move.id);
    f.move.t++;
    /* FLARE BREAK — data-driven cancel of any non-blockbuster */
    if(def.type!=='blockbuster' && f.buffer.pressed(input,'meter') &&
       f.meter>=M.breakCost && f.meter<M.bbCost){
      f.meter-=M.breakCost; f.state=STATE.IDLE; f.move=null; f.chainBuf=null;
      this.e.bus.emit('combat:flareBreak',{fighter:f});
      this.phys.clampX(f); return; }
    if(def.rush) this._applyRush(f,foe,def);
    if(def.teleport && f.move.t===def.startup && !f.hitDone){
      f.hitDone=true; f.ghosts.push({x:f.x,y:f.y,life:12});
      f.x += f.facing*def.teleport.distance; this.phys.clampX(f);
      f.glitchT=def.glitchFrames||12;
      this.e.bus.emit('combat:teleport',{fighter:f, move:def}); }
    if(!f.hitDone && f.move.t===def.hitFrame && !def.rush && !def.teleport){
      f.hitDone=true;
      if(def.selfVelocityY) f.vy=def.selfVelocityY;
      if(def.spawn) this._spawn(f,def);
      if(def.damage) this._melee(f,foe,def);
      if(def.vfx) this.e.bus.emit('vfx:play',{name:def.vfx, fighter:f});
      if(def.type==='blockbuster') this._runScript(f,def); }
    if(def.type==='blockbuster' && f.move.t===1) this._runScript(f,def,true);
    /* chain buffering — cancel windows come from JSON */
    const fwd=(f.facing===1&&input.right)||(f.facing===-1&&input.left);
    if(f.buffer.pressed(input,'light') && def.canCancel(this._nextChain(f), f.move.t))
      f.chainBuf=this._nextChain(f);
    else if(f.buffer.pressed(input,'heavy') && def.canCancel(fwd?'smash':'heavy', f.move.t))
      f.chainBuf=fwd?'smash':'heavy';
    else if(f.buffer.pressed(input,'special') && def.canCancel('special', f.move.t) && f.specCd<=0)
      f.chainBuf=fwd?'specialF':'special';
    else if(f.buffer.pressed(input,'meter') && f.meter>=M.bbCost && def.canCancel('blockbuster', f.move.t))
      f.chainBuf='blockbuster';
    if(f.y<P.ground){ f.vy+=P.gravity; f.y=Math.min(P.ground,f.y+f.vy);
      if(f.y>=P.ground){ f.landT=7;
        if(def.context==='air'){ f.state=STATE.IDLE; f.move=null; } } }
    if(f.move && f.move.t>=def.total){
      if(f.chainBuf){ const nxt=f.chainBuf; f.chainBuf=null; this._start(f,nxt); this.phys.clampX(f); return; }
      f.state=STATE.IDLE; f.move=null; f.chainBuf=null; }
    this.phys.clampX(f);
  }
  _nextChain(f){
    const chain=this.fd.chain(f.id,'light');
    const cur=f.move?chain.indexOf(f.move.id):-1;
    return cur>=0 && cur<chain.length-1 ? chain[cur+1] : chain[0];
  }
  _applyRush(f,foe,def){
    const r=def.rush;
    if(f.move.t===1){ f.vx=(r.velocityX||0)*f.facing; if(r.velocityY) f.vy=r.velocityY; }
    f.x+=f.vx; f.vx*=(r.friction||0.93);
    if(r.leaveGhost && f.animT%2===0) f.ghosts.push({x:f.x,y:f.y,life:12});
    if(def.vfx) this.e.bus.emit('vfx:play',{name:def.vfx, fighter:f, anchor:'hand'});
    if(!f.hitDone && f.move.t>=(def.startup+(f.startupRoll||0)) &&
       Math.abs(f.x-foe.x)<(r.hitRangeX||80) && Math.abs(f.y-foe.y)<(r.hitRangeY||110)){
      f.hitDone=true;
      this.applyHit(foe,f,{damage:def.damage,pushback:def.pushback,hitstun:def.hitstun,
        knockdown:def.knockdown, hitstop:'heavy'}); }
  }
  _spawn(f,def){
    const S=this.cfg.sprite;
    for(const sp of def.spawn){
      const pdef=this.fd.projectile(f.id, sp.projectile) || {};
      const spriteKey=f.def.sprite.key;
      const img=this.e.res.img(spriteKey);
      const fb=f.anchor(sp.anchor||'hand', S.displayHeight, img.width, img.height);
      const ax = (f.handX!==undefined) ? f.handX : fb[0];
      const ay = (f.handY!==undefined) ? f.handY : fb[1];
      const n=sp.count||1;
      for(let i=0;i<n;i++){
        const mid=(n-1)/2, off=(i-mid);
        const speed = sp.speedMin!=null
          ? sp.speedMin + this.e.rng.next()*(sp.speedMax-sp.speedMin)
          : (sp.speed||10);
        this.e.bus.emit('combat:spawnProjectile',{
          owner:f, def:pdef, kind:sp.projectile,
          x:ax + f.facing*8,
          y:ay + (sp.spreadY ? (this.e.rng.next()-0.5)*sp.spreadY : off*(sp.spread||0)),
          vx: speed*f.facing, vy: sp.cosmetic ? -7-i : off*0.7,
          damage: sp.cosmetic?0:(sp.damage||0), life: sp.life||70, cosmetic:!!sp.cosmetic });
      }
    }
  }
  _runScript(f,def,atStart){
    if(atStart){
      if(def.flash) this.e.bus.emit('combat:flash',{frames:def.flash});
      if(def.slowmo) this.e.slowmo=def.slowmo;
      if(def.camera) this.e.bus.emit('combat:cameraEvent',{kind:def.camera,fighter:f,frames:def.cameraFrames});
      this.e.bus.emit('combat:blockbuster',{fighter:f,move:def});
      for(const step of (def.script||[])){
        const reps=step.repeat||1, every=step.every||1;
        for(let i=0;i<reps;i++) this.schedule(step.at + i*every, ()=>this._scriptAction(f,step,i,reps));
      }
    }
  }
  _scriptAction(f,step,i,reps){
    const foe=this.state.fighters[1-f.index];
    if(step.action==='setState'){
      /* Volume 17 — swap which move/AI table this fighter reads from.
         Every lookup in this engine is already keyed on f.id, so changing it
         changes the fighter's entire combat vocabulary with no other edits.
         The body does not change; what it knows how to do does. */
      const prev=f.id; f.id = step.state ? f.baseId+'_'+step.state : f.baseId;
      if(step.duration) f.stateT = step.duration;
      this.e.bus.emit('combat:stateChange',{fighter:f, from:prev, to:f.id, state:step.state||'base'});
    } else if(step.action==='spawnProjectile'){
      this._spawn(f,{spawn:[{projectile:step.projectile,count:1,damage:step.damage,
        speedMin:step.speedMin,speedMax:step.speedMax,spreadY:step.spreadY,
        life:step.life,anchor:step.anchor}]});
    } else if(step.action==='zoneBurst'){
      if(step.vfx) this.e.bus.emit('vfx:play',{name:step.vfx,fighter:f});
      if(step.shake) this.e.bus.emit('combat:shake',{amount:step.shake});
      if(step.aberration) this.e.bus.emit('render:aberration',{frames:step.aberration});
      for(const off of (step.offsets||[0]))
        this._zoneHit(f,f.x+off,step.halfWidth,{damage:step.damage,pushback:step.pushback,
          hitstun:step.hitstun,stunBonus:step.stunBonus,hitstop:'heavy'});
    } else if(step.action==='blitzPass'){
      const dir=(foe.x>=f.x?1:-1); f.facing=dir; f.vx=0; f.dashT=0;
      const P=this.cfg.physics;
      f.x=Math.max(P.wallL,Math.min(P.wallR, foe.x - dir*step.gap));
      const sx=f.x;
      this.schedule(2, ()=>{
        f.x=sx+dir*step.travel; this.phys.clampX(f);
        f.ghosts.push({x:sx,y:f.y,life:14},{x:(sx+f.x)/2,y:f.y,life:14});
        if(step.vfx) this.e.bus.emit('vfx:play',{name:step.vfx,fighter:f,anchor:'hand'});
        const last=(i===reps-1);
        this._zoneHit(f,(sx+f.x)/2,step.halfWidth,{damage:step.damage,
          pushback:last?step.finalPushback:step.pushback, hitstun:step.hitstun,
          knockdown:last&&step.finalKnockdown, hitstop:'heavy'});
      });
    }
  }
  _melee(f,foe,def){
    const hx=f.x+f.facing*(f.w/2+def.range/2);
    if(Math.abs(hx-foe.x)<(def.range/2+foe.w/2) &&
       Math.abs((f.y-80)-(foe.y-80))<(def.height||105))
      this.applyHit(foe,f,def);
  }
  _zoneHit(f,cx,halfW,def){
    const foe=this.state.fighters[1-f.index];
    if(Math.abs(cx-foe.x)<halfW+foe.w/2 && foe.y>this.cfg.physics.ground-200)
      this.applyHit(foe,f,def);
  }

  /* ---------------- the hit resolution pipeline ---------------- */
  applyHit(def_, atk, move){
    const C=this.cfg.combat, M=this.cfg.meter, d=def_;
    if(d.state===STATE.KO || d.invulnT>0) return false;
    let damage=move.damage||0, pushback=move.pushback||0,
        hitstun=move.hitstun||16, launcher=move.launcher, knockdown=move.knockdown, spike=move.spike;
    let otg=false;
    if(d.state===STATE.DOWN){
      if(d.otgUsed) return false;
      d.otgUsed=true; otg=true; damage*=C.otgDmgMult; launcher=true; knockdown=false; d.downT=0;
      this.e.bus.emit('combat:otg',{defender:d}); }
    /* VOLUME 18 — a READ is a counter hit: striking a fighter who is mid-attack.
       Not a stat, a proof. Brooklyn's evolution counts these. */
    const isRead = d.state===STATE.ATTACK;
    if(isRead){
      /* THE READ ENGINE — Brooklyn's signature system.
         A read is proof he predicted you. Reads scale his DAMAGE OUTPUT only;
         his frame data and his move table never change, so the governor can
         still audit him at his true balance point (0 reads, weakest in cast). */
      const RE = atk.def && atk.def.readEngine;
      atk.reads = Math.min((RE && RE.max_reads) || 0, (atk.reads||0)+1);
      /* being read costs the DEFENDER a read — mistakes compound */
      if(d.def && d.def.readEngine) d.reads = Math.max(0, (d.reads||0)-1);
      atk.readT = 0;
      const cb = move.counterBonus || (atk.move && this.fd.move(atk.id, atk.move.id)||{}).counterBonus;
      if(cb) damage=Math.round(damage*cb);
      this.e.bus.emit('combat:read',{attacker:atk, defender:d, total:atk.reads});
    }
    const blocking = d.state===STATE.BLOCK && d.y>=this.cfg.physics.ground;
    /* PERFECT GUARD */
    if(blocking && d.animT - d.blockStartFrame <= C.perfectGuardWindow){
      d.meter=Math.min(M.max, d.meter+M.perfectGuardGain);
      atk.vx=-6*atk.facing;
      this.e.hitstop=6;
      this.e.bus.emit('combat:perfectGuard',{defender:d, attacker:atk});
      return false; }
    /* COUNTER HIT */
    let counter=false;
    if(!blocking && d.state===STATE.ATTACK && d.move){
      const dm=this.fd.move(d.id, d.move.id);
      if(dm && dm.isStartup(d.move.t)){ counter=true; damage*=C.counterDmgMult; hitstun+=C.counterStunBonus; } }
    const scale=Math.max(C.scaleMin, 1 - C.scaleStep*Math.max(0, atk.combo));
    const final=Math.round(damage*scale*atk.power*(blocking?C.chipMult:1));
    /* THE READ ENGINE applies at the point of damage, never to the move table.
       `final` is const, so scale into a separate binding rather than reassigning. */
    let _out = final;
    if(atk.def && atk.def.readEngine && atk.reads>0){
      const _t=atk.def.readEngine.tiers[Math.min(atk.reads, atk.def.readEngine.tiers.length-1)];
      if(_t && _t.damage_mult){
        _out = Math.round(final*_t.damage_mult);
        this.e.bus.emit('combat:readDamage',
          {attacker:atk, reads:atk.reads, tier:_t.name, base:final, dealt:_out});
      }
    }
    d.hp=Math.max(0,d.hp-_out); d.dmgTaken=(d.dmgTaken||0)+_out;
    d.meter=Math.min(M.max, d.meter+(blocking?M.onBlockTake:M.onHitTake));
    atk.meter=Math.min(M.max, atk.meter+(blocking?M.onBlockGive:M.onHitGive));
    if(blocking){
      d.vx=pushback*0.35*atk.facing; d.blockedRecently=90;
      this.e.bus.emit('combat:block',{defender:d,attacker:atk,damage:final});
    } else {
      d.state=STATE.HITSTUN; d.stun=hitstun+(move.stunBonus||0); d.move=null; d.chainIdx=0;
      d.vx=pushback*atk.facing;
      if(spike && d.y<this.cfg.physics.ground){ d.vy=10; d.spiked=true; }
      else d.vy = launcher ? -11.5 : (knockdown ? -6 : (d.y<this.cfg.physics.ground ? -3.5 : -1.6));
      if(knockdown) d.pendingDown=true;
      atk.combo++; atk.comboT=54;
      const heavy = move.hitstop==='heavy';
      this.e.hitstop = counter ? C.hitstopCounter : (heavy ? C.hitstopHeavy : C.hitstopLight);
      this.e.bus.emit('combat:hit',{attacker:atk,defender:d,damage:final,counter,heavy,otg,scale});
      if(counter) this.e.bus.emit('combat:counter',{attacker:atk,defender:d});
      this.e.bus.emit('combat:shake',{amount:Math.min(13,pushback+3)});
    }
    if(d.hp<=0) this._ko(d, atk);
    return !blocking;
  }
  _ko(loser, winner){
    loser.state=STATE.KO; loser.koStart=loser.animT; loser.vy=-9.5; loser.vx=6.5*winner.facing;
    this.state.phase='ko'; this.state.koT=150;
    this.e.slowmo=55;
    this.e.bus.emit('combat:ko',{loser,winner});
  }
  _endRound(){
    const s=this.state;
    const winner = s.fighters[0].state===STATE.KO ? s.fighters[1] : s.fighters[0];
    winner.rounds++;
    this.e.bus.emit('combat:roundEnd',{winner});
    if(winner.rounds>=this.cfg.rounds.toWin){
      s.phase='matchOver';
      this.e.bus.emit('combat:matchEnd',{winner, loser:s.fighters[1-winner.index]});
      return; }
    s.round++; this.resetRound();
  }

  /* ---------------- free movement / attack initiation ---------------- */
  _tickFree(f,foe,input){
    const P=this.cfg.physics, M=this.cfg.meter, C=this.cfg.combat;
    const onGround=f.y>=P.ground;
    for(const b of ['light','heavy','special'])
      if(f.buffer.pressed(input,b)) f.buffer.push(b, f.animT);
    if(f.dashT>0){
      f.dashT--; f.x+=f.dashDir*P.dashSpeed*f.speed;
      if(f.animT%2===0) f.ghosts.push({x:f.x,y:f.y,life:10});
      if(f.dashT===0) f.vx=0;
      this._tryStart(f,foe,input);
      this.phys.clampX(f);
      if(f.state!==STATE.ATTACK) f.facing = foe.x>=f.x?1:-1;
      return; }
    if(input.down && onGround){
      if(f.state!==STATE.BLOCK) f.blockStartFrame=f.animT;
      f.state=STATE.BLOCK; f.vx=0;
      return; }
    if(f.state===STATE.BLOCK) f.state=STATE.IDLE;
    let mv=0; if(input.left)mv=-1; if(input.right)mv=1;
    for(const d of [-1,1]){
      const btn = d===-1?'left':'right';
      if(f.buffer.pressed(input,btn)){
        if(f.lastTap.dir===d && f.animT-f.lastTap.t<15 && onGround){ f.dashT=P.dashFrames; f.dashDir=d; }
        f.lastTap={dir:d,t:f.animT}; } }
    if(input.dash && onGround && f.dashT<=0 && mv!==0){ f.dashT=P.dashFrames; f.dashDir=mv; }
    f.vx=mv*P.walkSpeed*f.speed; f.x+=f.vx;
    if(mv!==0 && onGround) f.state=STATE.WALK; else if(onGround) f.state=STATE.IDLE;
    if(input.up && onGround){ f.vy=P.jumpVel; f.state=STATE.JUMP; }
    if(!onGround) f.state=STATE.JUMP;
    f.vy+=P.gravity; f.y+=f.vy;
    if(f.y>P.ground){ f.y=P.ground; f.vy=0; f.landT=7; if(f.state===STATE.JUMP) f.state=STATE.IDLE; }
    this._tryStart(f,foe,input);
    if(f.state!==STATE.ATTACK) f.facing = foe.x>=f.x?1:-1;
    this.phys.clampX(f);
  }
  _tryStart(f,foe,input){
    const M=this.cfg.meter, P=this.cfg.physics;
    const air=f.y<P.ground;
    const fwd=(f.facing===1&&input.right)||(f.facing===-1&&input.left);
    if(f.buffer.pressed(input,'meter') && f.meter>=M.bbCost && !air){
      f.meter=0; this._start(f,'blockbuster'); return true; }
    const buffered=f.buffer.consume(f.animT);
    const want=b=>f.buffer.pressed(input,b)||buffered===b;
    if(want('special') && f.specCd<=0 && !air){
      const id=fwd?'specialF':'special';
      const d=this.fd.move(f.id,id); if(d){ f.specCd=d.cooldown||95; this._start(f,id); return true; } }
    /* GRAB — light+heavy together, the genre-standard input. Forward selects
       the alternate throw. Checked BEFORE light so the grab wins the overlap. */
    if(!air && f.buffer.pressed(input,'light') && f.buffer.pressed(input,'heavy')){
      const id = fwd ? 'throwF' : 'throw';
      if(this.fd.move(f.id,id)){ this._start(f,id); return true; }
    }
    if(want('light')){ this._start(f, air?'airL':this.fd.chain(f.id,'light')[0]); return true; }
    if(want('heavy')){ this._start(f, air?'airH':(fwd?'smash':'heavy')); return true; }
    return false;
  }
  _start(f, moveId){
    const def=this.fd.move(f.id, moveId); if(!def) return;
    f.state = (def.type==='throw') ? STATE.GRAB : STATE.ATTACK;
    f.hitDone=false; f.grabDone=false; f.move={id:moveId, t:0};
    if(def.type==='blockbuster') this._runScript(f,def,true);
    this.e.bus.emit('combat:moveStart',{fighter:f, move:def});
  }

  /* ---------------- projectiles ---------------- */
  _tickProjectiles(){
    const s=this.state, P=this.cfg.physics;
    for(const p of s.projectiles){
      p.life--; p.x+=p.vx; p.y+=p.vy;
      if(p.grav) p.vy+=p.grav;
      p.spin=(p.spin||0)+0.4*Math.sign(p.vx||1);
      if(p.cosmetic || p.damage<=0) continue;
      const foe=s.fighters[1-p.owner.index];
      if(p.life>0 && Math.abs(p.x-foe.x)<foe.w/2+16 &&
         p.y>foe.y-foe.hgt-30 && p.y<foe.y+8){
        p.life=0;
        this.applyHit(foe,p.owner,{damage:p.damage,pushback:p.def.pushback||4,
          hitstun:p.def.hitstun||16, hitstop:'light'}); } }
    s.projectiles=s.projectiles.filter(p=>p.life>0 && p.x>-60 && p.x<this.cfg.view.w+60 && p.y<this.cfg.view.h+40);
  }
  addProjectile(p){ this.state.projectiles.push(p); }
  snapshot(){
    const s=this.state; if(!s) return null;
    return { round:s.round, roundT:s.roundT, timer:s.timer, phase:s.phase, koT:s.koT,
      fighters:s.fighters.map(f=>f.snapshot()),
      projectiles:s.projectiles.map(p=>({...p, owner:p.owner.index})) };
  }
  restore(snap){
    const s=this.state; if(!s||!snap) return;
    Object.assign(s,{round:snap.round,roundT:snap.roundT,timer:snap.timer,phase:snap.phase,koT:snap.koT});
    snap.fighters.forEach((fs,i)=>s.fighters[i].restore(fs));
    s.projectiles=snap.projectiles.map(p=>({...p, owner:s.fighters[p.owner]}));
  }
}
