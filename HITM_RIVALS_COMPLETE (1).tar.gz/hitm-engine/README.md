# HITM RIVALS — Engine

The permanent foundation of the HITM fighting-game franchise.
Not a prototype. Built to carry 30+ fighters, 25 stages, story/arcade/versus,
online rollback, training, replay theater, trials, spectator, mods, and DLC.

## Run

    python3 tools/slice_rig.py    # sprites -> 12-part bone rigs + atlases
    python3 tools/author_anims.py # personality profiles -> keyframed clips
    python3 build.py              # bundle engine + data + assets -> dist/index.html
    node tests/smoke.mjs          # 90 headless integrity checks

Open `dist/index.html` in any browser. No server, no install, no network.

## The one rule

**Nothing is hardcoded.** Fighters, moves, frame data, stages, cameras, VFX,
and AI personalities are all JSON. The engine is a machine that reads data.
Adding a fighter is adding a folder — no engine code is written, ever.

## Layout

    engine/         systems — each owns one responsibility, talks only via EventBus
      core/         Engine loop, EventBus, RNG, Resources, SaveSystem, CharacterManager
      input/        device abstraction, per-fighter InputBuffer, replay recording
      combat/       Fighter (state), FrameData (move defs), CombatSystem (rules)
      physics/      gravity, walls, wall/ground bounce resolution
      render/       Renderer (2-pass), SkeletonSystem (cutout bone rig),
                    AnimationSystem (clip selection + crossfade), SpriteSystem
      camera/       cinematic director, profile-driven
      vfx/          effect graph with per-effect budgets + LOD
      audio/        layered impact synthesis, voice-bank ready
      ai/           personality-driven, deterministic, no input reading
      stage/        data-driven stages, ambient layers, reflections
      ui/           HUD + screens
      replay/       deterministic record/playback + rollback ring buffer
      debug/        F1–F5 dev tooling, perf monitor
    data/           ALL content
      characters/<id>/  character.json · moves.json · ai.json
      stages/<id>/      stage.json
      system/           game.json · vfx.json · cameras.json
    assets/sprites/ art
    dist/           built single-file game
    tools/          slice_rig.py (sprite -> bone rig) · author_anims.py (clips)
    tests/          headless integrity suite

## Adding a fighter

1. `data/characters/<id>/character.json` — identity, stats, sprite key, anchors
2. `data/characters/<id>/moves.json` — every move with full frame data
3. `data/characters/<id>/ai.json` — personality weights
4. `data/characters/<id>/rig.json` — 12 part rects + bone hierarchy
5. `assets/sprites/<id>.png`
6. Add a personality profile to `tools/author_anims.py`
7. Append `"<id>"` to `roster` in `data/system/game.json`
8. `python3 tools/slice_rig.py && python3 tools/author_anims.py && python3 build.py`

That is the entire process. See `CHARACTER_PIPELINE.md`.

## Controls

Move A/D · Dash double-tap · Jump W · Block S · Light J · Heavy K · →+K smash
Special L · →+L alt special · SPACE = blockbuster (100) / flare break (50, mid-attack) / burst (100, in hitstun)

Dev: F1 overlay · F2 hitboxes · F3 pause · F4 frame advance · F5 frame-data table
