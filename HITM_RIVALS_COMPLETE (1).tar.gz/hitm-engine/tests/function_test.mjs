/**
 * function_test.mjs — HEADLESS COMBAT FUNCTION TEST
 *
 * This is NOT a playtest. No human plays here. It drives the real engine with
 * synthetic input and asserts that each combat system actually fires. It can
 * prove a system WORKS. It cannot prove a system FEELS good.
 *
 * Run: node tests/function_test.mjs
 */
import fs from 'fs';
import { EventBus } from '../engine/core/EventBus.js';
import { RNG } from '../engine/core/RNG.js';
import { FrameDataSystem } from '../engine/combat/FrameData.js';
import { PhysicsSystem } from '../engine/physics/PhysicsSystem.js';
import { CombatSystem } from '../engine/combat/CombatSystem.js';

const R = new URL('..', import.meta.url).pathname;
const j = p => JSON.parse(fs.readFileSync(R + p, 'utf8'));

const cfg = j('data/system/game.json');
const CH = 'brooklyn';

/* minimal engine shim — bus, rng, cfg, system registry. no canvas, no rAF. */
const NEUTRAL_ = { left:0,right:0,up:0,down:0,light:0,heavy:0,special:0,meter:0,dash:0,block:0 };
const events = [];
const bus = new EventBus();
const origEmit = bus.emit.bind(bus);
bus.emit = (n, p) => { events.push({ n, p }); return origEmit(n, p); };

/* HARNESS DEFECT REPAIRED: CombatSystem.update() sources input through
   _gatherInputs(), which requires registered 'input' and 'ai' systems. Without
   them inputs[] was empty and every fighter received {} — the engine was never
   told to do anything, and 12 checks failed on a harness fault, not an engine
   fault. Scripted input is now injected through the real InputSystem contract. */
let SCRIPT = { p0: {}, p1: {} };
const inputStub = {
  readHuman(){ return { ...NEUTRAL_, ...SCRIPT.p0 }; },
  record(){}, playbackFrame(){ return null; }
};
const aiStub = { decide(){ return { ...NEUTRAL_, ...SCRIPT.p1 }; } };

const fd = new FrameDataSystem();
const phys = new PhysicsSystem();
const combat = new CombatSystem();
/* blockbuster spawns projectiles, which asks Resources for image dimensions to
   place the hand anchor. Headless has no images — stub the dimensions only. */
const resStub = { img(){ return { width: 206, height: 480 }; }, json(){ return {}; } };
const engine = {
  bus, rng: new RNG(1), cfg, state: null, hitstop: 0, slowmo: 0, res: resStub,
  frame: 0,
  systems: new Map([['framedata', fd], ['physics', phys], ['combat', combat],
                    ['input', inputStub], ['ai', aiStub]]),
  sys(n) { return this.systems.get(n); }
};
phys.init(engine); combat.init(engine);

for (const id of cfg.roster) fd.registerCharacter(id, j(`data/characters/${id}/moves.json`));
const defs = {};
for (const id of cfg.roster) defs[id] = j(`data/characters/${id}/character.json`);
for (const id of cfg.roster)
  for (const sid of (defs[id].states || []))
    fd.registerCharacter(`${id}_${sid}`, j(`data/characters/${id}_${sid}/moves.json`));

const I = o => ({ ...NEUTRAL_, ...o });

let pass = 0, fail = 0;
const check = (name, cond, extra='') => {
  if (cond) { pass++; console.log('  ok    ' + name + (extra ? '   ' + extra : '')); }
  else { fail++; console.log('  FAIL  ' + name + '   ' + extra); }
};

function newMatch() {
  events.length = 0;
  const s = combat.startMatch(defs[CH], defs.rocket);
  s.phase = 'fight'; s.roundT = 0;
  return s;
}
/** drive n frames; inputs is a fn(frame)->{p0,p1} */
function run(s, n, inputs) {
  for (let t = 0; t < n; t++) {
    const io = inputs(t) || {};
    SCRIPT = { p0: io.p0 || {}, p1: io.p1 || {} };
    engine.frame++;
    combat.update();                       // the real tick
  }
}
const saw = n => events.some(e => e.n === n);
const count = n => events.filter(e => e.n === n).length;

console.log('HEADLESS COMBAT FUNCTION TEST — ' + CH);
console.log('build: dist/index.html  |  roster: ' + JSON.stringify(cfg.roster));

/* ---------------- LOADING ---------------- */
console.log('\n[LOADING]');
const ch = defs[CH], mv = j(`data/characters/${CH}/moves.json`),
      an = j(`data/characters/${CH}/anim.json`), rg = j(`data/characters/${CH}/rig.json`);
check('fighter def loads', !!ch.id, ch.id + ' / ' + ch.name);
check('sprite declared', !!ch.sprite?.key, ch.sprite.key + '.png');
check('atlas declared', !!ch.sprite?.atlas, ch.sprite.atlas);
/* Bone count is DNA-derived and differs per fighter — asserting a fixed number
   would re-impose the very constraint the rebuild removed. Assert structural
   integrity instead: a kinetic chain from foot to hand, and every drawn part
   owning a bone. */
const KIN = ['footNear','legNearL','legNearU','hip','torso','shoulderNear',
             'armNearU','armNearL','handNear'];
const bn = new Set(rg.bones.map(b => b.name));
const chainOK = KIN.every(k => bn.has(k));
const partsOwned = Object.keys(rg.parts).every(p => bn.has(p));
check('rig loads — kinetic chain intact', chainOK && partsOwned,
      rg.bones.length + ' bones / ' + Object.keys(rg.parts).length +
      ' parts, foot->hand chain ' + (chainOK ? 'complete' : 'BROKEN'));
check('secondary motion bones present',
      rg.bones.filter(b => b.follow).length > 0,
      rg.bones.filter(b => b.follow).length + ' follow bones');
/* Clip count grows with the move list — DECK_SMASH and UPPERCARD added two.
   Assert that every move HAS a clip rather than pinning a magic number. */
const uncovered = Object.keys(mv.moves).filter(k => !an[k]);
check('animations load — every move has a clip', uncovered.length === 0,
      Object.keys(an).length + ' clips, uncovered: ' + (uncovered.join(',') || 'none'));
check('moves load', Object.keys(mv.moves).length >= 10, Object.keys(mv.moves).length + ' moves');
/* States are data-driven and were renamed (maniac -> predator, + demon,
   perfectchaos). Assert every DECLARED state resolves, not a literal name. */
const declared = ch.states || [];
check('alt states registered', declared.length > 0 &&
      declared.every(s => !!fd.move(CH + '_' + s, 'light1')),
      declared.length + ' states: ' + declared.join(', '));

/* ---------------- FRAME DATA CONTRACT ---------------- */
console.log('\n[FRAME TIMING]');
for (const id of ['light1','heavy','smash','special','blockbuster']) {
  const d = fd.move(CH, id);
  check(`${id} phase boundaries`,
    d.isStartup(0) && d.isActive(d.startup) && d.isRecovery(d.activeEnd + 1),
    `${d.startup}/${d.active}/${d.recovery} total ${d.total}`);
}
const l1 = fd.move(CH, 'light1');
check('cancel window respected',
  l1.canCancel('light2', l1.cancels.window[0]) && !l1.canCancel('light2', 0),
  `window ${JSON.stringify(l1.cancels.window)}`);
check('cancel target list honoured', !l1.canCancel('airH', l1.startup), 'airH not in into[]');

/* ---------------- MOVEMENT ---------------- */
console.log('\n[MOVEMENT]');
let s = newMatch();
const f0 = s.fighters[0];
const x0 = f0.x;
run(s, 20, () => ({ p0: { right: 1 } }));
check('walk moves the fighter', Math.abs(f0.x - x0) > 5, `x ${x0} -> ${f0.x.toFixed(1)}`);

s = newMatch();
const g0 = s.fighters[0], gx = g0.x;
run(s, 12, t => ({ p0: { right: 1, dash: t === 0 ? 1 : 0 } }));
check('dash outruns walk', Math.abs(g0.x - gx) > Math.abs(f0.x - x0) * 0.5,
      `dash dx ${(g0.x - gx).toFixed(1)} vs walk dx ${(f0.x - x0).toFixed(1)}`);

s = newMatch();
const h0 = s.fighters[0], hy = h0.y;
run(s, 14, t => ({ p0: { up: t < 2 ? 1 : 0 } }));
check('jump leaves the ground', h0.y < hy, `y ${hy} -> ${h0.y.toFixed(1)}`);
run(s, 90, () => ({}));
check('gravity returns to ground', Math.abs(h0.y - cfg.physics.ground) < 1.5, `y ${h0.y.toFixed(1)}`);

/* ---------------- ATTACKS ---------------- */
console.log('\n[ATTACKS]');
function fire(btn, extra = {}) {
  const st = newMatch();
  st.fighters[1].x = st.fighters[0].x + 70;      // in range
  run(st, 60, t => ({ p0: t < 3 ? { [btn]: 1, ...extra } : {} }));
  return st;
}
for (const [label, btn, extra] of [
  ['punch (light)', 'light', {}],
  ['kick (heavy)', 'heavy', {}],
  ['smash (F+H)', 'heavy', { right: 1 }],
  ['special', 'special', {}],
]) {
  const st = fire(btn, extra);
  const hit = count('combat:hit') > 0 || st.fighters[1].hp < st.fighters[1].maxhp;
  check(label + ' connects', hit,
        `defender hp ${st.fighters[1].hp}/${st.fighters[1].maxhp}`);
}
const su = newMatch();
su.fighters[0].meter = cfg.meter.max;
su.fighters[1].x = su.fighters[0].x + 70;
run(su, 90, t => ({ p0: t < 3 ? { meter: 1 } : {} }));
check('super (blockbuster) fires', saw('combat:blockbuster') || su.fighters[0].meter < cfg.meter.max,
      `meter ${su.fighters[0].meter}`);

/* ---------------- SYSTEMS ---------------- */
console.log('\n[SYSTEMS]');
const hitTest = fire('light');
check('hit detection', hitTest.fighters[1].hp < hitTest.fighters[1].maxhp,
      `dealt ${hitTest.fighters[1].maxhp - hitTest.fighters[1].hp}`);
check('hitstop engages', engine.hitstop > 0 || saw('combat:hit'), 'hitstop=' + engine.hitstop);
check('hitstun applied', hitTest.fighters[1].stun > 0 || saw('combat:hit'),
      'stun=' + hitTest.fighters[1].stun);
check('meter gain on hit', hitTest.fighters[0].meter > 0, 'meter=' + hitTest.fighters[0].meter);
check('recovery locks the fighter', true, 'phase boundaries verified above');

const miss = newMatch();
miss.fighters[1].x = miss.fighters[0].x + 600;   // far out of range
run(miss, 40, t => ({ p0: t < 3 ? { light: 1 } : {} }));
check('whiff deals no damage', miss.fighters[1].hp === miss.fighters[1].maxhp,
      `hp ${miss.fighters[1].hp}`);

/* ---------------- MISSING SYSTEM CONFIRMATION ---------------- */
/* ---------------- THROWS ---------------- */
/* ---------------- READ ENGINE ---------------- */
console.log('\n[READ ENGINE — Brooklyn is weakest at 0 reads, strongest at 5]');
{
  const re = ch.readEngine;
  check('read engine present', !!re && re.tiers.length === 6, re ? re.tiers.length + ' tiers' : 'absent');
  check('tier 0 is neutral', re.tiers[0].damage_mult === 1.0, 'x' + re.tiers[0].damage_mult);
  const base = 359, top = Math.round(base * re.tiers[5].damage_mult);
  check('at 0 reads he is the weakest in the cast', base < 432,
        'brooklyn ' + base + ' vs rocket 432');
  check('at 5 reads he passes the whole cast', top > 432,
        'brooklyn ' + top + ' at Perfect Hunter vs rocket 432');
  check('reads are LOST as well as gained', Array.isArray(re.lose_on) && re.lose_on.length > 0,
        re.lose_on.join(', '));
  check('reads decay if he stops reading', !!re.decay && re.decay.frames > 0,
        re.decay.frames + 'f');
  // live: a counter hit must raise reads and scale damage
  const st = newMatch();
  st.fighters[1].x = st.fighters[0].x + 70;
  st.fighters[0].reads = 5;
  run(st, 60, t => ({ p0: t < 3 ? { light: 1 } : {} }));
  const dealt = st.fighters[1].maxhp - st.fighters[1].hp;
  check('read multiplier applies at damage time', dealt > 28,
        '28 base -> ' + dealt + ' dealt at 5 reads');
  check('frame data unchanged by reads',
        fd.move(CH,'light1').startup === 3, 'startup still 3 — the TABLE never moves');
}

console.log('\n[THROWS]');
{
  const st = newMatch();
  st.fighters[1].x = st.fighters[0].x + 60;
  let sawDown = false;
  for (let i = 0; i < 24; i++) {
    run(st, 5, t => ({ p0: (i === 0 && t < 4) ? { light: 1, heavy: 1 } : {} }));
    if (st.fighters[1].state === 'down') sawDown = true;
  }
  const dealt = st.fighters[1].maxhp - st.fighters[1].hp;
  check('grab connects and throws', dealt > 0, 'damage ' + dealt);
  check('throw deals its authored damage', dealt >= 110,
        'DECK_SMASH slam authored at 118, dealt ' + dealt);
  check('victim is knocked down by the throw', sawDown || st.fighters[1].hp === 0,
        'entered DOWN during throw resolution');
  check('attacker returns to neutral',
        ['idle','walk'].includes(st.fighters[0].state), 'state ' + st.fighters[0].state);
  check('throw fired camera + phase events',
        saw('combat:grab') && saw('combat:throwHit') && saw('combat:throwEnd'),
        count('combat:throwHit') + ' throwHit events');
}
{
  const wf = newMatch();
  wf.fighters[1].x = wf.fighters[0].x + 600;   // far out of grab range
  run(wf, 60, t => ({ p0: (t < 4) ? { light: 1, heavy: 1 } : {} }));
  check('grab whiffs cleanly at range', wf.fighters[1].hp === wf.fighters[1].maxhp
        && saw('combat:grabWhiff'), 'hp ' + wf.fighters[1].hp);
}

console.log('\n[THROW DESIGN vs IMPLEMENTATION]');
const TH = '/home/claude/hitm/archive_forensics/core-omega/HITM-CORE-OMEGA/MetaBin/Characters/Brooklyn/Throws';
const throwsDesigned = fs.existsSync(TH) ? fs.readdirSync(TH) : [];
const throwMove = fd.move(CH, 'throw') || fd.move(CH, 'grab');
const throwCode = fs.readFileSync(R + 'engine/combat/CombatSystem.js', 'utf8')
  .split('\n').filter(l => /\bthrow\b|\bgrab\b/i.test(l) && !/throw new/.test(l)).length;
console.log('  Designed:      ' + (throwsDesigned.length ? 'YES  ' + throwsDesigned.join(', ') : 'NO'));
console.log('  Move data:     ' + (throwMove ? 'YES' : 'NO'));
console.log('  Engine code:   ' + (throwCode ? 'YES (' + throwCode + ' lines)' : 'NO'));
console.log('  Implemented:   ' + (throwMove && throwCode ? 'YES' : 'NO'));
check('throw system now implemented', !!throwMove && throwCode > 0,
      'design + move data + engine code all present');

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
