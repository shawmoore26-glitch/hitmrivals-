/**
 * Headless smoke test — validates the data layer and frame-data contracts
 * without a browser. Run: node tests/smoke.mjs
 */
import fs from 'fs';
const R = new URL('..', import.meta.url).pathname;
const j = p => JSON.parse(fs.readFileSync(R+p,'utf8'));

let pass=0, fail=0;
const check=(name,cond,extra='')=>{ if(cond){pass++;console.log('  ok  '+name);}
  else {fail++;console.log('  FAIL '+name+' '+extra);} };

const game = j('data/system/game.json');
check('game.json roster non-empty', game.roster.length>0);
check('meter costs coherent', game.meter.breakCost < game.meter.bbCost);
check('scaling floor sane', game.combat.scaleMin>0 && game.combat.scaleMin<1);

for(const id of game.roster){
  console.log('\n['+id+']');
  const ch = j(`data/characters/${id}/character.json`);
  const mv = j(`data/characters/${id}/moves.json`);
  const ai = j(`data/characters/${id}/ai.json`);
  check('character.json id matches folder', ch.id===id);
  check('has sprite anchors', !!ch.sprite.anchors.hand);
  check('has stats', ch.stats.speed>0 && ch.stats.power>0);
  check('ai profile complete', ['aggression','zoning','dashLove','whiffPunish']
    .every(k=>typeof ai[k]==='number'));
  // required move set
  const required=['light1','light2','light3','heavy','smash','airL','airH','special','specialF','blockbuster'];
  const missing=required.filter(m=>!mv.moves[m]);
  check('all required moves present', missing.length===0, missing.join(','));
  // frame data integrity
  for(const [mid,m] of Object.entries(mv.moves)){
    const total=(m.startup||0)+(m.active||0)+(m.recovery||0);
    if(!(total>0)){ check(mid+' has positive total frames', false); continue; }
    if(m.cancels && m.cancels.window){
      const [a,b]=m.cancels.window;
      if(b>total+1) check(mid+' cancel window within move', false, `${b}>${total}`);
    }
  }
  check('frame data integrity', true);
  // chain resolves
  const chain=mv.chains.light||[];
  check('light chain resolves to real moves', chain.every(c=>!!mv.moves[c]), chain.join('>'));
  // blockbuster costs meter
  check('blockbuster costs full meter', mv.moves.blockbuster.meterCost===game.meter.bbCost);
  // projectile refs exist
  for(const [mid,m] of Object.entries(mv.moves)){
    for(const sp of (m.spawn||[]))
      check(mid+' projectile "'+sp.projectile+'" defined',
        !!(mv.projectiles && mv.projectiles[sp.projectile]));
    for(const st of (m.script||[]))
      if(st.projectile) check(mid+' script projectile defined',
        !!(mv.projectiles && mv.projectiles[st.projectile]));
  }
}

// ---- rig + animation integrity ----
for(const id of game.roster){
  console.log('\n['+id+' rig]');
  const rig=j(`data/characters/${id}/rig.json`);
  const parts=j(`data/characters/${id}/parts.json`);
  const anim=j(`data/characters/${id}/anim.json`);
  const mv=j(`data/characters/${id}/moves.json`);
  const boneNames=parts.bones.map(b=>b.name);
  check('bone parents resolve', parts.bones.every(b=>!b.parent||boneNames.includes(b.parent)));
  check('exactly one root', parts.bones.filter(b=>!b.parent).length===1);
  check('every drawOrder part exists', parts.drawOrder.every(p=>!!parts.parts[p]));
  check('every bone part exists', parts.bones.every(b=>!b.part||!!parts.parts[b.part]));
  check('atlas frames present', Object.values(parts.parts).every(p=>Array.isArray(p.frame)&&p.frame.length===4));
  const required=['idle','walk','jumpUp','jumpDown','land','block','hurt','down','ko','dash','intro','victory'];
  check('core clips present', required.every(c=>!!anim[c]), required.filter(c=>!anim[c]).join(','));
  // every attack move needs a clip whose length matches its frame data
  for(const [mid,m] of Object.entries(mv.moves)){
    if(!anim[mid]) { check('clip for move '+mid, false); continue; }
    const total=(m.startup||0)+(m.active||0)+(m.recovery||0);
    check('clip "'+mid+'" length matches frame data', anim[mid].len===total, `${anim[mid].len} vs ${total}`);
  }
  // keys must be integers on the 60Hz grid, and inside the clip
  let offGrid=0, outOfRange=0;
  for(const [cn,clip] of Object.entries(anim))
    for(const tr of Object.values(clip.tracks))
      for(const k of tr){ if(!Number.isInteger(k[0])) offGrid++; if(k[0]>clip.len) outOfRange++; }
  check('all keyframes on integer frames', offGrid===0, offGrid+' off-grid');
  check('all keyframes within clip length', outOfRange===0, outOfRange+' overrun');
  check('animated bones are real bones',
    Object.values(anim).every(c=>Object.keys(c.tracks).every(b=>boneNames.includes(b))));
}

const stage=j('data/stages/hitm_city/stage.json');
check('\nstage ground matches physics', stage.ground===game.physics.ground);
const vfx=j('data/system/vfx.json');
check('vfx budgets declared', Object.values(vfx).every(v=>typeof v.budget==='number'));
const cams=j('data/system/cameras.json');
check('camera profiles present', ['fight','cinematic','ko','punch'].every(k=>!!cams[k]));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail?1:0);
