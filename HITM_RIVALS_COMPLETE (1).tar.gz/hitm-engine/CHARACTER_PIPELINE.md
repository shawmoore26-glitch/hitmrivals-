# Character Production Bible — Import Spec

Deliver a character as a folder. The engine imports it with zero code changes.

## 1. Art

    assets/sprites/<id>.png

**Today (cutout rig mode):** one full-body still, transparent background.
Cut cleanly — a flat black or single-color backdrop in the source render
gives a perfect extraction (this is why the Brooklyn sheet cut so well).

The still is sliced into a 12-part bone rig by `tools/slice_rig.py`, driven by
`rig.json`. Parts are feathered at the seams so joints blend under rotation.
Where the source art is cropped (a bust shot with no legs), `synthLegs` builds
trousers and shoes from the character's OWN fabric pixels — no invented color.
Animations are authored as integer-frame keyframe tracks by `tools/author_anims.py`.

    python3 tools/slice_rig.py      # sprite -> parts atlas + parts.json
    python3 tools/author_anims.py   # personality profile -> anim.json
    python3 build.py                # bundle
    node tests/smoke.mjs            # 90 checks incl. rig + clip integrity

**Target (hand-drawn frames):** a packed atlas plus frame map, replacing the
cutout rig entirely for that character. Both paths coexist; a character with
`sprite.clips` uses drawn frames, one without uses the bone rig.
Recommended minimum clip set per fighter:

    idle        6–8 frames, looping
    walkFwd     6 frames        walkBack    6 frames
    dash        4 frames        jumpUp/Down 2 + 2
    light1/2/3  4–6 frames each (anticipation, contact, follow-through)
    heavy       8 frames        smash       9 frames
    airL / airH 5 / 6 frames
    hurt        3 frames        down        2      ko          4
    block       2 frames        special ×2  8–10 each
    blockbuster 20–30 frames
    intro       12–20           victory     16–24   taunt      12

That is roughly 180–260 frames per fighter for full coverage. The engine is
built assuming eventual growth to 1,500–3,000 with alternates and layers.

Declare in `character.json`:

    "sprite": {
      "key": "<id>",
      "anchors": { "hand": [0.80,0.43], "alt": [0.24,0.47] },
      "atlas":  { "image": "<id>_atlas", "frames": { "idle_00": [x,y,w,h] } },
      "clips":  { "idle": { "frames": ["idle_00","idle_01"], "fps": 12, "loop": true } },
      "layers": ["body","hair","cape","weapon","fx"]
    }

Anchors are normalized [x,y] within the sprite box; VFX and projectiles spawn
from them, so a lantern glow or card fan tracks the actual hand.

## 2. character.json

    id, name, faction, archetype, accent (hex)
    stats: { speed, power, healthMult }     // 1.0 = baseline
    sprite: { key, anchors, atlas?, clips?, layers? }
    palettes: [ { id, name } ]              // alt colors / skins

## 3. moves.json

Every move is data. Fields the engine reads:

    startup, active, recovery               // frames — total is derived
    damage, hitstun, blockstun, pushback
    range, height                            // hitbox extents
    launcher, knockdown, spike, wallBounce   // reaction flags
    hitstop: "light" | "heavy"
    meterGain, cooldown, meterCost
    context: "ground" | "air"
    cancels: { into: [moveIds], window: [startFrame, endFrame] }
    selfVelocityY, rush: {...}, teleport: {...}
    spawn: [ { projectile, count, spread, speed, damage, life, anchor } ]
    camera: "punch" | "cinematic", cameraFrames, flash, slowmo
    script: [ { at, repeat, every, action, ... } ]   // blockbuster choreography

`chains.light` defines the ground chain order.
`projectiles` defines any projectile the moves reference.

Script actions available: `spawnProjectile`, `zoneBurst`, `blitzPass`.
New actions are added once in `CombatSystem._scriptAction` and become
available to every future character.

## 4. ai.json

    personality: "rushdown" | "zoner" | "burst" | ...
    aggression, zoning, dashLove, whiffPunish, guardBreakRead   // 0..1
    reactionFrames

## 5. Register + verify

Append the id to `roster` in `data/system/game.json`, then:

    python3 build.py
    node tests/smoke.mjs

The suite verifies the required move set exists, cancel windows fall inside
move durations, chains resolve, projectile references exist, and blockbuster
meter cost matches the global economy.

## Pending canon fighters

King Hitm · Lady Luck · Nova · Reaper · Lady Liberty — art needed,
then each is a folder drop.
