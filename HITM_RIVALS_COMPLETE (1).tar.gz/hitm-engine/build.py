#!/usr/bin/env python3
"""
HITM RIVALS — build pipeline.
Bundles the modular ES-module engine + data + assets into a single
distributable HTML file. Preserves module boundaries in source; the
bundler only concatenates in dependency order and strips import/export
keywords (no transpiler dependency, no network at runtime).

Usage: python3 build.py [--out dist/index.html]
"""
import base64, json, os, re, sys

ROOT = os.path.dirname(os.path.abspath(__file__))

# Explicit dependency order — mirrors the import graph in engine/core/main.js.
MODULE_ORDER = [
    "engine/core/EventBus.js",
    "engine/core/RNG.js",
    "engine/core/Resources.js",
    "engine/core/Engine.js",
    "engine/core/SaveSystem.js",
    "engine/input/InputSystem.js",
    "engine/combat/FrameData.js",
    "engine/combat/Fighter.js",
    "engine/physics/PhysicsSystem.js",
    "engine/combat/CombatSystem.js",
    "engine/render/SpriteSystem.js",
    "engine/render/SkeletonSystem.js",
    "engine/render/AnimationSystem.js",
    "engine/camera/CameraSystem.js",
    "engine/vfx/VFXSystem.js",
    "engine/audio/AudioSystem.js",
    "engine/ai/AISystem.js",
    "engine/stage/StageSystem.js",
    "engine/ui/UISystem.js",
    "engine/render/Renderer.js",
    "engine/replay/ReplaySystem.js",
    "engine/debug/DebugSystem.js",
    "engine/core/CharacterManager.js",
    "engine/core/main.js",
]

IMPORT_RE = re.compile(r'^\s*import\s+.*?;\s*$', re.M)
EXPORT_RE = re.compile(r'^\s*export\s+(?=(class|function|const|let|var|async))', re.M)
EXPORT_CONST_RE = re.compile(r'^\s*export\s+const\s+', re.M)

def strip_modules(src):
    src = IMPORT_RE.sub('', src)
    src = EXPORT_CONST_RE.sub('const ', src)
    src = EXPORT_RE.sub('', src)
    return src

def b64(path, mime):
    with open(path, 'rb') as fh:
        return 'data:%s;base64,%s' % (mime, base64.b64encode(fh.read()).decode())

def collect_data():
    """All JSON becomes an embedded resource map keyed as the manifest expects."""
    d = {}
    d['game']    = json.load(open(f'{ROOT}/data/system/game.json'))
    d['vfx']     = json.load(open(f'{ROOT}/data/system/vfx.json'))
    d['cameras'] = json.load(open(f'{ROOT}/data/system/cameras.json'))
    d['stage']   = json.load(open(f'{ROOT}/data/stages/hitm_city/stage.json'))
    for cid in d['game']['roster']:
        d[f'char_{cid}']  = json.load(open(f'{ROOT}/data/characters/{cid}/character.json'))
        d[f'moves_{cid}'] = json.load(open(f'{ROOT}/data/characters/{cid}/moves.json'))
        d[f'ai_{cid}']    = json.load(open(f'{ROOT}/data/characters/{cid}/ai.json'))
        # Volume 17 — alternate combat states ship with their fighter.
        for sid in d[f'char_{cid}'].get('states', []):
            k = f'{cid}_{sid}'
            d[f'moves_{k}'] = json.load(open(f'{ROOT}/data/characters/{k}/moves.json'))
            d[f'ai_{k}']    = json.load(open(f'{ROOT}/data/characters/{k}/ai.json'))
        d[f'parts_{cid}'] = json.load(open(f'{ROOT}/data/characters/{cid}/parts.json'))
        d[f'anim_{cid}']  = json.load(open(f'{ROOT}/data/characters/{cid}/anim.json'))
    return d

def collect_images(game):
    imgs = {}
    for cid in game['roster']:
        imgs[cid] = b64(f'{ROOT}/assets/sprites/{cid}.png', 'image/png')
        imgs[f'{cid}_atlas'] = b64(f'{ROOT}/assets/parts/{cid}_atlas.png', 'image/png')
    imgs['city'] = b64(f'{ROOT}/assets/sprites/city.jpg', 'image/jpeg')
    return imgs

def build(out_path):
    engine_src = []
    for rel in MODULE_ORDER:
        path = os.path.join(ROOT, rel)
        with open(path) as fh:
            engine_src.append(f'\n/* ==== {rel} ==== */\n' + strip_modules(fh.read()))
    engine_js = '\n'.join(engine_src)

    data = collect_data()
    images = collect_images(data['game'])
    shell = open(f'{ROOT}/shell.html').read()

    html = shell.replace('/*__ENGINE__*/', engine_js)
    html = html.replace('"__JSON__"',   json.dumps(data))
    html = html.replace('"__IMAGES__"', json.dumps(images))

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, 'w') as fh:
        fh.write(html)
    print(f'built {out_path}  ({len(html)/1048576:.2f} MB, {len(MODULE_ORDER)} modules, '
          f'{len(data)} data files, {len(images)} images)')

if __name__ == '__main__':
    out = f'{ROOT}/dist/index.html'
    if '--out' in sys.argv:
        out = sys.argv[sys.argv.index('--out')+1]
    build(out)
