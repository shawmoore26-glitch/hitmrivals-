# HITM RIVALS — ENGINE HANDOFF

## What this is
Complete, self-contained fighting game engine + derivation pipeline.
No network dependencies. Python 3 + Node.js only.

## Rebuild from scratch
```
python3 tools/genome_compiler.py    # DNA -> moves.json, character.json, ai.json
python3 tools/rig_compiler.py       # DNA -> rig.json  (bone count varies per fighter)
python3 tools/slice_rig.py          # sprite -> parts.json + atlas
python3 tools/author_anims.py       # moves.json -> anim.json
python3 build.py                    # -> dist/index.html  (open in any browser)
```

## Gates — all must pass
```
node tests/smoke.mjs                91 checks
node tests/function_test.mjs        45 checks (drives the real engine headless)
python3 tools/genome_governor.py --strict
python3 tools/content_validate.py   does everything that should exist, exist?
python3 tools/kinetic_check.py      do attacks run foot -> hand?
python3 tools/rig_validate.py       measured seam/pivot integrity
python3 tools/silhouette_test.py    render fighters as pure silhouette
```

## The one rule
`data/identity/` is AUTHORED SOURCE. `data/characters/` is GENERATED OUTPUT.
The compiler raises on any attempt to read its own output.
Never hand-edit anything under data/characters/.

## Roster
brooklyn (+ predator, demon, perfectchaos)   static   rocket (+ beast)

## What is NOT done
- run / crouch / taunt: missing MECHANICS, not missing clips
- Brooklyn visual rebuild: blocked on new sprite art
- PlayerIntelligence/: 0 sessions. Nobody has played this.
