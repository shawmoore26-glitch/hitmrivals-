# Architecture

## Principles

1. **One responsibility per system.** CombatSystem never draws. Renderer never
   mutates. Camera knows nothing about hit detection.
2. **EventBus only.** Systems never hold references to each other's internals.
   A new system subscribes to existing events and needs no changes elsewhere.
3. **Data over code.** If a designer might want to change it, it is JSON.
4. **Deterministic simulation.** Fixed 60Hz timestep, seeded RNG, serializable
   state. This is the precondition for rollback netcode and replays.

## Loop

Fixed-timestep accumulator in `Engine._tick`:
- `update()` runs at exactly 60Hz (sim). Hitstop and slow-motion gate it.
- `render()` runs every animation frame (visual), decoupled from sim rate.
- Registration order in `main.js` is update order. Declared once.

## Event contract

    combat:matchStart {fighters}      combat:roundStart {round}
    combat:fightStart                 combat:roundEnd {winner}
    combat:matchEnd {winner,loser}    combat:moveStart {fighter,move}
    combat:hit {attacker,defender,damage,counter,heavy,otg,scale}
    combat:block / combat:perfectGuard / combat:counter / combat:otg
    combat:burst / combat:flareBreak / combat:blockbuster / combat:teleport
    combat:ko {loser,winner}          combat:spawnProjectile {...}
    combat:shake {amount}             combat:flash {frames}
    combat:cameraEvent {kind,fighter,frames}
    physics:wallBounce / physics:groundBounce {fighter}
    vfx:play {name,fighter,anchor}    render:aberration {frames}
    input:rawKey {key}                engine:postUpdate {frame}

Adding a subscriber is always safe. Adding an emit is additive.

## Rollback readiness

- `Engine.snapshot()` / `restore()` walk every system implementing those hooks.
- `ReplaySystem` keeps a 12-frame ring buffer of full snapshots.
- All simulation randomness flows through the seeded `RNG`.
- Inputs are recorded per frame, so a match = seed + input stream.
- `rollbackTo(frame)` restores and re-simulates. Wiring a transport (WebRTC)
  is the only remaining work for online play; the simulation is already ready.

## Sprite pipeline seam

`AnimationSystem.pose()` is the single seam. Today it returns procedural
squash/stretch/rotation for still-image puppets. When a character ships with
`sprite.atlas` + `sprite.clips`, `pose()` returns a null transform and
`SpriteSystem.frame()` resolves real frames instead. Nothing else changes.
Layers (body/hair/cape/weapon/fx) are declared in `character.json`.

## Performance

`DebugSystem` samples frame time and sets `VFXSystem.quality` (1 / 0.75 / 0.5),
which scales emitter counts. Every effect declares a budget in `vfx.json`;
the particle pool has a hard ceiling. Renderer uses a single offscreen world
buffer sampled once per frame by the camera.
