#!/usr/bin/env python3
"""
author_anims.py — animation authoring tool.

Emits data/characters/<id>/anim.json: keyframed bone tracks on INTEGER frames
(never seconds — off-grid keys are the #1 source of one-frame bugs in a fighter).

Each character has a personality profile that drives timing, amplitude, stance
and signature accents, so no two fighters share a pose curve. Track format:
  "boneName": [[frame, rotDeg, offX, offY], ...]
offsets are in display-height-normalized units. The engine lerps between keys.
"""
import json, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ---------------------------------------------------------------- personalities
P = {
  'brooklyn': dict(  # loose, cocky, springy — fastest hands in the city
    idleLen=84, breathe=2.2, sway=3.4, headLead=1.5, armIdle=6.0,
    walkLen=26, stride=19, armSwing=15, bob=0.016, lean=5,
    stance=-3, kneeBend=4, punchReach=0.10, punchRot=-64, recoil=1.5,
    hurtSnap=-22, koSpin=-84, dashLean=-14, jumpTuck=26, accentBone='armNearL'),
  'static': dict(    # twitchy, erratic, glitch-jittery
    idleLen=66, breathe=1.4, sway=1.6, headLead=4.5, armIdle=9.0,
    walkLen=30, stride=14, armSwing=10, bob=0.011, lean=3,
    stance=2, kneeBend=6, punchReach=0.085, punchRot=-54, recoil=2.4,
    hurtSnap=-27, koSpin=-72, dashLean=-11, jumpTuck=22, accentBone='armFarL'),
  'rocket': dict(    # heavy, prowling, deliberate — the hound
    idleLen=96, breathe=2.8, sway=2.0, headLead=1.0, armIdle=4.0,
    walkLen=32, stride=16, armSwing=12, bob=0.021, lean=7,
    stance=-6, kneeBend=5, punchReach=0.115, punchRot=-70, recoil=1.1,
    hurtSnap=-19, koSpin=-92, dashLean=-17, jumpTuck=24, accentBone='armFarL'),
}

def K(*keys):
    """Normalize [frame, rot] / [frame, rot, dx, dy] into 4-tuples."""
    out = []
    for k in keys:
        f, r = k[0], k[1]
        dx = k[2] if len(k) > 2 else 0
        dy = k[3] if len(k) > 3 else 0
        out.append([f, round(r, 2), round(dx, 4), round(dy, 4)])
    return out

def build(cid):
    import os as _os
    # DNA + genome available to every clip author in this scope (Phase 8)
    _genome = json.load(open(_os.path.join(
        _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),
        'data', 'identity', cid, 'combat_genome.json')))
    _dna = json.load(open(_os.path.join(
        _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),
        'data', 'identity', cid, 'character_dna.json')))['dna']
    p = P[cid]
    A = {}

    # ---------------- IDLE: breathing, weight sway, trailing head, live hands
    L = p['idleLen']; h = L // 2; q = L // 4
    # ── PERFORMANCE-DIRECTED CLIPS (Phase 3) ────────────────────────────────
    # These are HAND-KEYED against motion_bible.json, not generated from DNA
    # scalars. Phase 3 forbids formulas standing in for personality. The bible
    # sentence each clip serves is quoted above it.
    _bible = json.load(open(_os.path.join(
        _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),
        'data', 'identity', cid, 'motion_bible.json')))

    if cid == 'brooklyn':
        # "Weight on the front foot, shoulders low and loose, hands open and low.
        #  He is not guarding. Guarding would admit you might hit him."
        # "Slow and even. Two full cycles... the ONLY part of him that keeps a
        #  steady beat." -> hip breathes on a clean 2-cycle; everything else drifts.
        # "When his body sways one way the head lags behind, still pointed at you."
        A['idle'] = dict(loop=True, len=L, tracks={
            'hip':      K([0,0,0,0],[L//4,0,0.003,-0.0026],[L//2,0,0,0],
                          [3*L//4,0,-0.003,0.0020],[L,0,0,0]),
            'torso':    K([0,-2],[L//2,3],[L,-2]),
            # head lags the torso by a quarter cycle and never fully returns —
            # the gaze does not leave you
            'head':     K([0,3],[L//4,2],[L//2,-1],[3*L//4,2],[L,3]),
            'shoulderNear': K([0,-4],[L//2,-6],[L,-4]),   # shoulders LOW
            'shoulderFar':  K([0,-3],[L//2,-5],[L,-3]),
            'armNearU': K([0,-8],[L//2,-4],[L,-8]),       # hands low, open
            'armNearL': K([0,14],[L//2,10],[L,14]),
            'armFarU':  K([0,6],[L//2,3],[L,6]),
            'armFarL':  K([0,-11],[L//2,-7],[L,-11]),
            # 60/40 forward: the near leg carries, the far leg trails
            'legNearU': K([0,4],[L,4]), 'legFarU': K([0,-7],[L,-7]),
            'legNearL': K([0,-3],[L,-3]),'legFarL': K([0,-5],[L,-5]),
            'footNear': K([0,2],[L,2]),  'footFar': K([0,-3],[L,-3]),
        })
        # "Feet never cross and never fully commit. The rear foot catches up
        #  rather than passing." + "a half-beat pause at the top of each step"
        A['walk'] = dict(loop=True, len=26, tracks={
            'hip':      K([0,0,0,0],[7,0,0.010,-0.005],[13,0,0.006,0],
                          [20,0,0.010,-0.004],[26,0,0,0]),
            'torso':    K([0,4],[13,6],[26,4]),           # weight forward, always
            'head':     K([0,-2],[13,-3],[26,-2]),        # gaze level, locked
            'shoulderNear': K([0,-3],[13,-4],[26,-3]),
            'armNearU': K([0,-10],[7,-6],[13,-12],[20,-7],[26,-10]),
            'armNearL': K([0,16],[13,12],[26,16]),
            'armFarU':  K([0,8],[13,5],[26,8]),
            'armFarL':  K([0,-12],[13,-9],[26,-12]),
            # near foot leads, far foot CATCHES UP — it never passes
            'legNearU': K([0,-14],[7,16],[13,4],[20,-8],[26,-14]),
            'legFarU':  K([0,12],[7,-4],[13,-12],[20,10],[26,12]),
            'legNearL': K([0,-6],[7,-16],[13,-4],[26,-6]),
            'legFarL':  K([0,-10],[13,-6],[20,-14],[26,-10]),
            'footNear': K([0,4],[7,-6],[13,3],[26,4]),
            'footFar':  K([0,-4],[13,5],[20,-5],[26,-4]),
        })
        # "One frame of nothing, then he is simply further forward."
        # "Stops dead in the hunting stance. No skid, no overshoot, no settle."
        A['dash'] = dict(loop=False, len=9, tracks={
            'hip':      K([0,0,0,0],[1,0,0.002,0],[2,0,0.030,0.010],
                          [6,0,0.034,0.004],[9,0,0.030,0]),
            'torso':    K([0,4],[1,4],[2,16],[9,12]),      # no wind-up on frame 1
            'head':     K([0,-2],[2,-8],[9,-6]),
            'shoulderNear': K([0,-4],[2,-12],[9,-8]),
            'armNearU': K([0,-10],[2,-46],[9,-38]),
            'armNearL': K([0,16],[2,40],[9,34]),
            'armFarU':  K([0,8],[2,50],[9,42]),
            'armFarL':  K([0,-12],[2,-30],[9,-26]),
            'legNearU': K([0,4],[2,-30],[6,18],[9,6]),
            'legFarU':  K([0,-7],[2,26],[6,-16],[9,-8]),
            'legNearL': K([0,-3],[2,-18],[9,-4]),
            'legFarL':  K([0,-5],[2,-20],[9,-6]),
            'footNear': K([0,2],[2,-10],[9,2]),
            'footFar':  K([0,-3],[2,12],[9,-3]),
        })

    elif cid == 'rocket':
        # BIBLE: "Head low, shoulders high, lantern hanging dead still. Weight
        # square. He looks like something that has been standing there a while."
        # "Deep and slow, with a long hold at the top. The chain does not swing."
        A['idle'] = dict(loop=True, len=L, tracks={
            # long hold at the top of the breath — 40% of the loop is stillness
            'hip':      K([0,0,0,0],[L//5,0,0,-0.0030],[L//2,0,0,-0.0030],
                          [3*L//5,0,0,0],[L,0,0,0]),
            'torso':    K([0,2],[L//5,3],[L//2,3],[L,2]),
            'head':     K([0,7],[L//2,8],[L,7]),          # head LOW, and it stays
            'shoulderNear': K([0,6],[L//2,7],[L,6]),      # shoulders HIGH
            'shoulderFar':  K([0,5],[L//2,6],[L,5]),
            'armNearU': K([0,-3],[L,-3]),                 # lantern arm dead still
            'armNearL': K([0,5],[L,5]),
            'armFarU':  K([0,3],[L//2,4],[L,3]),
            'armFarL':  K([0,-5],[L//2,-4],[L,-5]),
            'legNearU': K([0,0],[L,0]), 'legFarU': K([0,0],[L,0]),   # weight SQUARE
            'legNearL': K([0,-2],[L,-2]),'legFarL': K([0,-2],[L,-2]),
            'footNear': K([0,0],[L,0]),  'footFar': K([0,0],[L,0]),
        })
        # "Heavy, flat, deliberate. Both feet load fully before either lifts."
        A['walk'] = dict(loop=True, len=34, tracks={
            'hip':      K([0,0,0,0],[9,0,0.008,0.006],[17,0,0.005,0],
                          [26,0,0.008,0.006],[34,0,0,0]),
            'torso':    K([0,2],[17,3],[34,2]),
            'head':     K([0,7],[17,6],[34,7]),
            'shoulderNear': K([0,6],[17,7],[34,6]),
            'armNearU': K([0,-3],[34,-3]),
            'armFarU':  K([0,5],[9,-3],[17,6],[26,-2],[34,5]),
            'armFarL':  K([0,-7],[17,-4],[34,-7]),
            # full load before lift: long flat plateaus, no float
            'legNearU': K([0,-11],[6,-11],[13,15],[20,15],[27,-6],[34,-11]),
            'legFarU':  K([0,13],[6,13],[13,-9],[20,-9],[27,10],[34,13]),
            'legNearL': K([0,-4],[13,-14],[20,-4],[34,-4]),
            'legFarL':  K([0,-14],[13,-4],[27,-13],[34,-14]),
            'footNear': K([0,3],[13,-5],[20,3],[34,3]),
            'footFar':  K([0,-5],[13,4],[27,-4],[34,-5]),
        })
        # "A long crouch, then everything at once." + "Overshoots and has to gather"
        A['dash'] = dict(loop=False, len=14, tracks={
            'hip':      K([0,0,0,0],[5,0,-0.006,0.014],[7,0,0.030,0.004],
                          [11,0,0.040,0],[14,0,0.034,0.004]),
            'torso':    K([0,2],[5,-8],[7,20],[14,10]),    # long crouch, then all of it
            'head':     K([0,7],[5,10],[7,-6],[14,2]),
            'shoulderNear': K([0,6],[5,10],[7,-10],[14,0]),
            'armNearU': K([0,-3],[5,8],[7,-40],[14,-20]),
            'armNearL': K([0,5],[5,-6],[7,36],[14,18]),
            'armFarU':  K([0,3],[5,-8],[7,48],[14,24]),
            'armFarL':  K([0,-5],[7,-28],[14,-14]),
            'legNearU': K([0,0],[5,-22],[7,26],[11,-6],[14,4]),
            'legFarU':  K([0,0],[5,20],[7,-24],[11,8],[14,-4]),
            'legNearL': K([0,-2],[5,-18],[7,-14],[14,-4]),
            'legFarL':  K([0,-2],[5,-16],[7,-18],[14,-6]),
            'footNear': K([0,0],[5,-8],[7,10],[14,0]),
            'footFar':  K([0,0],[5,9],[7,-9],[14,0]),
        })

    elif cid == 'static':
        # BIBLE: "Upright, arms wide and loose, antenna drifting. Occupies more
        # space than he needs to." + "Irregular. Skips." + "the face changes one
        # frame before the body does."
        A['idle'] = dict(loop=True, len=L, tracks={
            # irregular breath: not a sine. arrives early, holds, drops late.
            'hip':      K([0,0,0,0],[L//6,0,0.002,-0.0022],[L//3,0,0.002,-0.0022],
                          [L//2,0,0,0.0008],[2*L//3,0,-0.002,-0.0014],[L,0,0,0]),
            'torso':    K([0,0],[L//3,-2],[L//2,1],[2*L//3,-1],[L,0]),
            # head leads the body by a beat — the face changes first
            'head':     K([0,-2],[L//6,3],[L//3,-3],[L//2,2],[2*L//3,-2],[L,-2]),
            'shoulderNear': K([0,2],[L//2,4],[L,2]),
            'shoulderFar':  K([0,2],[L//2,4],[L,2]),
            'armNearU': K([0,-16],[L//3,-13],[2*L//3,-18],[L,-16]),   # arms WIDE
            'armNearL': K([0,10],[L//2,7],[L,10]),
            'armFarU':  K([0,16],[L//3,13],[2*L//3,18],[L,16]),
            'armFarL':  K([0,-10],[L//2,-7],[L,-10]),
            'legNearU': K([0,1],[L,1]), 'legFarU': K([0,-1],[L,-1]),
            'legNearL': K([0,-2],[L,-2]),'legFarL': K([0,-2],[L,-2]),
            'footNear': K([0,0],[L,0]),  'footFar': K([0,0],[L,0]),
        })
        # "Small, quick, cut. No easing. A skipped step every cycle."
        A['walk'] = dict(loop=True, len=22, tracks={
            'hip':      K([0,0,0,0],[5,0,0.006,-0.003],[8,0,0.006,-0.003],
                          [13,0,0.009,0],[22,0,0,0]),      # frames 5-8: the skip
            'torso':    K([0,-1],[8,-1],[13,1],[22,-1]),
            'head':     K([0,-3],[4,2],[8,2],[13,-3],[22,-3]),
            'armNearU': K([0,-16],[8,-16],[13,-12],[22,-16]),
            'armFarU':  K([0,16],[8,16],[13,12],[22,16]),
            'legNearU': K([0,-9],[5,11],[8,11],[13,-4],[22,-9]),   # holds through skip
            'legFarU':  K([0,10],[5,-7],[8,-7],[13,9],[22,10]),
            'legNearL': K([0,-3],[5,-11],[8,-11],[22,-3]),
            'legFarL':  K([0,-9],[5,-3],[13,-10],[22,-9]),
            'footNear': K([0,2],[5,-4],[8,-4],[22,2]),
            'footFar':  K([0,-3],[5,3],[13,-3],[22,-3]),
        })
        # "Instant, no crouch. He is simply elsewhere." + "Cut, not settled."
        A['dash'] = dict(loop=False, len=7, tracks={
            'hip':      K([0,0,0,0],[1,0,0.034,0],[5,0,0.040,0],[7,0,0.040,0]),
            'torso':    K([0,-1],[1,6],[7,4]),             # no crouch frame at all
            'head':     K([0,-3],[1,-6],[7,-4]),
            'armNearU': K([0,-16],[1,-34],[7,-28]),
            'armNearL': K([0,10],[1,26],[7,20]),
            'armFarU':  K([0,16],[1,38],[7,30]),
            'armFarL':  K([0,-10],[1,-22],[7,-18]),
            'legNearU': K([0,1],[1,-18],[5,10],[7,2]),
            'legFarU':  K([0,-1],[1,16],[5,-10],[7,-2]),
            'legNearL': K([0,-2],[1,-12],[7,-3]),
            'legFarL':  K([0,-2],[1,-13],[7,-3]),
            'footNear': K([0,0],[1,-6],[7,0]),
            'footFar':  K([0,0],[1,7],[7,0]),
        })

    else:
        A['idle'] = dict(loop=True, len=L, tracks={
        'hip':      K([0,0,0,0], [q,0,0.004,-p['breathe']*0.0016], [h,0,0,0],
        [q*3,0,-0.004,p['breathe']*0.0012], [L,0,0,0]),
        'torso':    K([0,-p['sway']*0.4], [h,p['sway']*0.4], [L,-p['sway']*0.4]),
        'head':     K([0,p['sway']*0.5+p['headLead']], [h,-p['sway']*0.5-p['headLead']],
        [L,p['sway']*0.5+p['headLead']]),
        'armNearU': K([0,-p['armIdle']*0.5], [h,p['armIdle']*0.5], [L,-p['armIdle']*0.5]),
        'armNearL': K([0,p['armIdle']], [h,-p['armIdle']*0.6], [L,p['armIdle']]),
        'armFarU':  K([0,p['armIdle']*0.5], [h,-p['armIdle']*0.5], [L,p['armIdle']*0.5]),
        'armFarL':  K([0,-p['armIdle']*0.7], [h,p['armIdle']*0.5], [L,-p['armIdle']*0.7]),
        'legNearU': K([0,p['stance']*0.5], [L,p['stance']*0.5]),
        'legFarU':  K([0,-p['stance']*0.5], [L,-p['stance']*0.5]),
        'legNearL': K([0,-p['stance']*0.3], [L,-p['stance']*0.3]),
        'legFarL':  K([0,p['stance']*0.3], [L,p['stance']*0.3]),
        })

        # ---------------- WALK: contact / down / passing / up, counter-rotating arms
        W = p['walkLen']; s = p['stride']; kb = p['kneeBend']
        qw = W//4
        A['walk'] = dict(loop=True, len=W, tracks={
        'hip':      K([0,0,0,0], [qw,0,0,p['bob']], [W//2,0,0,0], [qw*3,0,0,p['bob']], [W,0,0,0]),
        'torso':    K([0,p['lean']*0.5],[W//2,p['lean']*0.5],[W,p['lean']*0.5]),
        'head':     K([0,-2],[W//2,2],[W,-2]),
        'legNearU': K([0,s],[W//2,-s],[W,s]),
        'legNearL': K([0,-kb*1.2],[qw,-kb*0.2],[W//2,-kb*1.8],[qw*3,-kb*1.0],[W,-kb*1.2]),
        'legFarU':  K([0,-s],[W//2,s],[W,-s]),
        'legFarL':  K([0,-kb*1.8],[qw,-kb*1.0],[W//2,-kb*1.2],[qw*3,-kb*0.2],[W,-kb*1.8]),
        'footNear': K([0,-s*0.35],[W//2,s*0.25],[W,-s*0.35]),
        'footFar':  K([0,s*0.25],[W//2,-s*0.35],[W,s*0.25]),
        'armNearU': K([0,-p['armSwing']],[W//2,p['armSwing']],[W,-p['armSwing']]),
        'armNearL': K([0,-p['armSwing']*0.5],[W//2,p['armSwing']*0.3],[W,-p['armSwing']*0.5]),
        'armFarU':  K([0,p['armSwing']],[W//2,-p['armSwing']],[W,p['armSwing']]),
        'armFarL':  K([0,p['armSwing']*0.3],[W//2,-p['armSwing']*0.5],[W,p['armSwing']*0.3]),
        })

        # ---------------- DASH: low forward lean, trailing limbs
        A['dash'] = dict(loop=False, len=9, tracks={
        'hip':      K([0,0,0,0],[3,0,0.02,0.012],[9,0,0.03,0.008]),
        'torso':    K([0,p['dashLean']*0.4],[3,p['dashLean']],[9,p['dashLean']*0.85]),
        'head':     K([0,-p['dashLean']*0.5],[9,-p['dashLean']*0.35]),
        'armNearU': K([0,-30],[4,-52],[9,-44]),
        'armNearL': K([0,20],[4,42],[9,36]),
        'armFarU':  K([0,34],[4,56],[9,48]),
        'armFarL':  K([0,-16],[4,-34],[9,-28]),
        'legNearU': K([0,26],[4,-34],[9,20]),
        'legFarU':  K([0,-30],[4,30],[9,-24]),
        'legNearL': K([0,-20],[4,-8],[9,-18]),
        'legFarL':  K([0,-8],[4,-26],[9,-10]),
        })

    # walkBack derives from walk and must exist for EVERY fighter.
    A['walkBack'] = dict(loop=True, len=A['walk']['len'],
                         tracks=dict(A['walk']['tracks']))

    # ---------------- JUMP: stretch up, tuck at apex, reach on descent
    t = p['jumpTuck']
    A['jumpUp'] = dict(loop=False, len=20, tracks={
        'torso':    K([0,-6],[6,-2],[20,2]),
        'head':     K([0,4],[20,-2]),
        'legNearU': K([0,-8],[7,t],[20,t*0.8]),
        'legNearL': K([0,4],[7,-t*1.5],[20,-t*1.2]),
        'legFarU':  K([0,-10],[7,t*0.6],[20,t*0.45]),
        'legFarL':  K([0,4],[7,-t*1.1],[20,-t*0.9]),
        'armNearU': K([0,-40],[8,-64],[20,-56]),
        'armFarU':  K([0,36],[8,58],[20,50]),
        'armNearL': K([0,14],[20,26]),
        'armFarL':  K([0,-14],[20,-22]),
    })
    A['jumpDown'] = dict(loop=False, len=20, tracks={
        'torso':    K([0,4],[20,7]),
        'head':     K([0,-3],[20,-5]),
        'legNearU': K([0,t*0.7],[20,t*0.25]),
        'legNearL': K([0,-t*1.0],[20,-t*0.5]),
        'legFarU':  K([0,t*0.3],[20,-4]),
        'legFarL':  K([0,-t*0.7],[20,-t*0.3]),
        'armNearU': K([0,-56],[20,-34]),
        'armFarU':  K([0,50],[20,30]),
    })
    A['land'] = dict(loop=False, len=8, tracks={
        'hip':      K([0,0,0,0.045],[4,0,0,0.055],[8,0,0,0]),
        'torso':    K([0,9],[4,11],[8,0]),
        'head':     K([0,-7],[8,0]),
        'legNearU': K([0,22],[3,26],[8,p['stance']*0.5]),
        'legNearL': K([0,-34],[3,-40],[8,-p['stance']*0.3]),
        'legFarU':  K([0,-20],[3,-24],[8,-p['stance']*0.5]),
        'legFarL':  K([0,-30],[3,-36],[8,p['stance']*0.3]),
        'armNearU': K([0,-30],[8,0]),
        'armFarU':  K([0,28],[8,0]),
    })

    # ---------------- BLOCK (PHASE 8: no fighter may block identically)
    # This clip used to be byte-identical across the whole roster. Guard shape is
    # now derived from the fighter's own defense_profile and DNA:
    #   misdirection -> he does not brace. He leans off the line, guard low,
    #                   weight already moving. Blocking is an insult.
    #   space        -> a cut, minimal, precise. He should not be here at all.
    #   absorb       -> plants, squares up, takes it. No evasion in him.
    _style = _genome['defense_profile']['style']
    _w  = _dna['weight'] / 100.0
    _el = _dna['elasticity'] / 100.0
    if _style == 'misdirection':
        _e = max(4, int(round(6 * (1 - _el * 0.35))))   # elastic bodies get there sooner
        _m = max(2, _e // 2)
        _bl = dict(loop=False, len=_e, tracks={
            'hip':      K([0,0,0,0],[_e,0,-0.030,0.008]),   # slides off the line
            'torso':    K([0,0],[_m,-14],[_e,-19]),          # leans away, not braced
            'head':     K([0,0],[_e,13]),                   # chin up. watching.
            'armNearU': K([0,0],[_m,-54],[_e,-61]),          # guard LOW — disrespectful
            'armNearL': K([0,0],[_m,40],[_e,49]),
            'armFarU':  K([0,0],[_e,58]),                   # far hand hangs loose
            'armFarL':  K([0,0],[_e,-34]),
            'legNearU': K([0,0],[_e,20]),
            'legFarU':  K([0,0],[_e,-24]),
            'legNearL': K([0,0],[_e,-22]),
            'legFarL':  K([0,0],[_e,-8]),
        })
    elif _style == 'space':
        _bl = dict(loop=False, len=5, tracks={
            'hip':      K([0,0,0,0],[5,0,-0.020,0.010]),
            'torso':    K([0,0],[2,-11],[5,-11]),          # arrives and STOPS. cut, not eased.
            'head':     K([0,0],[5,3]),
            'armNearU': K([0,0],[2,-88],[5,-88]),          # tight, high, exact
            'armNearL': K([0,0],[2,79],[5,79]),
            'armFarU':  K([0,0],[5,36]),
            'armFarL':  K([0,0],[5,-70]),
            'legNearU': K([0,0],[5,9]),
            'legFarU':  K([0,0],[5,-11]),
            'legNearL': K([0,0],[5,-13]),
            'legFarL':  K([0,0],[5,-9]),
        })
    else:  # absorb
        _bl = dict(loop=False, len=max(6, int(round(6 * (1 + _w * 0.6)))), tracks={
            'hip':      K([0,0,0,0],[9,0,-0.004,0.026]),   # sinks, does not slide
            'torso':    K([0,0],[4,-4],[9,-5]),            # square. barely turns.
            'head':     K([0,0],[9,-3]),                   # head DOWN into it
            'armNearU': K([0,0],[4,-78],[9,-92]),
            'armNearL': K([0,0],[4,66],[9,86]),
            'armFarU':  K([0,0],[9,52]),
            'armFarL':  K([0,0],[9,-72]),
            'legNearU': K([0,0],[9,7]),
            'legFarU':  K([0,0],[9,-8]),
            'legNearL': K([0,0],[9,-20]),
            'legFarL':  K([0,0],[9,-18]),
        })
    A['block'] = _bl

    # ---------------- HURT / DOWN / KO
    hs = p['hurtSnap']
    A['hurt'] = dict(loop=False, len=14, tracks={
        'hip':      K([0,0,0,0],[3,0,-0.02,0],[14,0,-0.01,0]),
        'torso':    K([0,0],[3,hs*0.6],[8,hs*0.3],[14,hs*0.45]),
        'head':     K([0,0],[3,hs],[8,hs*0.4],[14,hs*0.7]),
        'armNearU': K([0,0],[3,42],[14,30]),
        'armFarU':  K([0,0],[3,-46],[14,-32]),
        'armNearL': K([0,0],[3,-30],[14,-20]),
        'armFarL':  K([0,0],[3,34],[14,22]),
        'legNearU': K([0,0],[3,-20],[14,-12]),
        'legFarU':  K([0,0],[3,24],[14,16]),
    })
    A['down'] = dict(loop=False, len=10, tracks={
        'hip':      K([0,0,0,0.30],[10,0,-0.02,0.34]),
        'torso':    K([0,-70],[10,-84]),
        'head':     K([0,-20],[10,-26]),
        'legNearU': K([0,58],[10,66]), 'legFarU': K([0,44],[10,52]),
        'legNearL': K([0,-40],[10,-46]), 'legFarL': K([0,-30],[10,-36]),
        'armNearU': K([0,60],[10,72]), 'armFarU': K([0,-54],[10,-66]),
    })
    A['ko'] = dict(loop=False, len=30, tracks={
        'hip':      K([0,0,0,0],[12,0,-0.06,-0.10],[30,0,-0.12,0.34]),
        'torso':    K([0,-18],[12,p['koSpin']*0.6],[30,p['koSpin']]),
        'head':     K([0,-24],[12,-42],[30,-30]),
        'armNearU': K([0,-56],[12,-96],[30,-70]),
        'armFarU':  K([0,52],[12,92],[30,64]),
        'legNearU': K([0,-30],[12,-64],[30,48]),
        'legFarU':  K([0,24],[12,58],[30,36]),
        'legNearL': K([0,-24],[30,-40]), 'legFarL': K([0,-18],[30,-34]),
    })

    # ---------------- STRIKES: anticipation -> contact -> follow-through -> recover
    # ── SINGLE SOURCE OF TRUTH ──────────────────────────────────────────────
    # DEFECT REPAIRED: clip totals were hardcoded here, so frame data and
    # animation could silently disagree. README's one rule is "nothing is
    # hardcoded". Timing now comes from moves.json, which is the only place
    # a move's length is allowed to be defined.
    import os as _os
    _mv = json.load(open(_os.path.join(
        _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),
        'data', 'characters', cid, 'moves.json')))['moves']
    def T(name):
        m = _mv[name]
        return m['startup'] + m['active'] + m['recovery']
    def H(name):
        return _mv[name]['startup']

    def punch(total, hitAt, reach, rot, hipTwist, headFollow, sig=None):
        """KINETIC CHAIN (Phase 2 Part 1).

        Power begins at the ground and arrives at the hand LAST. Each link peaks
        one beat after the link below it, so the body reads as a whip rather than
        an arm swinging on its own:

            foot -> leg drive -> hip -> spine -> shoulder -> arm -> hand

        The stagger is scaled to the move's own startup, so a 3-frame jab still
        sequences correctly instead of collapsing every joint onto one frame
        (which is exactly what the previous authoring did)."""
        # Anticipation must precede the whole chain. Deriving it from hitAt-2
        # let it land AFTER the foot and leg peaks on longer moves, producing
        # unsorted keyframes — the legs appeared to fire before the wind-up.
        beat0 = max(1.0, hitAt / 6.0)
        pre  = max(1, int(round(max(1.0, hitAt - 6 * beat0) * 0.6)))
        # one "beat" of the chain, never less than a frame, never so long that a
        # short move loses its ground contact before the hand lands
        beat = max(1.0, hitAt / 6.0)
        def t(n, cap=None):
            """frame at which link n of the chain peaks (0 = foot, 6 = hand)"""
            f = hitAt - (6 - n) * beat
            return max(0, min(total, int(round(f if cap is None else min(f, cap)))))
        _ts = [t(i) for i in range(7)]
        # Enforce monotonicity by construction. On a 3-frame jab several links
        # clamp to the same frame — that is physically honest (a jab IS mostly
        # arm) — but a LATER link must never peak BEFORE an earlier one.
        for _i in range(1, 7):
            if _ts[_i] < _ts[_i-1]: _ts[_i] = _ts[_i-1]
        t_foot, t_leg, t_hip, t_spine, t_sh, t_arm, t_hand = _ts
        _s = 1 if t_hand > t_hip else 0   # did the chain actually sequence?

        tr = {
            # 0 — FOOT: the ground push. First thing to move, smallest amplitude.
            'footNear': K([0,0],[t_foot if t_foot>0 else 0,-7],[max(t_foot+1,t_hip),4],[total,0]),
            'footFar':  K([0,0],[t_foot if t_foot>0 else 0,9],[max(t_foot+1,t_hip),-5],[total,0]),
            # 1 — LEG DRIVE: rear leg extends into the floor
            'legFarU':  K([0,0],[pre,12],[t_leg,-18],[total,0]),
            'legFarL':  K([0,0],[t_leg,-8],[total,0]),
            'legNearU': K([0,0],[pre,-10],[t_leg,16],[total,0]),
            'legNearL': K([0,0],[t_leg,-12],[total,0]),
            # 2 — HIP: pelvis rotates. This is where the punch is actually thrown.
            'hip':      K([0,0,0,0],[pre,0,-0.012,0],[t_hip,0,reach*0.30,0],
                          [t_hip+3,0,reach*0.22,0],[total,0,0,0]),
            # 3 — SPINE: torso torque, counter-rotating against the hip
            'torso':    K([0,0],[pre,-hipTwist*0.9],[t_spine,hipTwist],
                          [t_spine+3,hipTwist*0.7],[total,0]),
            # 4 — SHOULDER: compression, then release. Loads before the arm moves.
            'shoulderNear': K([0,0],[pre,-6],[t_sh,10],[t_sh+3,6],[total,0]),
            'shoulderFar':  K([0,0],[pre,5],[t_sh,-8],[total,0]),
            # 5 — ARM: extension, driven, not initiating
            'armNearU': K([0,0],[pre,-rot*0.30],[t_arm,rot],[t_arm+3,rot*0.78],[total,0]),
            'armFarU':  K([0,0],[pre,rot*0.34],[t_arm,-rot*0.5],[total,0]),
            'armFarL':  K([0,0],[pre,-rot*0.3],[t_arm,rot*0.34],[total,0]),
            # 6 — HAND: arrives last. This frame is the hit.
            'armNearL': K([0,0],[pre,rot*0.55],[t_hand,-rot*0.92],
                          [t_hand+3,-rot*0.6],[total,0]),
            'head':     K([0,0],[pre,hipTwist*0.5],[t_spine,-headFollow],[total,0]),
        }
        # A signature override may restyle a move, but it may not take the power
        # path off the ground: hip, legs and feet stay chain-authored. Overriding
        # them made heavy and smash read as arm-only despite the chain existing.
        if sig:
            # The FULL chain is locked: foot, leg, hip, spine, shoulder, arm, hand.
            # A signature is styling — facial performance, a flourish, a coat
            # accent. It may not re-time the power path. Overriding torso and
            # armNearL made heavy and smash read as arm-led despite the chain
            # being authored correctly underneath.
            CHAIN_LOCKED = {'hip','torso','legFarU','legNearU','legFarL','legNearL',
                            'footNear','footFar','shoulderNear','shoulderFar',
                            'armNearU','armNearL','armFarU','armFarL'}
            tr.update({k: v for k, v in sig.items() if k not in CHAIN_LOCKED})
        return dict(loop=False, len=total, tracks=tr)

    r, R = p['punchReach'], p['punchRot']
    A['light1'] = punch(T('light1'), H('light1'),  r*0.75, R*0.72, 7,  5)
    A['light2'] = punch(T('light2'), H('light2'),  r*0.85, R*0.86, 9,  6)
    A['light3'] = punch(T('light3'), H('light3'),  r*1.00, R*1.05, 13, 9)
    A['heavy']  = punch(T('heavy'), H('heavy'), r*1.15, R*1.30, 17, 12, sig={
        'armNearU': K([0,0],[6,-52],[10,-64],[12,R*1.34],[16,R*1.0],[27,0]),
        'armNearL': K([0,0],[6,64],[10,76],[12,-R*1.15],[16,-R*0.8],[27,0]),
        'hip':      K([0,0,0,0],[6,0,-0.03,0.014],[12,0,r*0.34,-0.03],[16,0,r*0.24,-0.01],[27,0,0,0])})
    A['smash']  = punch(T('smash'), H('smash'), r*1.35, R*1.5, 21, 15, sig={
        'torso':    K([0,0],[10,-26],[15,30],[19,22],[31,0]),
        'hip':      K([0,0,0,0],[10,0,-0.05,0.02],[15,0,r*0.55,0],[19,0,r*0.4,0],[31,0,0,0]),
        'legNearU': K([0,0],[10,-22],[15,34],[31,0]),
        'legFarU':  K([0,0],[10,26],[15,-34],[31,0])})
    # PHASE 8: airL was byte-identical between brooklyn and rocket. The air
    # attack now derives from range_profile — where this fighter meets you in
    # the air is who they are. Close bodies punch down through the target;
    # long bodies reach out ahead of themselves.
    _band = _genome['range_profile']['band']
    _reach = {'close': 0.82, 'mid': 1.00, 'long': 1.22}.get(_band, 1.0)
    _tuck  = {'close': 1.25, 'mid': 1.00, 'long': 0.72}.get(_band, 1.0)
    A['airL'] = dict(loop=False, len=16, tracks={
        'torso':    K([0,round(4*_tuck)],[5,round(12*_tuck)],[16,round(7*_tuck)]),
        'head':     K([0,round(-3*_tuck)],[5,round(-9*_tuck)],[16,round(-5*_tuck)]),
        'armNearU': K([0,round(-30*_reach)],[5,round(-96*_reach)],[16,round(-70*_reach)]),
        'armNearL': K([0,round(20*_reach)],[5,round(72*_reach)],[16,round(48*_reach)]),
        'legNearU': K([0,round(26*_tuck)],[16,round(20*_tuck)]),
        'legFarU':  K([0,round(-18*_tuck)],[16,round(-14*_tuck)]),
        'legNearL': K([0,round(-30*_tuck)],[16,round(-24*_tuck)]),
        'legFarL':  K([0,round(-22*_tuck)],[16,round(-18*_tuck)])})
    A['airH'] = dict(loop=False, len=20, tracks={
        'torso':    K([0,6],[8,26],[20,18]),
        'head':     K([0,-4],[8,-14],[20,-10]),
        'armNearU': K([0,-40],[8,54],[20,44]),
        'armNearL': K([0,26],[8,-40],[20,-30]),
        'armFarU':  K([0,34],[8,-46],[20,-36]),
        'legNearU': K([0,20],[8,-30],[20,-24]),
        'legFarU':  K([0,-16],[8,26],[20,20]),
        'legNearL': K([0,-26],[20,-14]),'legFarL': K([0,-20],[20,-12])})

    # ---------------- SPECIALS: signature silhouettes
    if cid == 'brooklyn':
        A['special'] = dict(loop=False, len=36, tracks={   # Razor Fan
            'torso':K([0,0],[8,-16],[11,20],[18,12],[36,0]),
            'head':K([0,0],[8,10],[11,-8],[36,0]),
            'armNearU':K([0,0],[8,-96],[11,-24],[16,-40],[36,0]),
            'armNearL':K([0,0],[8,86],[11,-64],[16,-30],[36,0]),
            'armFarU':K([0,0],[8,40],[36,0]),
            'hip':K([0,0,0,0],[8,0,-0.04,0],[11,0,0.05,0],[36,0,0,0]),
            'legNearU':K([0,0],[11,20],[36,0]),'legFarU':K([0,0],[11,-22],[36,0])})
        A['specialF'] = dict(loop=False, len=36, tracks={  # Uppercut Ace
            'hip':K([0,0,0,0],[5,0,0,0.05],[9,0,0.03,-0.16],[20,0,0.02,-0.08],[36,0,0,0]),
            'torso':K([0,0],[5,14],[9,-30],[20,-18],[36,0]),
            'head':K([0,0],[9,-16],[36,0]),
            'armNearU':K([0,0],[5,50],[9,-140],[20,-108],[36,0]),
            'armNearL':K([0,0],[5,30],[9,-46],[36,0]),
            'armFarU':K([0,0],[9,64],[36,0]),
            'legNearU':K([0,0],[5,30],[9,-44],[36,0]),
            'legFarU':K([0,0],[5,26],[9,34],[36,0]),
            'legNearL':K([0,0],[9,-52],[36,0])})
    elif cid == 'static':
        A['special'] = dict(loop=False, len=36, tracks={   # Live Wire
            'torso':K([0,0],[7,-20],[12,16],[36,0]),
            'head':K([0,0],[6,14],[12,-18],[20,8],[36,0]),
            'armFarU':K([0,0],[7,-70],[12,-118],[22,-96],[36,0]),
            'armFarL':K([0,0],[7,52],[12,-38],[22,-20],[36,0]),
            'armNearU':K([0,0],[12,44],[36,0]),
            'hip':K([0,0,0,0],[12,0,0.04,0],[36,0,0,0]),
            'legNearU':K([0,0],[12,24],[36,0]),'legFarU':K([0,0],[12,-26],[36,0])})
        A['specialF'] = dict(loop=False, len=36, tracks={  # Broadcast (teleport)
            'torso':K([0,0],[5,-24],[6,0],[14,10],[36,0]),
            'head':K([0,0],[5,18],[6,-24],[14,6],[36,0]),
            'armNearU':K([0,0],[5,-60],[6,-10],[36,0]),
            'armFarU':K([0,0],[5,58],[6,12],[36,0]),
            'legNearU':K([0,0],[5,-28],[6,22],[36,0]),
            'legFarU':K([0,0],[5,30],[6,-20],[36,0])})
    else:  # rocket
        A['special'] = dict(loop=False, len=36, tracks={   # Ghost Dash
            'torso':K([0,0],[4,-22],[8,26],[20,20],[36,0]),
            'head':K([0,0],[8,-14],[36,0]),
            'hip':K([0,0,0,0],[4,0,-0.05,0.03],[8,0,0.07,0.01],[36,0,0,0]),
            'armNearU':K([0,0],[4,-46],[8,-88],[20,-70],[36,0]),
            'armFarU':K([0,0],[4,44],[8,76],[36,0]),
            'armFarL':K([0,0],[8,-40],[36,0]),
            'legNearU':K([0,0],[4,-32],[8,44],[20,30],[36,0]),
            'legFarU':K([0,0],[4,36],[8,-40],[36,0]),
            'legNearL':K([0,0],[8,-40],[36,0])})
        A['specialF'] = dict(loop=False, len=36, tracks={  # Pounce
            'hip':K([0,0,0,0],[6,0,-0.03,0.06],[10,0,0.05,-0.14],[24,0,0.03,-0.05],[36,0,0,0]),
            'torso':K([0,0],[6,20],[10,-26],[24,-14],[36,0]),
            'head':K([0,0],[6,10],[10,-20],[36,0]),
            'armNearU':K([0,0],[6,40],[10,-116],[24,-88],[36,0]),
            'armFarU':K([0,0],[6,-34],[10,96],[36,0]),
            'legNearU':K([0,0],[6,40],[10,-56],[24,-30],[36,0]),
            'legFarU':K([0,0],[6,34],[10,-40],[36,0]),
            'legNearL':K([0,0],[10,-60],[36,0]),'legFarL':K([0,0],[10,-46],[36,0])})

    # ---------------- BLOCKBUSTER: big wind-up, held hero pose, release
    A['blockbuster'] = dict(loop=False, len=76, tracks={
        'hip':K([0,0,0,0],[10,0,-0.06,0.03],[20,0,0,-0.05],[50,0,0.02,-0.03],[76,0,0,0]),
        'torso':K([0,0],[10,-30],[20,24],[36,18],[50,22],[76,0]),
        'head':K([0,0],[10,20],[20,-18],[50,-12],[76,0]),
        'armNearU':K([0,0],[10,-110],[20,-46],[36,-70],[50,-52],[76,0]),
        'armNearL':K([0,0],[10,96],[20,-60],[36,-30],[50,-48],[76,0]),
        'armFarU':K([0,0],[10,86],[20,-40],[50,-24],[76,0]),
        'armFarL':K([0,0],[10,-70],[20,44],[76,0]),
        'legNearU':K([0,0],[10,-26],[20,30],[50,24],[76,0]),
        'legFarU':K([0,0],[10,30],[20,-32],[50,-26],[76,0]),
        'legNearL':K([0,0],[20,-30],[76,0]),'legFarL':K([0,0],[20,-22],[76,0])})

    # ---------------- INTRO / VICTORY (story, arcade, replay theater use these)
    A['intro'] = dict(loop=False, len=90, tracks={
        'torso':K([0,-40],[24,10],[50,-4],[90,0]),
        'head':K([0,30],[24,-14],[50,6],[90,0]),
        'armNearU':K([0,-120],[24,-30],[50,-56],[90,0]),
        'armNearL':K([0,90],[24,20],[90,0]),
        'armFarU':K([0,110],[24,26],[90,0]),
        'legNearU':K([0,40],[24,-14],[90,0]),'legFarU':K([0,-44],[24,16],[90,0])})
    A['victory'] = dict(loop=True, len=110, tracks={
        'torso':K([0,6],[55,-6],[110,6]),
        'head':K([0,-8],[55,10],[110,-8]),
        'armNearU':K([0,-116],[55,-96],[110,-116]),
        'armNearL':K([0,70],[55,52],[110,70]),
        'armFarU':K([0,30],[55,44],[110,30]),
        'legNearU':K([0,10],[110,10]),'legFarU':K([0,-12],[110,-12])})
    # ── FALLBACK CLIP ───────────────────────────────────────────────────────
    # DEFECT REPAIRED: a move added to the source layer with no hand-authored
    # clip shipped with no animation at all, and the smoke suite caught it only
    # because it checks clip coverage. Every move now gets at least a derived
    # clip built from its own frame data, so authoring a move can never produce
    # an invisible one.
    for _mid, _m in _mv.items():
        if _mid in A:
            continue
        A[_mid] = punch(T(_mid), H(_mid), r*1.05, R*1.15, 15, 11)

    # ── CLIP/FRAME-DATA NORMALIZER ──────────────────────────────────────────
    # Any clip that corresponds to a move in moves.json is rescaled so its
    # length and keyframe times match that move's real frame data. Hand-authored
    # keyframe times are treated as proportions of the clip, not absolutes.
    # This is what makes moves.json the single source of truth for timing:
    # change frame data, and the animation follows automatically.
    for _mid, _m in _mv.items():
        if _mid not in A:
            continue
        _total = _m['startup'] + _m.get('active', 1) + _m['recovery']
        _clip = A[_mid]
        # Signature-override tracks are hand-authored against the ORIGINAL
        # total, so the clip's declared len is not a reliable divisor. Scale
        # against the longest key actually present in the clip.
        _maxk = max((_k[0] for _tr in _clip['tracks'].values() for _k in _tr),
                    default=0)
        _old = max(_clip.get('len') or 0, _maxk) or _total
        if _old != _total:
            _scale = _total / float(_old)
            for _tr in _clip['tracks'].values():
                for _k in _tr:
                    _k[0] = int(round(_k[0] * _scale))
        # hard clamp — no keyframe may ever live past the end of its clip
        for _tr in _clip['tracks'].values():
            for _k in _tr:
                _k[0] = max(0, min(_total, _k[0]))
        _clip['len'] = _total

    return A

if __name__ == '__main__':
    game = json.load(open(f'{ROOT}/data/system/game.json'))
    print('authoring animations...')
    for cid in game['roster']:
        A = build(cid)
        json.dump(A, open(f'{ROOT}/data/characters/{cid}/anim.json','w'), indent=1)
        keys = sum(len(t) for c in A.values() for t in c['tracks'].values())
        print(f'  {cid}: {len(A)} clips, {keys} keyframes')
    print('done')
