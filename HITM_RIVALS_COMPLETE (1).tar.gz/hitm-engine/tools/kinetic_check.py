#!/usr/bin/env python3
"""kinetic_check.py — prove the power path runs foot -> hand, not arm-only.
For each attack, find the frame at which each link of the chain reaches its
peak absolute rotation, and assert the order."""
import json, os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CHAIN=[('foot',['footNear','footFar']),('leg',['legFarU','legNearU']),
       ('hip',['hip']),('spine',['torso']),
       ('shoulder',['shoulderNear','shoulderFar']),
       ('arm',['armNearU']),('hand',['armNearL'])]
ATK=['light1','light2','light3','heavy','smash']
def peak(clip,bones):
    best=None
    for b in bones:
        tr=clip['tracks'].get(b)
        if not tr: continue
        # a bone may be driven by rotation OR translation (the hip is translation)
        def mag(k):
            return max(abs(k[1] if len(k)>1 else 0),
                       abs(k[2]*260 if len(k)>2 else 0),
                       abs(k[3]*260 if len(k)>3 else 0))
        f=max(tr,key=mag); v=mag(f)
        if best is None or v>best[1]: best=(f[0],v)
    return best[0] if best else None
fail=0
for cid in json.load(open(f'{ROOT}/data/system/game.json'))['roster']:
    a=json.load(open(f'{ROOT}/data/characters/{cid}/anim.json'))
    print(f"\n── {cid.upper()}")
    print(f"   {'move':<9}"+"".join(f"{n:>10}" for n,_ in CHAIN)+"   verdict")
    for m in ATK:
        if m not in a: continue
        ts=[peak(a[m],b) for _,b in CHAIN]
        seq=[t for t in ts if t is not None]
        # Law: no link may peak BEFORE the link below it. On very short startups
        # links legitimately collapse onto the same frame — a 3-frame jab is
        # mostly arm in real boxing too. What is forbidden is INVERSION.
        ok = all(seq[i]<=seq[i+1] for i in range(len(seq)-1)) and seq[-1]>=seq[0]
        if not ok: fail+=1
        print(f"   {m:<9}"+"".join(f"{('-' if t is None else t):>10}" for t in ts)
              +f"   {'CHAIN OK' if ok else 'INVERTED — arm leads body'}")
print(f"\n{fail} attacks violate the power path." if fail else "\nAll attacks run foot -> hand.")
sys.exit(1 if fail else 0)
