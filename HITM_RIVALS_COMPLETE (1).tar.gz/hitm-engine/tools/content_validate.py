#!/usr/bin/env python3
"""content_validate.py — EXPECTED CONTENT VALIDATION.

The suite proved "the clips that exist work". It never proved "the clips that
should exist exist". That gap let walkBack vanish from two fighters with 91
tests green. This gate closes it: it derives what SHOULD be present from the
move tables and the roster, and fails on anything absent.
"""
import json, os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
J=lambda p: json.load(open(f'{ROOT}/{p}'))

# Locomotion every fighter must have, independent of their move list.
BASE=['idle','walk','walkBack','dash','jumpUp','jumpDown','land',
      'block','hurt','down','ko','victory','intro']
# Declared but not yet built — tracked as MISSING MECHANIC, not silently ignored.
PLANNED={'run':'no run state in CombatSystem',
         'crouch':'no crouch state in CombatSystem',
         'taunt':'no taunt state in CombatSystem'}

def main():
    roster=J('data/system/game.json')['roster']
    fail=0; planned=0
    print("content_validate — does everything that should exist, exist?\n")
    for cid in roster:
        an=J(f'data/characters/{cid}/anim.json')
        mv=J(f'data/characters/{cid}/moves.json')['moves']
        ch=J(f'data/characters/{cid}/character.json')
        need=BASE+sorted(mv)                       # every move needs a clip
        missing=[n for n in need if n not in an]
        extra=[n for n in an if n not in need and n not in PLANNED]
        # alternate states must carry their own tables
        for sid in ch.get('states',[]):
            for f in ('moves.json','ai.json'):
                if not os.path.exists(f'{ROOT}/data/characters/{cid}_{sid}/{f}'):
                    missing.append(f'{cid}_{sid}/{f}'); 
        print(f"── {cid.upper()}  {len(an)} clips · {len(mv)} moves · "
              f"states {ch.get('states',[]) or 'none'}")
        for n in need:
            if n not in an: print(f"     MISSING   {n}")
        if extra: print(f"     unbound clips (no move): {extra}")
        for n,why in PLANNED.items():
            if n not in an:
                planned+=1
                print(f"     planned   {n:<8} {why}")
        if missing: fail+=len(missing)
        else: print(f"     complete — all {len(need)} required assets present")
        print()
    print(f"{fail} required assets missing." if fail else "All required content present.")
    print(f"{planned} planned assets blocked on missing mechanics (not counted as failures).")
    sys.exit(1 if fail else 0)

if __name__=='__main__': main()
