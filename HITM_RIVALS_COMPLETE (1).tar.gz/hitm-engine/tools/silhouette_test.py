#!/usr/bin/env python3
"""silhouette_test.py — THE FINAL TEST.
Render each fighter as a pure black silhouette at a given clip frame.
If you cannot tell who is who, the personality is not in the movement yet."""
import json, os, sys
from PIL import Image
import numpy as np
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def silhouette(cid, clip='idle', frame=0):
    rig=json.load(open(f'{ROOT}/data/characters/{cid}/rig.json'))
    prt=json.load(open(f'{ROOT}/data/characters/{cid}/parts.json'))
    an=json.load(open(f'{ROOT}/data/characters/{cid}/anim.json'))
    at=Image.open(f'{ROOT}/assets/parts/{cid}_atlas.png').convert('RGBA')
    SW,SH=prt['sourceSize']
    pose={}
    cl=an.get(clip)
    if cl:
        for b,tr in cl['tracks'].items():
            v=tr[0]
            for k in tr:
                if k[0]<=frame: v=k
            pose[b]={'rot':v[1] if len(v)>1 else 0,
                     'dx':v[2] if len(v)>2 else 0,'dy':v[3] if len(v)>3 else 0}
    canvas=Image.new('RGBA',(SW,SH),(0,0,0,0))
    hip=pose.get('hip',{})
    ox,oy=int(hip.get('dx',0)*SW), int(hip.get('dy',0)*SH)
    for name in rig['drawOrder']:
        m=prt['parts'].get(name)
        if not m: continue
        x,y,w,h=m['frame']
        piece=at.crop((x,y,x+w,y+h))
        rot=pose.get(name,{}).get('rot',0)
        if abs(rot)>0.5:
            piece=piece.rotate(-rot,expand=True,resample=Image.BICUBIC)
        r=rig['parts'][name]['rect']
        canvas.alpha_composite(piece,(max(0,int(r[0]*SW)-6+ox),max(0,int(r[1]*SH)-6+oy)))
    a=np.array(canvas)
    black=np.zeros_like(a); black[:,:,3]=a[:,:,3]
    return Image.fromarray(black)

if __name__=='__main__':
    clip=sys.argv[1] if len(sys.argv)>1 else 'idle'
    frame=int(sys.argv[2]) if len(sys.argv)>2 else 0
    ims=[silhouette(c,clip,frame) for c in ['brooklyn','static','rocket']]
    W=sum(i.width for i in ims)+80; H=max(i.height for i in ims)
    s=Image.new('RGB',(W,H),'white'); x=0
    for i in ims: s.paste(i,(x,0),i); x+=i.width+40
    s.save(f'/tmp/sil_{clip}_{frame}.png')
    # measurable silhouette signature
    print(f"{'fighter':<11}{'width':>7}{'height':>8}{'fill%':>8}{'lean':>7}{'top-heavy':>11}")
    for c,i in zip(['brooklyn','static','rocket'],ims):
        m=np.array(i)[:,:,3]>30
        ys,xs=np.where(m)
        if not len(xs): continue
        w=xs.max()-xs.min(); h=ys.max()-ys.min()
        top=m[:m.shape[0]//2].sum(); bot=m[m.shape[0]//2:].sum()
        cx_top=np.where(m[:m.shape[0]//2])[1].mean() if top else 0
        cx_bot=np.where(m[m.shape[0]//2:])[1].mean() if bot else 0
        print(f"{c:<11}{w:>7}{h:>8}{m.mean()*100:>7.1f}%{cx_top-cx_bot:>7.1f}{top/max(bot,1):>11.2f}")
    print(f"-> /tmp/sil_{clip}_{frame}.png")
