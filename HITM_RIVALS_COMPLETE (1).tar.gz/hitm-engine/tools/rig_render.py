#!/usr/bin/env python3
"""rig_render.py — offline composite of a rig at a given clip frame.
Reproduces SkeletonSystem's transform chain in PIL so a rig can be LOOKED AT
without a browser. Verification tool: proves parts assemble into a figure."""
import json, os, sys, math
from PIL import Image
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def build(cid, clip='idle', frame=0, H=520):
    rig=json.load(open(f'{ROOT}/data/characters/{cid}/rig.json'))
    parts=json.load(open(f'{ROOT}/data/characters/{cid}/parts.json'))
    anim=json.load(open(f'{ROOT}/data/characters/{cid}/anim.json'))
    atlas=Image.open(f'{ROOT}/assets/parts/{cid}_atlas.png').convert('RGBA')
    frames=parts['frames'] if 'frames' in parts else parts
    meta=parts.get('parts',{})
    # local pose from clip
    lp={}
    cl=anim.get(clip)
    if cl:
        for b,tr in cl['tracks'].items():
            v=tr[0]
            for k in tr:
                if k[0]<=frame: v=k
            lp[b]={'rot':v[1] if len(v)>1 else 0}
    bones={b['name']:b for b in rig['bones']}
    world={}
    def solve(n):
        if n in world: return world[n]
        b=bones[n]; rot=(lp.get(n,{}).get('rot',0))*math.pi/180
        if not b.get('parent'):
            world[n]=(0.5*H*0.42, H*0.98, rot); return world[n]
        px,py,pr=solve(b['parent'])
        L=b.get('len',0.09)*H
        x=px+math.sin(pr)*0; y=py
        world[n]=(x,y,pr+rot); return world[n]
    canvas=Image.new('RGBA',(int(H*0.62),H),(0,0,0,0))
    for pname in rig['drawOrder']:
        if pname not in meta: continue
        fr=frames.get(pname)
        if not fr: continue
        x,y,w,h=fr[:4]
        piece=atlas.crop((x,y,x+w,y+h))
        m=meta[pname]
        sw=int(m['normW']*H*0.62/1.0*0.62); sh=int(m['normH']*H)
        if sw<1 or sh<1: continue
        piece=piece.resize((max(1,sw),max(1,sh)),Image.LANCZOS)
        bn=pname
        rot=lp.get(bn,{}).get('rot',0)
        if abs(rot)>0.01: piece=piece.rotate(-rot,expand=True,resample=Image.BICUBIC)
        # place by source rect so the composite matches the original layout
        r=rig['parts'][pname]['rect']
        cx=int(r[0]*canvas.width); cy=int(r[1]*H)
        canvas.alpha_composite(piece,(max(0,cx),max(0,cy)))
    return canvas

if __name__=='__main__':
    outs=[]
    for cid in ['brooklyn','static','rocket']:
        im=build(cid, sys.argv[1] if len(sys.argv)>1 else 'idle')
        p=f'/tmp/rig_{cid}.png'; im.save(p); outs.append(p)
        print(f"  {cid}: {im.size} -> {p}")
    W=sum(Image.open(p).width for p in outs); H=max(Image.open(p).height for p in outs)
    strip=Image.new('RGBA',(W,H),(255,255,255,255)); x=0
    for p in outs:
        i=Image.open(p); strip.alpha_composite(i,(x,0)); x+=i.width
    strip.convert('RGB').save('/tmp/rig_strip.png'); print("  strip -> /tmp/rig_strip.png")
