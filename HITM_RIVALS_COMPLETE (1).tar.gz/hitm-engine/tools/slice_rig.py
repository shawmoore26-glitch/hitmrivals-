#!/usr/bin/env python3
"""
slice_rig.py — cutout rig slicer.

Reads data/characters/<id>/rig.json and assets/sprites/<id>.png, cuts the sprite
into bone-attached body parts, feathers the seam edges so joints blend when the
parts rotate, synthesizes missing limbs where the source art is cropped, and
packs everything into one atlas per character plus a frames map.

Output: assets/parts/<id>_atlas.png + data/characters/<id>/parts.json
Run:    python3 tools/slice_rig.py
"""
import json, math, os, sys
from PIL import Image, ImageDraw, ImageFilter
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PAD  = 4          # transparent padding so rotation doesn't clip
FEATHER = 9       # px of soft alpha at seam edges

def feather_edges(img, top=True, bottom=True, sides=False):
    """Soften the cut seams so rotated joints don't show hard rectangle edges."""
    a = np.array(img)[:, :, 3].astype(np.float32)
    h, w = a.shape
    n = min(FEATHER, max(1, h // 6))
    ramp = np.linspace(0.25, 1.0, n)
    if top:    a[:n, :] *= ramp[:, None]
    if bottom: a[h-n:, :] *= ramp[::-1][:, None]
    if sides:
        m = min(FEATHER, max(1, w // 6))
        r2 = np.linspace(0.35, 1.0, m)
        a[:, :m] *= r2[None, :]
        a[:, w-m:] *= r2[::-1][None, :]
    out = np.array(img)
    out[:, :, 3] = np.clip(a, 0, 255).astype(np.uint8)
    return Image.fromarray(out, 'RGBA')

def crop_part(src, rect, feather=True):
    W, H = src.size
    x0, y0, x1, y1 = rect
    box = (max(0, int(x0*W)), max(0, int(y0*H)), min(W, int(x1*W)), min(H, int(y1*H)))
    part = src.crop(box)
    if feather:
        part = feather_edges(part, top=True, bottom=True)
    canvas = Image.new('RGBA', (part.width+PAD*2, part.height+PAD*2), (0,0,0,0))
    canvas.paste(part, (PAD, PAD))
    return canvas

def synth_legs(src, cfg, name_prefix):
    """
    Build trouser limbs from the character's OWN fabric when the source art is
    cropped at the hips. Samples a patch of suit, tiles it vertically, and shapes
    it into upper leg / lower leg / shoe. No invented colors — only the art's own pixels.
    """
    W, H = src.size
    x0, y0, x1, y1 = cfg['sampleRect']
    patch = src.crop((int(x0*W), int(y0*H), int(x1*W), int(y1*H))).convert('RGBA')
    pw, ph = patch.size
    out = {}
    gap = int((1.0 - cfg.get('hipY', 0.62)) * H)      # hip -> ground, in source px
    upH, loH, shH = int(gap*0.50), int(gap*0.44), int(gap*0.16)
    specs = {'legFarU': (0.86, upH), 'legNearU': (0.90, upH),
             'legFarL': (0.74, loH), 'legNearL': (0.78, loH)}
    for nm, (wscale, hgt) in specs.items():
        w = max(10, int(pw*wscale))
        limb = Image.new('RGBA', (w, hgt), (0,0,0,0))
        y = 0
        while y < hgt:
            tile = patch.resize((w, ph), Image.LANCZOS)
            limb.paste(tile, (0, y))
            y += ph
        # taper toward the ankle and round the silhouette
        mask = Image.new('L', (w, hgt), 0)
        d = ImageDraw.Draw(mask)
        taper = 0.80 if 'L' in nm[-1] else 0.92
        d.polygon([(1, 0), (w-1, 0),
                   (int(w*(0.5+taper*0.42)), hgt-1), (int(w*(0.5-taper*0.42)), hgt-1)], fill=255)
        mask = mask.filter(ImageFilter.GaussianBlur(1.6))
        limb.putalpha(Image.composite(limb.getchannel('A'), Image.new('L',(w,hgt),0), mask))
        out[nm] = feather_edges(limb, top=True, bottom=True)
    # shoes: dark ellipse sampled from the darkest suit tone
    arr = np.array(patch)
    vis = arr[:, :, 3] > 40
    dark = arr[:, :, :3][vis]
    tone = tuple(int(v) for v in np.percentile(dark, 12, axis=0)) if len(dark) else (18,18,24)
    for nm, flip in (('footFar', False), ('footNear', True)):
        sw, sh = max(34,int(pw*0.95)), max(14, shH)
        shoe = Image.new('RGBA', (sw, sh), (0,0,0,0))
        d = ImageDraw.Draw(shoe)
        d.ellipse([0, 4, sw-1, sh-1], fill=tone+(255,))
        d.ellipse([2, 2, sw-16, sh-6], fill=tuple(min(255, c+16) for c in tone)+(255,))
        if flip: shoe = shoe.transpose(Image.FLIP_LEFT_RIGHT)
        out[nm] = shoe
    padded = {}
    for k, v in out.items():
        c = Image.new('RGBA', (v.width+PAD*2, v.height+PAD*2), (0,0,0,0))
        c.paste(v, (PAD, PAD)); padded[k] = c
    return padded

def pack(images):
    """Simple shelf packer -> (atlas image, {name: [x,y,w,h]})."""
    items = sorted(images.items(), key=lambda kv: -kv[1].height)
    maxw = 1024
    x = y = shelf = 0
    frames = {}
    for name, im in items:
        if x + im.width > maxw:
            x = 0; y += shelf; shelf = 0
        frames[name] = [x, y, im.width, im.height]
        x += im.width; shelf = max(shelf, im.height)
    total_h = y + shelf
    atlas = Image.new('RGBA', (maxw, total_h), (0,0,0,0))
    for name, im in items:
        fx, fy = frames[name][0], frames[name][1]
        atlas.paste(im, (fx, fy))
    return atlas, frames

def build(char_id):
    rig = json.load(open(f'{ROOT}/data/characters/{char_id}/rig.json'))
    src = Image.open(f'{ROOT}/assets/sprites/{char_id}.png').convert('RGBA')
    W, H = src.size
    images, meta = {}, {}

    for name, p in rig['parts'].items():
        img = crop_part(src, p['rect'])
        images[name] = img
        x0, y0, x1, y1 = p['rect']
        meta[name] = {
            'pivot': p['pivot'],
            # part size in SOURCE-normalized units, so the engine can scale to display height
            'normW': (x1-x0) + (PAD*2)/W,
            'normH': (y1-y0) + (PAD*2)/H,
        }

    if 'synthLegs' in rig:
        synth = synth_legs(src, rig['synthLegs'], char_id)
        for name, img in synth.items():
            images[name] = img
            meta[name] = {
                'pivot': [0.5, 0.08] if name.startswith('leg') else [0.45, 0.30],
                'normW': img.width / W,
                'normH': img.height / H,
            }

    atlas, frames = pack(images)
    os.makedirs(f'{ROOT}/assets/parts', exist_ok=True)
    atlas.save(f'{ROOT}/assets/parts/{char_id}_atlas.png')

    out = {'atlas': f'{char_id}_atlas', 'sourceSize': [W, H],
           'parts': {n: {**meta[n], 'frame': frames[n]} for n in images},
           'bones': rig['bones'], 'drawOrder': rig['drawOrder'],
           'handBone': rig.get('handBone'), 'handPoint': rig.get('handPoint', [0.5,0.5])}
    json.dump(out, open(f'{ROOT}/data/characters/{char_id}/parts.json','w'), indent=1)
    kb = os.path.getsize(f'{ROOT}/assets/parts/{char_id}_atlas.png')//1024
    print(f'  {char_id}: {len(images)} parts, atlas {atlas.width}x{atlas.height} ({kb} KB)')

if __name__ == '__main__':
    game = json.load(open(f'{ROOT}/data/system/game.json'))
    print('slicing rigs...')
    for cid in game['roster']:
        build(cid)
    print('done')
