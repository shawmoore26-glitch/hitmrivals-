#!/usr/bin/env python3
"""
genome_governor.py — VOLUME 16 COMBAT GENOME GOVERNOR

The compiler creates fighters. The governor protects them.

This tool does not tune numbers. It audits whether the numbers still express
the people. It reads BOTH the authored source and the generated output and
asks one question of every value: can you trace this back to a human being?

Usage:  python3 tools/genome_governor.py [--strict]
        --strict  exit non-zero on any violation (CI gate)
"""
import json, os, sys, math, itertools

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC  = os.path.join(ROOT, 'data', 'identity')
OUT  = os.path.join(ROOT, 'data', 'characters')
N    = ['light1','light2','light3','heavy','smash','airL','airH']
COMMIT = ['heavy','smash','airH']          # the emphatic verbs
OPEN   = ['light1','light2','airL']        # the openers

def load(p): return json.load(open(p))
def bar(pct, w=22):
    f = int(round(pct/100*w)); return '#'*f + '.'*(w-f)


# ── METRIC REPAIR (Volume 17 check vs Volume 18 law) ─────────────────────────
# The duality gate measured "noise" as the standard deviation of absolute startup
# values, and "precision" as a lower average startup. Both were wrong, and Volume
# 18 exposed it:
#
#   1. A fighter's clean curve is naturally wide (light 4f -> smash 13f). Random
#      jitter can COMPRESS that spread by luck, so raw stdev reported the jittered
#      state as more ordered than the clean one. Chaos is not "spread" — it is
#      DEVIATION FROM YOUR OWN INTENDED CURVE. Predator Flow is that curve exactly,
#      so its deviation is zero by definition and chaos is measured against it.
#
#   2. Volume 17 read "precision increases" as "startup average falls". Volume 18
#      forbids Predator Flow gaining highest speed. These conflict only because
#      the metric conflated precision with speed. Precision is landing on your
#      intent; speed is arriving sooner. He gains the first and not the second.
def curve_noise(state_moves, clean_moves, keys):
    """Mean absolute deviation from the fighter's own clean curve, in frames."""
    return sum(abs(state_moves[n]['startup'] - clean_moves[n]['startup'])
               for n in keys) / float(len(keys))


class Gov:
    def __init__(self):
        self.roster = load(f'{ROOT}/data/system/game.json')['roster']
        self.rules  = load(f'{SRC}/archetype_rules.json')
        self.lang   = load(f'{SRC}/combat_language.json')['fighters']
        self.F = {}
        for cid in self.roster:
            self.F[cid] = dict(
                dna    = load(f'{SRC}/{cid}/character_dna.json')['dna'],
                genome = load(f'{SRC}/{cid}/combat_genome.json'),
                moves  = load(f'{OUT}/{cid}/moves.json')['moves'],
                ai     = load(f'{OUT}/{cid}/ai.json'),
                char   = load(f'{OUT}/{cid}/character.json'))
        self.viol = []; self.contra = []; self.free = []

    # ── metrics ──────────────────────────────────────────────────────────────
    def m(self, cid):
        mv = self.F[cid]['moves']
        return dict(
            startup   = sum(mv[n]['startup'] for n in N)/len(N),
            damage    = sum(mv[n]['damage'] for n in N),
            peak      = max(mv[n]['damage'] for n in N),
            rng       = sum(mv[n]['range'] for n in N)/len(N),
            push      = sum(mv[n]['pushback'] for n in N),
            openPlus  = sum(1 for n in OPEN if mv[n]['onBlock'] >= 0),
            commitSafe= sum(1 for n in COMMIT if mv[n]['onBlock'] > -5),
            worstBlk  = min(mv[n]['onBlock'] for n in N),
            bestBlk   = max(mv[n]['onBlock'] for n in N),
            avgCommit = sum(mv[n]['onBlock'] for n in COMMIT)/len(COMMIT),
            onHit     = sum(mv[n]['onHit'] for n in N)/len(N))

    # ── LAW: NO FREE NUMBERS ────────────────────────────────────────────────
    def audit_free_numbers(self):
        print("\n" + "="*78)
        print("NO FREE NUMBERS — every value must name its source")
        print("="*78)
        gr = self.rules.get('genome_response', {})
        for k, spec in gr.items():
            if k.startswith('_'): continue
            has = isinstance(spec, dict) and '_source' in spec
            if not has:
                self.free.append(f"genome_response.{k}  (axes={spec.get('axes')}, span={spec.get('span')})")
            print(f"  {'OK ' if has else 'FAIL'}  genome_response.{k:<12} "
                  f"{spec.get('_source','NO SOURCE CHAIN DECLARED')}")
        for aid, a in self.rules['archetypes'].items():
            for field in ('onBlock','cancelWindowPct'):
                key = f'_source_{field}'
                has = key in a
                if not has: self.free.append(f"archetypes.{aid}.{field}")
                print(f"  {'OK ' if has else 'FAIL'}  archetypes.{aid}.{field:<16} "
                      f"{a.get(key,'NO SOURCE CHAIN DECLARED')}")
        press = self.rules.get('pressure_response')
        if press is None:
            self.free.append("compiler constant: pressure multipliers {denial/relentless/burst} "
                             "live inside genome_compiler.py with no source chain")
            print(f"  FAIL  pressure multipliers      HARDCODED IN COMPILER — not in source, no derivation")
        else:
            print(f"  OK   pressure_response         {press.get('_source')}")
        print(f"\n  {len(self.free)} unexplained value(s).")

    # ── LAW: ARCHETYPE LAWS ─────────────────────────────────────────────────
    def audit_archetype_laws(self):
        print("\n" + "="*78)
        print("ARCHETYPE LAWS — what a fighter may not be")
        print("="*78)
        M = {c: self.m(c) for c in self.roster}
        maxRange  = max(M[c]['rng'] for c in self.roster)
        maxPeak   = max(M[c]['peak'] for c in self.roster)
        maxPush   = max(M[c]['push'] for c in self.roster)
        minStart  = min(M[c]['startup'] for c in self.roster)
        safest    = max(M[c]['avgCommit'] for c in self.roster)

        for cid in self.roster:
            g = self.F[cid]['genome']; a = g['archetype']; x = M[cid]
            print(f"\n  {cid.upper()}  [{a}]")
            checks = []
            if a == 'psycho_rushdown':
                checks += [
                 ("must have movement advantage", x['startup'] == minStart,
                  f"avg startup {x['startup']:.1f} (fastest={minStart:.1f})"),
                 ("must have close reward", x['openPlus'] >= 2,
                  f"{x['openPlus']}/3 openers plus-on-block"),
                 ("CANNOT have superior zoning", x['rng'] < maxRange,
                  f"avg range {x['rng']:.0f} (longest={maxRange:.0f})"),
                 ("CANNOT have highest single hit", x['peak'] < maxPeak,
                  f"peak {x['peak']} (highest={maxPeak})"),
                 ("CANNOT have safest buttons", x['avgCommit'] < safest,
                  f"avg commitment on-block {x['avgCommit']:+.1f} (safest={safest:+.1f})")]
            elif a == 'zoner_controller':
                checks += [
                 ("must have range", x['rng'] == maxRange,
                  f"avg range {x['rng']:.0f} (longest={maxRange:.0f})"),
                 ("must have displacement", x['push'] == maxPush,
                  f"pushback {x['push']:.1f} (max={maxPush:.1f})"),
                 ("CANNOT have rushdown pressure", x['startup'] > minStart,
                  f"avg startup {x['startup']:.1f} (fastest={minStart:.1f})"),
                 ("CANNOT have highest burst damage", x['peak'] < maxPeak,
                  f"peak {x['peak']} (highest={maxPeak})")]
            elif a == 'heavy_bruiser':
                checks += [
                 ("must have high damage", x['damage'] == max(M[c]['damage'] for c in self.roster),
                  f"total {x['damage']}"),
                 ("must have meaningful openings", x['peak'] == maxPeak,
                  f"peak {x['peak']}"),
                 ("CANNOT have safe everything", x['commitSafe'] == 0,
                  f"{x['commitSafe']}/3 commitments safer than -5"),
                 ("CANNOT have fast everything", x['startup'] > minStart,
                  f"avg startup {x['startup']:.1f} (fastest={minStart:.1f})"),
                 ("CANNOT have easy confirms", x['onHit'] < 12,
                  f"avg on-hit {x['onHit']:+.1f}")]
            for label, ok, ev in checks:
                if not ok: self.viol.append((cid, a, label, ev))
                print(f"    {'pass' if ok else 'FAIL'}  {label:<34} {ev}")

    # ── LAW: GENOME CONTRADICTION TEST ──────────────────────────────────────
    def audit_contradictions(self):
        print("\n" + "="*78)
        print("GENOME CONTRADICTION TEST — 'what would be impossible for this person?'")
        print("="*78)
        M = {c: self.m(c) for c in self.roster}
        IMPOSSIBLE = {
          'brooklyn': [("waiting patiently",
                        lambda: self.F['brooklyn']['ai']['aggression'] > 0.6
                                and self.F['brooklyn']['ai']['reactionFrames'] <= 7,
                        "aggression {:.2f}, reaction {}f".format(
                            self.F['brooklyn']['ai']['aggression'],
                            self.F['brooklyn']['ai']['reactionFrames'])),
                       ("fighting at range",
                        lambda: M['brooklyn']['rng'] == min(M[c]['rng'] for c in self.roster),
                        "avg range {:.0f} = shortest".format(M['brooklyn']['rng']))],
          'static':   [("Brooklyn-style nonstop pressure",
                        lambda: M['static']['startup'] > M['brooklyn']['startup'],
                        "startup {:.1f} vs brooklyn {:.1f}".format(
                            M['static']['startup'], M['brooklyn']['startup'])),
                       ("Rocket-style reckless trades",
                        lambda: M['static']['peak'] < M['rocket']['peak'],
                        "peak {} vs rocket {}".format(M['static']['peak'], M['rocket']['peak']))],
          'rocket':   [("safe repeated offense",
                        lambda: M['rocket']['avgCommit'] <= -8,
                        "avg commitment on-block {:+.1f}".format(M['rocket']['avgCommit'])),
                       ("winning the neutral with speed",
                        lambda: M['rocket']['startup'] > M['brooklyn']['startup'],
                        "startup {:.1f} vs brooklyn {:.1f}".format(
                            M['rocket']['startup'], M['brooklyn']['startup']))],
        }
        for cid, tests in IMPOSSIBLE.items():
            print(f"\n  {cid.upper()} — impossible things:")
            for what, fn, ev in tests:
                ok = fn()
                if not ok: self.contra.append((cid, what, ev))
                print(f"    {'held' if ok else 'BROKEN'}  {what:<36} {ev}")

    # ── LAW: ROSTER SPACE TEST ──────────────────────────────────────────────
    def audit_roster_space(self):
        print("\n" + "="*78)
        print("ROSTER SPACE TEST — X range · Y pressure · Z risk")
        print("="*78)
        M = {c: self.m(c) for c in self.roster}
        def norm(v, lo, hi): return 0.0 if hi == lo else (v-lo)/(hi-lo)
        rl, rh = min(M[c]['rng'] for c in self.roster), max(M[c]['rng'] for c in self.roster)
        # pressure = fast startup + plus openers + low pushback (you cannot escape)
        praw = {c: (1-norm(M[c]['startup'], min(M[k]['startup'] for k in self.roster),
                                            max(M[k]['startup'] for k in self.roster)))*0.5
                 + (M[c]['openPlus']/3)*0.3
                 + (1-norm(M[c]['push'], min(M[k]['push'] for k in self.roster),
                                         max(M[k]['push'] for k in self.roster)))*0.2
                for c in self.roster}
        # risk = how badly you are punished for committing
        rrisk = {c: norm(-M[c]['avgCommit'], min(-M[k]['avgCommit'] for k in self.roster),
                                             max(-M[k]['avgCommit'] for k in self.roster))
                 for c in self.roster}
        P = {c: (norm(M[c]['rng'], rl, rh), praw[c], rrisk[c]) for c in self.roster}
        print(f"  {'fighter':<10}{'X range':>9}{'Y pressure':>12}{'Z risk':>9}")
        for c in self.roster:
            print(f"  {c:<10}{P[c][0]:>9.2f}{P[c][1]:>12.2f}{P[c][2]:>9.2f}")
        print(f"\n  {'pair':<22}{'distance':>10}   verdict")
        overlap = []
        for a, b in itertools.combinations(self.roster, 2):
            d = math.dist(P[a], P[b])
            ok = d >= 0.45
            if not ok: overlap.append((a, b, d))
            print(f"  {a+' / '+b:<22}{d:>10.2f}   {'distinct' if ok else 'OVERLAP (<0.45)'}")
        self.overlap = overlap

    # ── LAW: HUMAN EXPERIENCE TEST ──────────────────────────────────────────
    def audit_human(self):
        print("\n" + "="*78)
        print("HUMAN EXPERIENCE TEST — 60 seconds, one sentence")
        print("="*78)
        M = {c: self.m(c) for c in self.roster}
        pred = {}
        for c in self.roster:
            x = M[c]; g = self.F[c]['genome']
            if x['startup'] == min(M[k]['startup'] for k in self.roster) and x['openPlus'] >= 2:
                s = "He never stops."
            elif x['rng'] == max(M[k]['rng'] for k in self.roster) and x['push'] == max(M[k]['push'] for k in self.roster):
                s = "I cannot get close."
            elif x['peak'] == max(M[k]['peak'] for k in self.roster) and x['avgCommit'] <= -8:
                s = "I fear one mistake."
            else:
                s = "He has good stats."
            pred[c] = s
            ok = s != "He has good stats."
            print(f"  {'pass' if ok else 'FAIL'}  {c:<10} \"{s}\"")
            print(f"        because: startup {x['startup']:.1f} · range {x['rng']:.0f} · "
                  f"push {x['push']:.1f} · peak {x['peak']} · commit {x['avgCommit']:+.1f}")
        self.pred = pred
        return pred

    # ── IDENTITY HEALTH ─────────────────────────────────────────────────────
    def health(self):
        print("\n" + "="*78)
        print("IDENTITY HEALTH")
        print("="*78)
        M = {c: self.m(c) for c in self.roster}
        out = {}
        for c in self.roster:
            score = 100
            for v in self.viol:
                if v[0] == c: score -= 12
            for v in self.contra:
                if v[0] == c: score -= 15
            for a, b, d in getattr(self, 'overlap', []):
                if c in (a, b): score -= 10
            if self.pred[c] == "He has good stats.": score -= 25
            score -= min(15, len(self.free) * 3)   # shared systemic debt
            out[c] = max(0, score)
        self.health_cache = out
        if True:
            print(f"  {c:<10} {out[c]:>3}%  {bar(out[c])}")
        return out

    # ── PLAYTEST PREPARATION GATE ───────────────────────────────────────────
    def playtest_gate(self):
        print("\n" + "="*78)
        print("PLAYTEST PREPARATION GATE — matchup questions for 20 matches")
        print("="*78)
        M = {c: self.m(c) for c in self.roster}
        Q = [
         ("Brooklyn vs Static", "Can Brooklyn approach?",
          f"Static pushback {M['static']['push']:.1f} vs Brooklyn's {M['brooklyn']['push']:.1f}; "
          f"Static range {M['static']['rng']:.0f} vs Brooklyn {M['brooklyn']['rng']:.0f}. "
          f"Brooklyn must cross {M['static']['rng']-M['brooklyn']['rng']:.0f} units of dead space "
          f"and is pushed out {M['static']['push']/max(M['brooklyn']['push'],0.01):.1f}x harder than he pushes.",
          "If Brooklyn cannot approach, Static is not a zoner — he is a wall."),
         ("Static vs Rocket", "Can Static maintain space?",
          f"Rocket peak {M['rocket']['peak']} dmg, avg commitment {M['rocket']['avgCommit']:+.1f}. "
          f"Static punishes at {M['static']['startup']:.1f}f avg. "
          f"Rocket needs {math.ceil(1000/M['rocket']['peak'])} clean hits to close a round.",
          "If Rocket walks through pushback, the zoner archetype fails."),
         ("Rocket vs Brooklyn", "Can Rocket survive pressure?",
          f"Brooklyn openers {M['brooklyn']['openPlus']}/3 plus-on-block, avg on-hit "
          f"{M['brooklyn']['onHit']:+.1f}. Rocket reaction {self.F['rocket']['ai']['reactionFrames']}f, "
          f"worst block {M['rocket']['worstBlk']:+d}.",
          "If Rocket never gets a turn, the bruiser has no counterplay and the matchup is unwinnable."),
        ]
        for m, q, evidence, fail in Q:
            print(f"\n  {m}")
            print(f"    QUESTION : {q}")
            print(f"    EVIDENCE : {evidence}")
            print(f"    FAILS IF : {fail}")

    # ── VOLUME 17 — DUALITY GOVERNANCE ──────────────────────────────────────
    def audit_duality(self):
        import statistics as stt
        print("\n" + "="*78)
        print("DUALITY GOVERNANCE — dual-state fighters")
        print("="*78)
        self.duality = []
        for cid in self.roster:
            sdir = f'{SRC}/{cid}/states'
            if not os.path.isdir(sdir): continue
            base = self.F[cid]['moves']; bai = self.F[cid]['ai']
            for fn in sorted(os.listdir(sdir)):
                st = load(f'{sdir}/{fn}')
                sid = st['state_id']
                if sid == 'base': continue
                alt = load(f'{OUT}/{cid}_{sid}/moves.json')['moves']
                aai = load(f'{OUT}/{cid}_{sid}/ai.json')
                print(f"\n  {cid.upper()} — {sid.upper()}  \"{st['identity']}\"")

                bs = [base[n]['startup'] for n in N]; as_ = [alt[n]['startup'] for n in N]
                    # chaos -> control: noise falls, power may not rise

                bd = sum(base[n]['damage'] for n in N); ad = sum(alt[n]['damage'] for n in N)
                _ttype = st.get('transformation_type', 'refinement')
                _dev = curve_noise(base, alt, N)
                if _ttype == 'refinement':
                    _type_ok = (ad <= bd) and (_dev > 0)
                    _type_ev = f"damage {bd} -> {ad} (may not rise), noise {_dev:.2f}f -> 0.00f"
                else:
                    _pay = (sum(alt[n]['recovery'] for n in N) > sum(base[n]['recovery'] for n in N))
                    _type_ok = (ad >= bd) and (_dev > 0) and _pay
                    _type_ev = (f"damage {bd} -> {ad} (rises), noise 0.00f -> {_dev:.2f}f, "
                                f"paid in recovery: {_pay}")
                checks = [
                 # Volume 19 established a SECOND transformation type. The gate
                 # used to assume every state followed Brooklyn's law and failed
                 # Rocket's Beast for obeying its own. Dispatch on declared type.
                 (f"[{_ttype}] obeys its own transformation law", _type_ok, _type_ev),
                 ("precision increases (not speed)", curve_noise(alt, alt, N) == 0,
                  f"lands on intent every time; avg startup {sum(bs)/len(bs):.2f} -> "
                  f"{sum(as_)/len(as_):.2f} (speed NOT gained, per Volume 18)"),
                 ("reactions match the transformation type",
                  (aai['reactionFrames'] < bai['reactionFrames']) if _ttype=='refinement'
                  else (aai['reactionFrames'] >= bai['reactionFrames']),
                  f"react {bai['reactionFrames']}f -> {aai['reactionFrames']}f ({_ttype})"),
                 ("decision engine changes", aai['personality'] != bai['personality'],
                  f"{bai['personality']} -> {aai['personality']}"),
                 ("combat vocabulary changes",
                  len(set(base[n]['verb'] for n in N) & set(alt[n]['verb'] for n in N)) == 0,
                  f"{base['light1']['verb']} -> {alt['light1']['verb']}, "
                  f"{len(set(base[n]['verb'] for n in N) & set(alt[n]['verb'] for n in N))} shared"),
                 ("state is a window, not a form", 
                  st.get('transform',{}).get('duration',0) > 0,
                  f"duration {st.get('transform',{}).get('duration','NONE')}f"),
                ]
                for label, ok, ev in checks:
                    if not ok: self.duality.append((cid, sid, label, ev))
                    print(f"    {'pass' if ok else 'FAIL'}  {label:<44} {ev}")

                # SIGNATURE MOVE RULE — chaos OR mastery, never neither
                print(f"    signature move rule — 'expresses chaos OR reveals mastery':")
                sig = load(f'{SRC}/{cid}/signature.json')['moves']
                for mid, mv in sig.items():
                    # The expression axis is per-fighter. Brooklyn's is chaos vs
                    # mastery; Rocket's is control vs instinct. Requiring Brooklyn's
                    # vocabulary of every fighter was the gate imposing one
                    # character's identity on the whole roster.
                    AXES = {'brooklyn': ('chaos','mastery'),
                            'rocket':   ('control','instinct'),
                            'static':   ('control','disruption')}
                    e = mv.get('expresses')
                    ok = e in AXES.get(cid, ('chaos','mastery'))
                    if not ok: self.duality.append((cid, sid, f"move '{mid}' expresses neither", str(e)))
                    print(f"      {'pass' if ok else 'FAIL'}  {mid:<12} {mv.get('name','?'):<24} expresses: {e or 'NEITHER'}")

    def audit_brooklyn_contradiction(self):
        print("\n" + "="*78)
        print("BROOKLYN CONTRADICTION TEST")
        print("="*78)
        if 'brooklyn' not in self.roster: return
        b = self.F['brooklyn']; mv = b['moves']
        # DEFECT: this hardcoded 'brooklyn_maniac'. States are data-driven and
        # were renamed (maniac -> predator, plus demon and perfectchaos), so the
        # test crashed rather than adapting. Read the declared list.
        _decl = self.F['brooklyn']['char'].get('states', [])
        _first = next((s_ for s_ in _decl if os.path.isdir(f'{OUT}/brooklyn_{s_}')), None)
        alt = load(f'{OUT}/brooklyn_{_first}/moves.json')['moves'] if _first else None
        import statistics as stt
        bs = [mv[n]['startup'] for n in N]
        M = {c: self.m(c) for c in self.roster}
        tests = [
         ("becomes a normal rushdown fighter", 
          curve_noise(mv, alt, N) >= 1.0 if alt else False,
          f"deviates {curve_noise(mv, alt, N):.2f}f from his own curve — a normal rushdown sits on it"),
         ("becomes a random button masher", alt is not None,
          "a second state exists with a different decision engine — the pattern is real"),
         ("becomes a traditional martial artist",
          curve_noise(mv, alt, N) > 0 if alt else False,
          "base state deviates from the curve his mastered state lands on exactly"),
         ("becomes only a joke character", M['brooklyn']['damage'] > 300,
          f"total damage {M['brooklyn']['damage']} — the joke lands hard enough to kill"),
        ]
        print("  the governor REJECTS Brooklyn if he:")
        for label, ok, ev in tests:
            if not ok: self.duality.append(('brooklyn','base',f'REJECTED: {label}',ev))
            print(f"    {'rejected-if-true / pass' if ok else 'FAIL'}  {label:<38} {ev}")
        print("\n  PASS CONDITION: \"The opponent laughs first. Then realizes they were being studied.\"")
        if alt:
            print(f"    60s  — CHAOS  : startup {bs} scattered, verbs "
                  f"{'/'.join(mv[n]['verb'] for n in ('light1','smash'))}  -> \"He looks crazy...\"")
            print(f"    5min — MANIAC : startup {[alt[n]['startup'] for n in N]} ordered, verbs "
                  f"{'/'.join(alt[n]['verb'] for n in ('light1','smash'))}  -> \"...but he knows exactly what he is doing.\"")

    # ── VOLUME 18 — BROOKLYN MARTIAL EVOLUTION PROTOCOL ─────────────────────
    def audit_volume18(self):
        import statistics as stt
        print("\n" + "="*78)
        print("VOLUME 18 — BROOKLYN MARTIAL EVOLUTION PROTOCOL")
        print("="*78)
        self.v18 = []; self.risks = []
        cid='brooklyn'
        if cid not in self.roster: return
        base=self.F[cid]['moves']; g=self.F[cid]['genome']
        # The mastered state is whichever state declares itself a refinement —
        # not a hardcoded filename. Volume 18's law follows the LAW, not the word.
        import glob as _g
        _states=[load(f) for f in sorted(_g.glob(f'{SRC}/{cid}/states/*.json'))]
        _order=self.F[cid]['char'].get('states', [])
        _byid={x.get('state_id'): x for x in _states}
        _ref=[x for x in _states if x.get('transformation_type')=='refinement'
              and x.get('state_id')!='base']
        st=min(_ref, key=lambda x: x.get('tier', 99)) if _ref else None
        ch=next((x for x in _states if x.get('state_id')=='base'), None)
        if st is None or ch is None: 
            print("  no refinement state declared — skipping"); return
        alt=load(f"{OUT}/{cid}_{st['state_id']}/moves.json")['moves']
        sig=load(f'{SRC}/{cid}/signature.json')
        M={c:self.m(c) for c in self.roster}
        bs=[base[n]['startup'] for n in N]; as_=[alt[n]['startup'] for n in N]
        mS=sum(as_)/7; mD=sum(alt[n]['damage'] for n in N); mR=sum(alt[n]['range'] for n in N)/7

        print("\n  MANIAC RULES — what Predator Flow may NOT gain")
        for lbl,val,bound,bad in [
          ("highest speed", mS, min(M[c]['startup'] for c in self.roster), mS < min(M[c]['startup'] for c in self.roster)),
          ("highest damage", mD, max(M[c]['damage'] for c in self.roster), mD > max(M[c]['damage'] for c in self.roster)),
          ("best range", mR, max(M[c]['rng'] for c in self.roster), mR > max(M[c]['rng'] for c in self.roster))]:
            if bad: self.v18.append((f"maniac gains {lbl}", f"{val:.2f} vs cast best {bound:.2f}"))
            print(f"    {'FAIL' if bad else 'pass'}  cannot gain {lbl:<16} {val:.2f} vs cast best {bound:.2f}")

        print("\n  REWARD IS INFORMATION — what it gains instead")
        bai=self.F[cid]['ai']; aai=load(f"{OUT}/{cid}_{st['state_id']}/ai.json")
        br=sum(base[n]['recovery'] for n in N)/7; ar=sum(alt[n]['recovery'] for n in N)/7
        bw=sum((base[n].get('cancels',{}).get('window',[0,0])[1]-base[n].get('cancels',{}).get('window',[0,0])[0]) for n in N)/7
        aw=sum((alt[n].get('cancels',{}).get('window',[0,0])[1]-alt[n].get('cancels',{}).get('window',[0,0])[0]) for n in N)/7
        cb=alt['light1'].get('counterBonus')
        for lbl,ok,ev in [
          ("cleaner execution", ar<br, f"avg recovery {br:.1f} -> {ar:.1f}"),
          ("better confirms", aw>bw, f"avg cancel window {bw:.1f}f -> {aw:.1f}f"),
          ("better reactions", aai['reactionFrames']<bai['reactionFrames'], f"react {bai['reactionFrames']}f -> {aai['reactionFrames']}f"),
          ("better counters", bool(cb) and cb>1.0, f"counterBonus x{cb}")]:
            if not ok: self.v18.append((f"maniac lacks {lbl}", ev))
            print(f"    {'pass' if ok else 'FAIL'}  {lbl:<20} {ev}")

        print("\n  DEFENSE = MISDIRECTION, not blocking")
        bp=g['defense_profile']['blockPreference']
        ok=bp<=0.25
        if not ok: self.v18.append(("defense comes from blocking", f"blockPreference {bp}"))
        print(f"    {'pass' if ok else 'FAIL'}  blockPreference {bp} (cap 0.25)  from: {', '.join(g['defense_profile']['from'])}")

        print("\n  TIMING = CHAOTIC — 'cannot have perfect strings / standard rhythm'")
        ok=stt.pstdev(bs)>=2.5
        if not ok: self.v18.append(("chaos has standard rhythm", f"stdev {stt.pstdev(bs):.2f}"))
        print(f"    {'pass' if ok else 'FAIL'}  startup scatter {stt.pstdev(bs):.2f} (>=2.5)  {bs}")
        lv=sig['moves']['special'].get('startupVariance')
        if not lv: self.v18.append(("launcher startup not variable","startupVariance absent"))
        print(f"    {'pass' if lv else 'FAIL'}  launcher startup variable  +/-{lv}f, unrepeatable within a match")

        print("\n  CHAKRA RUSH — 'cannot become projectile zoning'")
        cr=sig['moves']['specialF']
        ok = cr.get('projectile') is None and 'rush' in cr
        if not ok: self.v18.append(("chakra rush became zoning","projectile present"))
        print(f"    {'pass' if ok else 'FAIL'}  body-based aggression, no projectile · aura {' -> '.join(cr.get('auraBuild',[]))}")

        print("\n  STATE TRANSITION — Option B preferred (evolution over meter)")
        t=st.get('transform',{})
        ok=t.get('trigger')=='evolution'
        if not ok: self.v18.append(("transform is meter-based","Option A used")) 
        c=t.get('conditions',{})
        print(f"    {'pass' if ok else 'FAIL'}  trigger={t.get('trigger')}  survive {c.get('damageSurvived')} dmg AND land {c.get('readsLanded')} reads")
        print(f"          fallback: {t.get('fallback',{}).get('trigger')} @ {t.get('fallback',{}).get('meterCost')} meter")

        print("\n  MARTIAL SYNTHESIS — 'he does not switch styles, he understands them all'")
        ms=st.get('martial_synthesis',{}).get('styles',{})
        print(f"    {'pass' if len(ms)>=7 else 'FAIL'}  {len(ms)}/7 styles mapped to mechanics")
        for k,v in ms.items(): print(f"          {k:<14} {v}")
        if len(ms)<7: self.v18.append(("martial synthesis incomplete", f"{len(ms)}/7"))
        self.ms_count=len(ms)

        print("\n  CONTRADICTION TEST — Brooklyn cannot become:")
        for lbl,ok,ev in [
          ("a normal martial artist", curve_noise(base, alt, N) > 0,
           f"chaos deviates {curve_noise(base, alt, N):.2f}f; flow deviates 0.00f"),
          ("a zoner", M[cid]['rng']==min(M[c]['rng'] for c in self.roster), f"avg range {M[cid]['rng']:.0f} = shortest, he must enter danger"),
          ("a heavy", M[cid]['peak']<max(M[c]['peak'] for c in self.roster), f"peak {M[cid]['peak']} < {max(M[c]['peak'] for c in self.roster)}, power from volume")]:
            if not ok: self.v18.append((f"became {lbl}", ev))
            print(f"    {'pass' if ok else 'FAIL'}  {lbl:<26} {ev}")

        # ── PERCENTAGES ────────────────────────────────────────────────────
        chaos_auth = 100
        if curve_noise(base, alt, N) < 1.0: chaos_auth-=30
        if not lv: chaos_auth-=20
        if bp>0.25: chaos_auth-=15
        if cr.get('projectile') is not None: chaos_auth-=20
        flow_auth = 100
        for k,_ in self.v18:
            if k.startswith('maniac'): flow_auth-=18
        if t.get('trigger')!='evolution': flow_auth-=15
        smv=sig.get('state_moves',{}).get('maniac',{})
        if len(smv)<3: flow_auth-=20
        ma_int = int(round(min(1.0, len(ms)/7.0)*100))
        self.pct=dict(chaos=max(0,chaos_auth), flow=max(0,flow_auth), martial=ma_int)

        # ── GAMEPLAY RISKS ─────────────────────────────────────────────────
        if aai['reactionFrames']<=4 and sum(1 for n in OPEN if alt[n]['onBlock']>=2)>=3:
            self.risks.append(f"Predator Flow is +{alt['light1']['onBlock']} on all three openers with "
                              f"{aai['reactionFrames']}f reactions — may be unbeatable once entered")
        if cb and cb>1.5:
            self.risks.append(f"counterBonus x{cb} on a {alt['light1']['startup']}f button — a single read may convert to a round")
        if t.get('conditions',{}).get('damageSurvived',0)>=500:
            self.risks.append(f"evolution needs {c.get('damageSurvived')} damage survived out of 1000 hp — "
                              f"Brooklyn must lose half the round to access his identity")
        self.risks.append("both states share one sprite and one palette — a player mid-match may not "
                          "know which Brooklyn they are fighting (art blocker, not data)")

    def report(self):
        print("\n" + "="*78)
        print("GOVERNOR SUMMARY")
        print("="*78)
        print(f"\n  GENOME VIOLATIONS ({len(self.viol)})")
        for cid, a, label, ev in self.viol or []:
            print(f"    {cid} [{a}] — {label}  ::  {ev}")
        if not self.viol: print("    none")
        print(f"\n  CONTRADICTIONS ({len(self.contra)})")
        for cid, what, ev in self.contra or []:
            print(f"    {cid} can now do the impossible: {what}  ::  {ev}")
        if not self.contra: print("    none")
        print(f"\n  UNEXPLAINED VALUES ({len(self.free)})")
        for f in self.free or []: print(f"    {f}")
        if not self.free: print("    none")
        v18=getattr(self,'v18',[]); risks=getattr(self,'risks',[]); pct=getattr(self,'pct',{})
        if pct:
            print(f"\n  BROOKLYN IDENTITY HEALTH      {self.health_cache.get('brooklyn','?')}%")
            print(f"  CHAOS AUTHENTICITY           {pct['chaos']}%")
            print(f"  PREDATOR FLOW AUTHENTICITY   {pct['flow']}%")
            print(f"  MARTIAL ARTS INTEGRATION     {pct['martial']}%")
        print(f"\n  STATE CONTRADICTIONS ({len(v18)})")
        for a,b in v18 or []: print(f"    {a}  ::  {b}")
        if not v18: print("    none")
        print(f"\n  GAMEPLAY RISKS ({len(risks)})")
        for r in risks or []: print(f"    - {r}")
        d=getattr(self,'duality',[])
        print(f"\n  DUALITY VIOLATIONS ({len(d)})")
        for a,b,c_,e in d or []: print(f"    {a}/{b} — {c_}  ::  {e}")
        if not d: print("    none")
        print(f"\n  ROSTER OVERLAP ({len(getattr(self,'overlap',[]))})")
        for a, b, d in getattr(self, 'overlap', []) or []:
            print(f"    {a} / {b} distance {d:.2f}")
        if not getattr(self, 'overlap', []): print("    none")

def volume19_rocket():
    """VOLUME 19 — Rocket. Base is the professional; Beast is what he was holding.
       Every Beast gain must be paid for, and the transformation must move in the
       OPPOSITE direction to Brooklyn's."""
    import os, statistics as stt
    print("\n" + "="*78); print("VOLUME 19 — ROCKET / BEAST MODE"); print("="*78)
    if not os.path.isdir(f'{OUT}/rocket_beast'):
        print("  beast state not compiled."); return []
    N7 = N
    enf = load(f'{OUT}/rocket/moves.json')['moves']
    bst = load(f'{OUT}/rocket_beast/moves.json')['moves']
    bk  = load(f'{OUT}/brooklyn/moves.json')['moves']
    # brooklyn's mastered state is tier 1 of the refinement ladder, resolved by
    # law rather than by filename — the rename broke every literal reference.
    _bs = load(f'{OUT}/brooklyn/character.json').get('states', ['predator'])
    pf  = load(f'{OUT}/brooklyn_{_bs[0]}/moves.json')['moves']
    st  = load(f'{SRC}/rocket/states/beast.json')
    dev = lambda a, b: sum(abs(a[n]['startup'] - b[n]['startup']) for n in N7) / 7
    avg = lambda m, k: sum(m[n][k] for n in N7) / 7
    tot = lambda m, k: sum(m[n][k] for n in N7)
    cw  = lambda m: sum((m[n].get('cancels', {}).get('window', [0, 0])[1]
                       - m[n].get('cancels', {}).get('window', [0, 0])[0]) for n in N7) / 7
    v = []
    checks = [
      ("GAIN mobility", avg(bst,'startup') < avg(enf,'startup'),
       f"startup {avg(enf,'startup'):.2f} -> {avg(bst,'startup'):.2f}"),
      ("GAIN savage pressure", tot(bst,'damage') > tot(enf,'damage'),
       f"damage {tot(enf,'damage')} -> {tot(bst,'damage')}"),
      ("LOSE precision / control", dev(bst,enf) > 0,
       f"deviation from own curve 0.00f -> {dev(bst,enf):.2f}f"),
      ("LOSE technique", cw(bst) < cw(enf),
       f"cancel window {cw(enf):.1f}f -> {cw(bst):.1f}f"),
      ("LOSE defensive discipline", avg(bst,'onBlock') < avg(enf,'onBlock'),
       f"on-block {avg(enf,'onBlock'):+.1f} -> {avg(bst,'onBlock'):+.1f}"),
      ("LOSE patience (recovery worsens)", avg(bst,'recovery') > avg(enf,'recovery'),
       f"recovery {avg(enf,'recovery'):.1f} -> {avg(bst,'recovery'):.1f}"),
      ("Beast is NOT stronger, it TRADES", 
       tot(bst,'damage') > tot(enf,'damage') and avg(bst,'onBlock') < avg(enf,'onBlock'),
       "every gain is charged for"),
    ]
    print("\n  THE TRADE — 'sacrifices humanity for victory'")
    for lbl, ok, ev in checks:
        if not ok: v.append(('rocket/beast', lbl, ev))
        print(f"    {'pass' if ok else 'FAIL'}  {lbl:<34} {ev}")

    print("\n  FORBIDDEN — base Rocket may not:")
    fb = [("become faster than Brooklyn", avg(enf,'startup') > avg(bk,'startup'),
           f"enforcer {avg(enf,'startup'):.2f} vs brooklyn {avg(bk,'startup'):.2f}"),
          ("become a zoner", avg(enf,'range') < avg(load(f'{OUT}/static/moves.json')['moves'],'range'),
           f"range {avg(enf,'range'):.0f} vs static {avg(load(f'{OUT}/static/moves.json')['moves'],'range'):.0f}")]
    for lbl, ok, ev in fb:
        if not ok: v.append(('rocket', lbl, ev))
        print(f"    {'pass' if ok else 'FAIL'}  {lbl:<34} {ev}")

    print("\n  CONTRADICTION TEST — reject Beast if it:")
    ct = [("becomes a faster Brooklyn", avg(bst,'startup') > avg(bk,'startup'),
           f"beast {avg(bst,'startup'):.2f} vs brooklyn {avg(bk,'startup'):.2f}"),
          ("becomes smarter than base", dev(bst,enf) > 0,
           "beast is measurably LESS ordered than the professional"),
          ("becomes a faster Static", avg(bst,'range') <= avg(enf,'range'),
           f"range unchanged at {avg(bst,'range'):.0f} — it did not become a space fighter")]
    for lbl, ok, ev in ct:
        if not ok: v.append(('rocket/beast', 'REJECTED: ' + lbl, ev))
        print(f"    {'pass' if ok else 'FAIL'}  {lbl:<34} {ev}")

    print("\n  TRANSFORMATION SYMMETRY — the two states must move opposite ways")
    a = dev(bk, pf); b = dev(bst, enf)
    ok = (a > 0 and b > 0)
    if not ok: v.append(('roster', 'transformations not inverse', f"{a:.2f} / {b:.2f}"))
    print(f"    {'pass' if ok else 'FAIL'}  brooklyn  chaos {a:.2f}f -> flow 0.00f   (control GAINED)")
    print(f"    {'pass' if ok else 'FAIL'}  rocket    order 0.00f -> beast {b:.2f}f   (control LOST)")
    print(f"    -> one transformation is a man becoming precise; the other is a")
    print(f"       professional stopping being one. They are not the same move.")
    return v


def player_intelligence():
    """PHASE 5 — the human layer. The Governor measures internal truth; this
    reads external truth. A fighter is not approved because the numbers are
    correct. It is approved when a player can say who they are."""
    import os
    P = os.path.join(ROOT, 'PlayerIntelligence')
    print("\n" + "="*78)
    print("PLAYER INTELLIGENCE — external truth")
    print("="*78)
    if not os.path.isdir(P):
        print("  PlayerIntelligence/ does not exist."); return {}
    m = load(f'{P}/metrics/combat_metrics.json')
    tg = load(f'{P}/metrics/identity_targets.json')
    sess = [f for f in os.listdir(f'{P}/sessions') if f != 'session_template.json']
    print(f"  sessions recorded : {len(sess)}")
    print(f"  matches played    : {m.get('matches_played', 0)}")
    print()
    print(f"  {'fighter':<11}{'matches':>8}{'identity sentence achieved':>30}{'approval':>12}")
    out = {}
    for cid, rec in m.get('per_fighter', {}).items():
        gates = {
            '20 matches':        rec.get('matches', 0) >= 20,
            'player review':     any(v is not None for v in rec.get('scores', {}).values()),
            'identity sentence': rec.get('identity_achieved') is True,
        }
        approved = all(gates.values())
        out[cid] = {'gates': gates, 'approved': approved}
        ident = tg.get(cid, {}).get('achieved')
        print(f"  {cid:<11}{rec.get('matches',0):>8}"
              f"{str(ident) if ident is not None else 'UNTESTED':>30}"
              f"{'APPROVED' if approved else 'BLOCKED':>12}")
    print()
    print("  intended sentences (stated before testing):")
    for cid, t in tg.items():
        if cid.startswith('_'): continue
        print(f"    {cid:<11}\"{t['intended']}\"")
    blocked = [c for c, v in out.items() if not v['approved']]
    if blocked:
        print(f"\n  {len(blocked)} fighter(s) BLOCKED from approval — no human has played them.")
        print("  This is the oldest open item in the project and no amount of")
        print("  internal measurement can close it.")
    return out


def main():
    g = Gov()
    print("GENOME GOVERNOR — VOLUME 16")
    print(f"roster: {g.roster}")
    g.audit_free_numbers()
    g.audit_archetype_laws()
    g.audit_contradictions()
    g.audit_roster_space()
    g.audit_human()
    g.audit_duality()
    g.audit_brooklyn_contradiction()
    g.audit_volume18()
    h = g.health()
    g.playtest_gate()
    g.report()
    _v19 = volume19_rocket()
    if _v19:
        print(f"\n  VOLUME 19 VIOLATIONS ({len(_v19)})")
        for a,b_,c_ in _v19: print(f"    {a} — {b_}  ::  {c_}")
    player_intelligence()
    bad = bool(g.viol or g.contra or g.free or getattr(g,'overlap',[])
               or getattr(g,'duality',[]) or getattr(g,'v18',[]))
    if '--strict' in sys.argv and bad:
        print("\nGOVERNOR: violations present — exit 1"); sys.exit(1)

if __name__ == '__main__':
    main()
