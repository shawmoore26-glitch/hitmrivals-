#!/usr/bin/env python3
"""
rig_validate.py — MEASURE THE RIG. DO NOT GUESS.

Every part rect in design.json was estimated by eye. This tool measures what is
actually in the pixels and reports where the estimates fail:

  * true opaque bounds of each slice vs the rect that was authored
  * overlap between a part and its parent (the seam budget)
  * the maximum rotation each bone can take before its seam opens
  * pivot verification: is the pivot inside opaque pixels?

Writes data/characters/<id>/rig_validation.json
"""
import json, os, sys, math
import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A_THRESH = 30

def opaque_mask(img):
    return np.array(img.convert('RGBA'))[:, :, 3] > A_THRESH

def measure(cid):
    src = Image.open(f'{ROOT}/assets/sprites/{cid}.png').convert('RGBA')
    SW, SH = src.size
    M = opaque_mask(src)
    rig = json.load(open(f'{ROOT}/data/characters/{cid}/rig.json'))
    bones = {b['name']: b for b in rig['bones']}
    out, issues = {}, []

    for name, p in rig['parts'].items():
        x0, y0, x1, y1 = p['rect']
        px0, py0 = int(x0 * SW), int(y0 * SH)
        px1, py1 = int(x1 * SW), int(y1 * SH)
        sub = M[py0:py1, px0:px1]
        if sub.size == 0:
            issues.append((name, 'EMPTY RECT')); continue
        fill = float(sub.mean())

        # true opaque bounds inside the authored rect
        ys, xs = np.where(sub)
        if len(xs) == 0:
            issues.append((name, 'NO OPAQUE PIXELS')); continue
        tx0 = (px0 + xs.min()) / SW; tx1 = (px0 + xs.max() + 1) / SW
        ty0 = (py0 + ys.min()) / SH; ty1 = (py0 + ys.max() + 1) / SH

        # slack: authored rect minus true content, in source pixels.
        # slack is GOOD on the joint edge (it is the overlap that hides a seam)
        # and WASTE on the free edge.
        slack = {
            'left':   round((tx0 - x0) * SW, 1), 'right':  round((x1 - tx1) * SW, 1),
            'top':    round((ty0 - y0) * SH, 1), 'bottom': round((y1 - ty1) * SH, 1),
        }

        # pivot verification — must land on opaque pixels
        pv = p['pivot']
        ppx = int(px0 + pv[0] * (px1 - px0)); ppy = int(py0 + pv[1] * (py1 - py0))
        r_ = 5
        nb = M[max(0,ppy-r_):ppy+r_, max(0,ppx-r_):ppx+r_]
        pivot_ok = bool(nb.size and nb.mean() > 0.12)

        b = bones.get(name, {})
        parent = b.get('parent')
        overlap_px, overlap_zone = 0.0, None
        # A control bone (hip, neck, shoulder*) has no drawn part. Overlap
        # against it is UNDEFINED, not zero — flagging it was a tool defect
        # that reported 13 false seam risks on the first run.
        # Walk up to the nearest DRAWN ancestor. A coat parented to 'hip' still
        # has to hide its seam against the torso — the control bone is a pivot,
        # not a covering surface. Stopping at the control bone reported a 0-degree
        # safe rotation for every coat and tail in the roster.
        # A seam is hidden by whatever is drawn UNDERNEATH this part, which is
        # not always its bone parent — Brooklyn's coat hangs off 'hip' (a control
        # bone) but is covered by the torso. Measure against every part drawn
        # earlier in drawOrder and keep the best coverage.
        # Either stacking order hides a seam: a coat drawn FIRST is covered by
        # the torso drawn on top of it. Measuring only earlier parts reported a
        # 0-degree limit for every part at the bottom of the draw stack.
        order = rig['drawOrder']
        best = (0.0, None)
        for other in [o for o in order if o != name]:
            q = rig['parts'].get(other)
            if not q: continue
            ox = max(0.0, min(x1, q['rect'][2]) - max(x0, q['rect'][0])) * SW
            oy = max(0.0, min(y1, q['rect'][3]) - max(y0, q['rect'][1])) * SH
            ov = min(ox, oy)
            if ov > best[0]: best = (ov, other)
        overlap_px, overlap_zone = round(best[0], 1), best[1]
        parent_drawn = overlap_zone is not None

        # ── ROTATION LIMIT ──────────────────────────────────────────────────
        # Rotating about the pivot swings the far edge by r*theta. A seam opens
        # when that displacement exceeds the overlap with the parent. Solve for
        # the angle at which the joint stops being covered.
        # Distance from pivot to the NEAREST edge = the joint edge. That edge is
        # what can separate. Using the FAR edge (first attempt) reported a 3-degree
        # limit on a dread that is attached at its top and free at its bottom.
        dx_edge = min(abs(pv[0]), abs(1 - pv[0])) * (px1 - px0)
        dy_edge = min(abs(pv[1]), abs(1 - pv[1])) * (py1 - py0)
        radius = max(1.0, min(dx_edge, dy_edge) if min(dx_edge, dy_edge) > 0
                          else max(dx_edge, dy_edge))
        if overlap_px > 0 and radius > 0:
            lim = math.degrees(math.asin(min(1.0, overlap_px / radius)))
        else:
            lim = 0.0
        declared = (b.get('follow') or {}).get('maxAngle')

        rec = {
            'bone': name, 'parent': parent,
            'authored_rect': [round(v, 4) for v in p['rect']],
            'measured_rect': [round(tx0, 4), round(ty0, 4), round(tx1, 4), round(ty1, 4)],
            'fill_pct': round(fill * 100, 1),
            'slack_px': slack,
            'pivot': pv,
            'pivot_on_opaque': pivot_ok,
            'overlap_px': overlap_px,
            'overlap_zone': overlap_zone,
            'overlap_required': parent_drawn,
            'covering_ancestor': overlap_zone,
            'parent_is_control_bone': bool(parent) and parent not in rig['parts'],
            'safe_rotation_deg': round(lim, 1),
            'declared_maxAngle': declared,
            'verdict': 'ok',
        }
        if not pivot_ok:
            # suggest a corrected pivot: nearest opaque pixel to the declared one
            oy_, ox_ = np.where(sub)
            d = (ox_ - pv[0]*(px1-px0))**2 + (oy_ - pv[1]*(py1-py0))**2
            k = int(np.argmin(d))
            rec['suggested_pivot'] = [round(float(ox_[k])/max(1,(px1-px0)), 3),
                                      round(float(oy_[k])/max(1,(py1-py0)), 3)]
            rec['verdict'] = 'PIVOT OFF-MODEL'
            issues.append((name, f"pivot {pv} on transparency; nearest opaque {rec['suggested_pivot']}"))
        elif parent_drawn and overlap_px < 4:
            rec['verdict'] = 'SEAM RISK'; issues.append((name, f'only {overlap_px}px overlap with {parent}'))
        elif declared is not None and declared > lim + 0.5:
            rec['verdict'] = 'OVER-ROTATION'
            issues.append((name, f'declared {declared}deg exceeds measured safe {lim:.1f}deg'))
        out[name] = rec
    return out, issues, (SW, SH)

def main():
    fix = '--fix' in sys.argv
    roster = json.load(open(f'{ROOT}/data/system/game.json'))['roster']
    total = 0
    print("rig_validate — measured, not estimated\n")
    for cid in roster:
        out, issues, size = measure(cid)
        ok = sum(1 for r in out.values() if r['verdict'] == 'ok')
        print(f"── {cid.upper()}  sprite {size[0]}x{size[1]}  {len(out)} parts  "
              f"{ok} clean / {len(out)-ok} flagged")
        for n, why in issues:
            print(f"     {out.get(n,{}).get('verdict','ISSUE'):<16} {n:<13} {why}")
        total += len(issues)
        doc = {'_generated': 'rig_validate.py — measured from source pixels',
               '_source_size': size, 'parts': out,
               '_issues': [{'part': n, 'why': w} for n, w in issues]}
        json.dump(doc, open(f'{ROOT}/data/characters/{cid}/rig_validation.json', 'w'), indent=2)

        if fix:
            # clamp every declared maxAngle to the measured safe limit
            design_p = f'{ROOT}/data/identity/{cid}/design.json'
            d = json.load(open(design_p)); changed = []
            for n, e in d.get('features', {}).items():
                if n in out and e.get('maxAngle', 0) > out[n]['safe_rotation_deg']:
                    old = e['maxAngle']
                    e['maxAngle'] = max(6, int(out[n]['safe_rotation_deg']))
                    e['_maxAngle_measured'] = (
                        f"clamped {old} -> {e['maxAngle']} by rig_validate.py: "
                        f"{out[n]['overlap_px']}px overlap with {out[n]['parent']} "
                        f"cannot hide a larger swing")
                    changed.append((n, old, e['maxAngle']))
            if changed:
                json.dump(d, open(design_p, 'w'), indent=2)
                for n, o, v in changed:
                    print(f"     CLAMPED         {n:<13} maxAngle {o} -> {v}")
        print()
    print(f"{total} issues found." if total else "no issues.")
    sys.exit(0 if total == 0 else 1)

if __name__ == '__main__':
    main()
