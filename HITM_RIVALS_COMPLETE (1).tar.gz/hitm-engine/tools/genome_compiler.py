#!/usr/bin/env python3
"""
genome_compiler.py — VOLUME 14 COMBAT GENOME & IDENTITY COMPILER

    CHARACTER SOUL  ->  PLAYABLE COMBAT IDENTITY

Replaces identity_compiler.py, which violated 7 of 8 Volume 14 laws — most
seriously the Immutability Law: it snapshotted its own output and read it back
as source. That made it reproducible and illegal at the same time.

SOURCE (read-only, authored):
    data/identity/archetype_rules.json
    data/identity/combat_language.json
    data/identity/<id>/character_dna.json
    data/identity/<id>/combat_genome.json
    data/identity/<id>/signature.json
    data/identity/<id>/identity.json

OUTPUT (written, never read back):
    data/characters/<id>/moves.json
    data/characters/<id>/character.json
    data/characters/<id>/ai.json

The compiler NEVER opens data/characters/. Frame data is generated from the
neutral skeleton in archetype_rules.json, bent by DNA, then gated by archetype.

Usage:  python3 tools/genome_compiler.py [--check] [--report]
"""
import json, os, sys, copy, hashlib

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC  = os.path.join(ROOT, 'data', 'identity')
OUT  = os.path.join(ROOT, 'data', 'characters')
NORMALS = ['light1','light2','light3','heavy','smash','airL','airH']

# ── IMMUTABILITY GUARD ───────────────────────────────────────────────────────
class SourceOnly:
    """Volume 14: generated files are outputs only. Enforced, not promised."""
    def __init__(self): self.reads = []
    def json(self, path):
        real = os.path.abspath(path)
        if os.path.abspath(OUT) in real:
            raise RuntimeError(
                f"IMMUTABILITY LAW VIOLATION: compiler attempted to read generated "
                f"output {os.path.relpath(real, ROOT)}")
        self.reads.append(os.path.relpath(real, ROOT))
        return json.load(open(real))

def lerp(a, b, t): return a + (b - a) * max(0.0, min(1.0, t))

def response(dna, spec):
    """Bend one skeleton field by weighted DNA axes. Returns a multiplier."""
    t = 0.5
    for axis, w in zip(spec['axes'], spec['weights']):
        t += (dna.get(axis, 50) / 100.0 - 0.5) * w
    lo, hi = spec['span']
    return lerp(lo, hi, t)

def jitter_for(genome, name):
    """Volume 5 'Skip': frames are missing. Startups must not form a curve.
       Derived from the genome's rhythm signature, not hardcoded per fighter."""
    # DEFECT REPAIRED: only 'absent' produced irregularity, so Brooklyn — whose
    # Chaos State genome REQUIRES "irregular timing" and "broken rhythm" — came
    # out on a perfectly smooth startup curve. He was a normal rushdown fighter
    # wearing chaos as a description. Amplitude now follows the beat category:
    #   absent  — there is no beat. Wide scatter. You cannot find him.
    #   broken  — a beat exists; he lands beside it. Narrower, but never on time.
    #   delayed / other — deliberate, on-beat. No scatter.
    amp = {'absent': 3, 'broken': 2}.get(genome['rhythm_profile']['beat'], 0)
    if not amp:
        return 0
    # deterministic irregularity seeded by fighter+move — never random
    h = int(hashlib.md5((genome['archetype'] + name).encode()).hexdigest(), 16)
    return (h % (amp * 2 + 1)) - amp

def ai_base_for_state(arch, dna, st):
    """A state's AI inherits the archetype chassis but swaps the decision engine."""
    a = dict(arch['ai'])
    a['personality']    = st['ai']['engine']
    a['behaviours']     = st['ai']['behaviours']
    a['goal']           = st['ai']['goal']
    noise = st.get('noise', 1.0)
    a['aggression']     = round(lerp(0.15, 0.95, dna['aggression']/100.0), 2)
    a['whiffPunish']    = round(lerp(0.20, 0.95, dna['precision']/100.0) * lerp(1.25, 1.0, noise), 2)
    a['reactionFrames'] = int(round(lerp(4, 12, dna['patience']/100.0) * lerp(0.65, 1.0, noise)))
    a['guardBreakRead'] = round(min(0.95, lerp(0.20, 0.90, dna['discipline']/100.0) * lerp(1.35, 1.0, noise)), 2)
    a['_generated']     = 'genome_compiler.py'
    return a


def compile_fighter(cid, io):
    dna_doc = io.json(f'{SRC}/{cid}/character_dna.json')
    dna     = dna_doc['dna']
    genome  = io.json(f'{SRC}/{cid}/combat_genome.json')
    sig     = io.json(f'{SRC}/{cid}/signature.json')
    ident   = io.json(f'{SRC}/{cid}/identity.json')
    rules   = io.json(f'{SRC}/archetype_rules.json')
    lang    = io.json(f'{SRC}/combat_language.json')['fighters'][cid]

    arch = rules['archetypes'][genome['archetype']]
    gr   = rules['genome_response']
    skel = rules['skeleton']

    mul = {k: response(dna, gr[k]) for k in gr if k != '_note'}
    moves = {}

    for i, name in enumerate(NORMALS):
        s = copy.deepcopy(skel[name]); s.pop('role', None)
        role = skel[name]['role']
        verb = lang['combat_verbs'][i % len(lang['combat_verbs'])]
        motion = lang['motion_verbs'][i % len(lang['motion_verbs'])]

        m = dict(s)
        clean_startup  = max(3, round(s['startup'] * mul['startup']))
        m['startup']   = max(3, clean_startup + jitter_for(genome, name))
        m['_cleanStartup'] = clean_startup
        m['damage']    = max(1, round(s['damage'] * mul['damage']))
        # RANGE PROFILE owns space. The genome declares a dominant band; DNA only
        # modulates within it. Previously range came from DNA alone, which let two
        # fighters with different declared bands land on the same number.
        band   = genome['range_profile']['dominant']
        anchor = band / float(skel['light1']['range'])
        m['range'] = max(20, round(s['range'] * anchor * lerp(0.96, 1.06, dna['precision']/100.0)))

        # PRESSURE PROFILE owns distance control. Denial pushes you out, relentless
        # refuses to let you leave, burst drives through you.
        # VOLUME 16 NO FREE NUMBERS: pressure intents live in archetype_rules.json
        # with a declared source chain and a stated limit. The compiler holds no
        # design opinions of its own.
        press = rules['pressure_response'][genome['pressure_profile']['style']]
        m['pushback'] = round(s['pushback'] * press * mul['pushback'], 2)
        m['hitstun']   = max(4, round(s['hitstun'] * mul['hitstun']))
        m['blockstun'] = max(3, round(s['blockstun'] * mul['blockstun']))
        m['hitstop']   = genome['impact_profile']['hitstop']

        # COMBAT DIRECTOR GATE — archetype owns on-block advantage.
        # Solved through recovery only; DNA-derived fields are never overwritten.
        tgt = arch['onBlock'][role]
        m['recovery'] = max(3, m['blockstun'] - (m['active'] - 1) - tgt)
        total = m['startup'] + m['active'] + m['recovery']

        chain = rules['skeleton']  # cancel targets follow the skeleton's chain shape
        into = {'light1': ['light2','heavy','smash','special','blockbuster'],
                'light2': ['light3','heavy','smash','special','blockbuster'],
                'light3': ['heavy','smash','special','blockbuster'],
                'heavy':  ['smash','special','blockbuster'],
                'smash':  ['special','blockbuster'],
                'airL':   ['airH','special'],
                'airH':   ['special']}[name]
        lo = m['startup']
        hi = max(lo + 1, int(round(total * arch['cancelWindowPct'])))
        m['cancels'] = {'into': into, 'window': [lo, min(total, hi)]}

        # VOLUME 14 MOVE GENERATION FORMAT — all 16 fields
        m['name']   = f"{verb.title()} {role.title()}"
        m['type']   = 'normal'
        m['verb']   = verb
        m['motionVerb'] = motion
        m['purpose'] = {
            'opener':   'open the sentence — fast, cheap, deniable',
            'connector':'rotate the angle and keep the turn',
            'ender':    'close the sentence and take the ground',
            'emphatic': 'the only verb permitted to break his rhythm'}[role]
        m['onHit']   = m['hitstun'] - (m['active'] - 1) - m['recovery']
        m['onBlock'] = tgt
        m['animationIntent'] = f"{motion} — {genome['rhythm_profile']['signature']}"
        m['facial']  = genome['philosophy']
        m['sound']   = genome['impact_profile']['soundIntent']
        m['vfx']     = f"{genome['impact_profile']['cameraShake']} shake · {genome['weight_profile']['categorical'].lower()} impact"
        m.pop('_cleanStartup', None) if False else None
        moves[name] = m

    # signature moves pass through untouched — hand-authored, never generated
    for k, v in sig['moves'].items():
        moves[k] = v

    # ── VOLUME 17 — CHARACTER EVOLUTION ─────────────────────────────────────
    # A fighter may declare alternate combat states. A state is not a power-up:
    # it is a different way of using the same body, so it re-derives from the
    # SAME dna and the SAME skeleton — only the state's own genome differs.
    states = {}
    sdir = f'{SRC}/{cid}/states'
    if os.path.isdir(sdir):
        for fn in sorted(os.listdir(sdir)):
            st = io.json(f'{sdir}/{fn}')
            if st['state_id'] == 'base': continue
            states[st['state_id']] = st

    moves_doc = {'_generated': 'genome_compiler.py — do not hand-edit',
                 'chains': sig['chains'], 'projectiles': sig['projectiles'], 'moves': moves}

    # character.json — stats derive from genome, identity passes through
    char = {k: v for k, v in ident.items() if not k.startswith('_')}
    char['archetype'] = f"{genome['combat_verbs'][0]} · {genome['archetype'].replace('_',' ')}"
    char['stats'] = {
        'speed':      round(lerp(0.92, 1.20, dna['speed']/100.0), 2),
        'power':      round(lerp(0.86, 1.14, dna['violence']/100.0), 2),
        'healthMult': round(lerp(0.88, 1.12, dna['weight']/100.0), 2)}
    if genome.get('read_engine'): char['readEngine'] = genome['read_engine']
    char['ai']    = f'data/characters/{cid}/ai.json'
    char['moves'] = f'data/characters/{cid}/moves.json'
    char['_generated'] = 'genome_compiler.py'

    # ai.json — AI INHERITS THE GENOME (Volume 14 AI Integration)
    ai = dict(arch['ai'])
    ai['aggression']     = round(lerp(0.15, 0.95, dna['aggression']/100.0), 2)
    ai['zoning']         = round(lerp(0.05, 0.92, (100 - dna['aggression'])/100.0 * (dna['patience']/100.0) * 1.6), 2)
    ai['dashLove']       = round(lerp(0.10, 0.95, dna['speed']/100.0), 2)
    ai['whiffPunish']    = round(lerp(0.20, 0.90, dna['precision']/100.0), 2)
    ai['guardBreakRead'] = round(lerp(0.20, 0.90, dna['discipline']/100.0), 2)
    ai['reactionFrames'] = int(round(lerp(4, 12, dna['patience']/100.0)))
    ai['behaviours']     = genome['ai_intent']
    ai['_generated']     = 'genome_compiler.py'

    if states:
        # order by declared tier, not by filename
        char['states'] = [k for k, _ in sorted(states.items(),
                          key=lambda kv: kv[1].get('tier', 99))]
        ev = rules.get('evolution_response', {})
        dur = int(round(ev.get('base_round_frames', 3600) * ev.get('share', 0.167)))
        char['evolution'] = {}
        for sid, st in states.items():
            t = st.get('transform', {})
            char['evolution'][sid] = {
                'trigger': t.get('trigger', 'meter'),
                'conditions': t.get('conditions', {}),
                'fallbackMeter': t.get('fallback', {}).get('meterCost', 100),
                'duration': dur}

    # Derive each alternate state's move table from the base table.
    # "The transformation is not more power. The transformation is less noise."
    # noise=1.0 keeps the chaos jitter; noise=0.0 removes it entirely and pays
    # the fighter back in precision — recovery and startup tighten, damage does
    # NOT rise. Mastery is efficiency, not strength.
    alt = {}
    for sid, st in states.items():
        smoves = {}
        for i, n in enumerate(NORMALS):
            m = copy.deepcopy(moves[n])
            # VOLUME 18 MANIAC RULES — "cannot gain highest damage / speed / range".
            # Removing the jitter is the whole speed story: he stops being early or
            # late, he does not become fast. speed_gain is 0.0 and the governor
            # checks it. The reward is INFORMATION, paid out below.
            # DEFECT REPAIRED: the state used to un-jitter by SUBTRACTING the jitter
            # from the chaos value. Where jitter had pushed a startup below the
            # 3-frame floor the clamp had already eaten part of it, so subtracting
            # over-corrected and ADDED scatter — Predator Flow came out more
            # chaotic than Drunken Chaos (3.23 vs 2.76), the exact inverse of the
            # character. Both states now derive from the same clean pre-jitter
            # value. A state is a sibling of the base, never a function of it.
            # A state may reduce noise (Predator Flow: chaos -> control) or ADD
            # it (Beast: control -> instinct). Both start from the clean curve;
            # the state's own noise value decides which direction it moves.
            clean = m.pop('_cleanStartup', m['startup'])
            st_noise = st.get('noise', 0.0)
            if st_noise > 0:
                import hashlib as _h
                amp = max(1, int(round(3 * st_noise)))
                hh = int(_h.md5((sid + n).encode()).hexdigest(), 16)
                m['startup'] = max(3, clean + (hh % (amp * 2 + 1)) - amp)
            else:
                m['startup'] = clean
            noise = st.get('noise', 1.0)
            sg = st.get('speed_gain', 0.0)
            m['startup']  = max(3, round(m['startup'] * (1.0 - sg)))
            m['recovery'] = max(3, round(m['recovery'] * st.get('execution_gain', 1.0)))
            # Volume 18 forbids Predator Flow gaining damage. Volume 19 PERMITS
            # Beast damage, because Volume 19 charges for it — recovery, cancel
            # windows and on-block safety all get worse. A gain with no cost is
            # what both laws actually forbid.
            m['damage'] = int(round(m['damage'] * st.get('damage_gain', 1.0)))
            m['range']  = m['range']                               # LIMIT: never rises
            # better counters — a read, proven
            if st.get('counter_gain'):
                m['counterBonus'] = round(st['counter_gain'], 2)
            m['verb']     = st['combat_verbs'][i % len(st['combat_verbs'])]
            m['motionVerb'] = m['verb'].title()
            m['name']     = f"{m['verb'].title()} {skel[n]['role'].title()}"
            m['onBlock']  = m['blockstun'] - (m['active'] - 1) - m['recovery']
            total = m['startup'] + m['active'] + m['recovery']
            m['onHit']    = m['hitstun'] - (m['active'] - 1) - m['recovery']
            c = m.get('cancels', {})
            if c.get('window'):
                lo = m['startup']
                pct = min(0.95, arch['cancelWindowPct'] * st.get('confirm_gain', 1.0))
                end = int(round(total * pct)) + st.get('confirm_frames', 0)
                c['window'] = [lo, min(total, max(lo + 1, end))]
            # defensive discipline is a declared loss: pay it on block
            # Volume 16 still applies inside a transformation. Mastery buys
            # economy, not immunity.
            cap = st.get('onblock_cap')
            if cap is not None:
                ob = m['blockstun'] - (m.get('active',1) - 1) - m['recovery']
                if ob > cap:
                    m['recovery'] = m['blockstun'] - (m.get('active',1) - 1) - cap
                    m['onBlock']  = cap
            if st.get('onblock_penalty'):
                m['recovery'] = max(3, m['recovery'] - st['onblock_penalty'])
                m['onBlock']  = m['blockstun'] - (m['active'] - 1) - m['recovery']
            m['animationIntent'] = f"{m['verb'].title()} — {st['stance']['name']}: " + \
                                   ', '.join(st['stance']['traits'][:3])
            m['facial'] = st['identity']
            m['state']  = sid
            smoves[n] = m
        # A state may replace signature moves entirely (Predator Flow moves).
        smov = sig.get('state_moves', {}).get(sid, {})
        for k, v in sig['moves'].items():
            if k == 'maniac': continue
            smoves[k] = smov.get(k, v)
        sai = dict(ai_base_for_state(arch, dna, st))
        alt[sid] = ({'_generated': 'genome_compiler.py', '_state': sid,
                     'chains': sig['chains'], 'projectiles': sig['projectiles'],
                     'moves': smoves}, sai)

    # helper field is internal to compilation — never ships
    for _m in moves.values(): _m.pop('_cleanStartup', None)
    return moves_doc, char, ai, genome, lang, arch, alt


def gates(built, lang_all):
    """Volume 14 Quality Gates. Any FAIL halts the compile."""
    ok = True
    print("\nQUALITY GATES")

    # IDENTITY GATE / EXPRESSION GATE — Law 7
    ids = list(built)
    print("  IDENTITY GATE — 'Could another fighter use this move?'")
    for i in range(len(ids)):
        for k in range(i + 1, len(ids)):
            a, b = ids[i], ids[k]
            ma, mb = built[a][0]['moves'], built[b][0]['moves']
            fields = ('startup','recovery','damage','range','pushback','hitstun','blockstun')
            shared = [n for n in NORMALS
                      if tuple(ma[n][f] for f in fields) == tuple(mb[n][f] for f in fields)]
            if shared: ok = False
            print(f"    {'FAIL' if shared else 'pass'}  {a} vs {b}  "
                  f"{'SHARED: '+','.join(shared) if shared else 'all 7 normals differ'}")

    # BALANCE GATE — the defender must always have opportunities
    print("  BALANCE GATE — 'No fighter may have every move safe.'")
    for cid, (mv, *_r) in built.items():
        pun = [n for n in NORMALS if mv['moves'][n]['onBlock'] <= -3]
        safe = [n for n in NORMALS if mv['moves'][n]['onBlock'] >= 0]
        good = len(pun) >= 2
        if not good: ok = False
        print(f"    {'pass' if good else 'FAIL'}  {cid:<9} punishable(-3 or worse): "
              f"{len(pun)}/7 {pun}  safe/plus: {len(safe)}/7")

    # COMBAT GATE — do they play differently
    print("  COMBAT GATE — measurable separation")
    prof = {}
    for cid, (mv, *_r) in built.items():
        m = mv['moves']
        prof[cid] = (sum(m[n]['startup'] for n in NORMALS)/7,
                     sum(m[n]['damage'] for n in NORMALS),
                     sum(m[n]['range'] for n in NORMALS)/7,
                     sum(m[n]['pushback'] for n in NORMALS))
    for cid, p in prof.items():
        print(f"    {cid:<9} startup {p[0]:5.1f}  damage {p[1]:4.0f}  "
              f"range {p[2]:5.0f}  pushback {p[3]:5.1f}")
    spread = max(p[1] for p in prof.values()) / min(p[1] for p in prof.values())
    print(f"    {'pass' if spread > 1.15 else 'FAIL'}  damage spread {spread:.2f}x (>1.15 required)")
    if spread <= 1.15: ok = False

    # COMBAT LANGUAGE VALIDATOR — animation intent vs forbidden verbs
    print("  ANIMATION GATE — 'Does the animation match the verb?'")
    for cid, (mv, _c, _a, _g, lang, *_r) in built.items():
        bad = []
        # DEFECT REPAIRED: the validator matched forbidden words as raw substrings
        # and flagged Static's own rule — "startups must not form a SMOOTH curve" —
        # as off-model. A prohibition that names the thing it prohibits is not a
        # violation. Negated clauses are excluded before matching.
        NEG = ('not ', 'no ', 'never ', 'without ')
        for n in NORMALS:
            intent = mv['moves'][n]['animationIntent'].lower()
            for f in list(lang['animation_rejected']) + list(lang['forbidden']):
                fl = f.lower()
                i = intent.find(fl)
                while i != -1:
                    window = intent[max(0, i - 24):i]
                    if not any(neg in window for neg in NEG):
                        bad.append((n, f)); break
                    i = intent.find(fl, i + 1)
        if bad: ok = False
        print(f"    {'FAIL' if bad else 'pass'}  {cid:<9} "
              f"{'off-model: '+str(bad) if bad else 'no forbidden verbs in animation intent'}")
    return ok


def main():
    check  = '--check' in sys.argv
    io = SourceOnly()
    roster = json.load(open(f'{ROOT}/data/system/game.json'))['roster']
    lang_all = io.json(f'{SRC}/combat_language.json')

    print("genome_compiler — VOLUME 14")
    print(f"roster: {roster}")

    built = {}
    for cid in roster:
        built[cid] = compile_fighter(cid, io)

    for cid, (mv, ch, ai, genome, lang, arch, alt) in built.items():
        print(f"\n── {cid.upper()}  [{genome['archetype']}]")
        print(f"   philosophy : {genome['philosophy']}")
        print(f"   verbs      : {' '.join(genome['combat_verbs'])}")
        print(f"   grammar    : {lang['grammar']}")
        print(f"   {'move':<8}{'verb':<11}{'su':>4}{'act':>4}{'rec':>4}{'dmg':>5}"
              f"{'rng':>5}{'push':>7}{'onHit':>7}{'onBlk':>7}  purpose")
        for n in NORMALS:
            m = mv['moves'][n]
            print(f"   {n:<8}{m['verb']:<11}{m['startup']:>4}{m['active']:>4}{m['recovery']:>4}"
                  f"{m['damage']:>5}{m['range']:>5}{m['pushback']:>7}"
                  f"{m['onHit']:>+7}{m['onBlock']:>+7}  {m['purpose'][:38]}")
        print(f"   AI: {ai['personality']} · aggr {ai['aggression']} · zone {ai['zoning']} · "
              f"dash {ai['dashLove']} · punish {ai['whiffPunish']} · react {ai['reactionFrames']}f")
        print(f"       {' -> '.join(ai['behaviours'])}")

    if not gates(built, lang_all):
        print("\nQUALITY GATE FAILURE — nothing written.")
        sys.exit(1)

    print(f"\nSOURCE READS ({len(set(io.reads))} files, all authored):")
    for r in sorted(set(io.reads)): print(f"   {r}")

    if check:
        print("\ncheck only — nothing written.")
        return
    for cid, (mv, ch, ai, g, l, a, alt) in built.items():
        os.makedirs(f'{OUT}/{cid}', exist_ok=True)
        json.dump(mv, open(f'{OUT}/{cid}/moves.json', 'w'), indent=2)
        json.dump(ch, open(f'{OUT}/{cid}/character.json', 'w'), indent=2)
        json.dump(ai, open(f'{OUT}/{cid}/ai.json', 'w'), indent=2)
        for sid, (smv, sai) in alt.items():
            os.makedirs(f'{OUT}/{cid}_{sid}', exist_ok=True)
            json.dump(smv, open(f'{OUT}/{cid}_{sid}/moves.json', 'w'), indent=2)
            json.dump(sai, open(f'{OUT}/{cid}_{sid}/ai.json', 'w'), indent=2)
    print("\nwritten: moves.json · character.json · ai.json  x" + str(len(built)))

if __name__ == '__main__':
    main()
