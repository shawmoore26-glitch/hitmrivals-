#!/usr/bin/env python3
"""
rig_compiler.py — DNA-DERIVED SKELETON COMPILER

  "The skeleton is derived from the fighter. Never force the fighter into the skeleton."

No fixed bone target. Each fighter's skeleton is the union of:

  CORE          the bones any humanoid needs to throw a punch (kinetic chain)
  DESIGN        what this specific character physically has — coat, tail, dreads,
                lantern, wires. Read from their design manifest.
  DNA GATING    a design element only earns a bone if the fighter's DNA says it
                should move. A rigid fighter's coat is painted on; an elastic
                fighter's coat is a bone. elasticity + chaos decide.

Reads ONLY authored source. Writes rig.json (generated).
"""
import json, os, sys, copy

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC  = os.path.join(ROOT, 'data', 'identity')
OUT  = os.path.join(ROOT, 'data', 'characters')

# ── CORE SKELETON — the kinetic chain (Phase 5) ──────────────────────────────
# foot -> leg -> hip -> spine -> shoulder -> arm -> hand -> impact
# Every bone here exists because power travels through it. None are optional.
CORE = [
  ('root',      None,        'origin'),
  ('hip',       'root',      'kinetic chain: where ground force enters the body'),
  ('torso',     'hip',       'kinetic chain: spine compression and counter-rotation'),
  ('neck',      'torso',     'lets the head lag behind the chest'),
  ('head',      'neck',      'kinetic chain terminus, and the readable one'),
  ('shoulderFar','torso',    'shoulder compression before the arm moves'),
  ('shoulderNear','torso',   'shoulder compression before the arm moves'),
  ('armFarU',   'shoulderFar','kinetic chain'),
  ('armFarL',   'armFarU',   'kinetic chain'),
  ('handFar',   'armFarL',   'wrist — a punch may not originate here, but it must finish here'),
  ('armNearU',  'shoulderNear','kinetic chain'),
  ('armNearL',  'armNearU',  'kinetic chain'),
  ('handNear',  'armNearL',  'wrist'),
  ('legFarU',   'hip',       'kinetic chain'),
  ('legFarL',   'legFarU',   'kinetic chain'),
  ('footFar',   'legFarL',   'foot roll — power begins at the ground'),
  ('legNearU',  'hip',       'kinetic chain'),
  ('legNearL',  'legNearU',  'kinetic chain'),
  ('footNear',  'legNearL',  'foot roll — power begins at the ground'),
]

def dna_allows(dna, elem):
    """A design element earns a bone only if the DNA says it moves.
       score = how much this body throws things around."""
    motion = (dna.get('elasticity', 50) * 0.45
            + dna.get('chaos', 50)      * 0.30
            + dna.get('speed', 50)      * 0.25)
    return motion >= elem.get('dnaThreshold', 0)

def compile_rig(cid):
    dna    = json.load(open(f'{SRC}/{cid}/character_dna.json'))['dna']
    design = json.load(open(f'{SRC}/{cid}/design.json'))
    genome = json.load(open(f'{SRC}/{cid}/combat_genome.json'))

    bones, parts, log = [], {}, []
    for name, parent, why in CORE:
        b = {'name': name, 'parent': parent, '_why': why}
        if name in design['core_parts']:
            p = design['core_parts'][name]
            parts[name] = {'rect': p['rect'], 'pivot': p['pivot']}
            b['len'] = p.get('len', 0.1)
        bones.append(b)
    log.append(f"core: {len(CORE)} bones (kinetic chain)")

    # ── DESIGN BONES — this character's own physical features ────────────────
    granted, denied = [], []
    for name, e in design.get('features', {}).items():
        if not dna_allows(dna, e):
            denied.append((name, e.get('dnaThreshold')))
            continue
        b = {'name': name, 'parent': e['parent'], '_why': e['why']}
        # ── SECONDARY MOTION (Phase 4) — procedural, not hand-keyed ──────────
        # stiffness: how fast it catches up.  damping: how long it keeps moving.
        # Both derive from DNA: a heavy fighter's coat is slow and settles;
        # a light chaotic fighter's coat never quite stops.
        w = dna.get('weight', 50) / 100.0
        el = dna.get('elasticity', 50) / 100.0
        b['follow'] = {
            'stiffness': round(0.10 + (1 - el) * 0.30, 3),
            'damping':   round(0.55 + w * 0.30, 3),
            'lagBeats':  e.get('lagBeats', 1.0),
            'maxAngle':  e.get('maxAngle', 34),
            'gravity':   e.get('gravity', 0.0),
        }
        bones.append(b)
        parts[name] = {'rect': e['rect'], 'pivot': e['pivot']}
        granted.append(name)
    log.append(f"design: {len(granted)} granted {granted}")
    if denied:
        log.append(f"design: {len(denied)} denied by DNA {denied}")

    draw = design['drawOrder']
    missing_in_draw = [b['name'] for b in bones if b['name'] in parts and b['name'] not in draw]
    orphan_draw     = [d for d in draw if d not in parts]

    rig = {
        '_generated': 'rig_compiler.py — derived from character_dna + design + combat_genome',
        '_bone_count': len(bones),
        '_derivation': log,
        'parts': parts,
        'bones': bones,
        'drawOrder': draw,
        'handBone': design.get('handBone', 'handNear'),
        'handPoint': design.get('handPoint', [0.5, 0.5]),
    }
    if 'synthLegs' in design: rig['synthLegs'] = design['synthLegs']
    return rig, log, missing_in_draw, orphan_draw

def main():
    check = '--check' in sys.argv
    roster = json.load(open(f'{ROOT}/data/system/game.json'))['roster']
    print("rig_compiler — skeleton derived from DNA, not from a target count\n")
    ok = True
    for cid in roster:
        if not os.path.exists(f'{SRC}/{cid}/design.json'):
            print(f"  SKIP {cid} — no design.json (authored source missing)"); continue
        rig, log, miss, orph = compile_rig(cid)
        dna = json.load(open(f'{SRC}/{cid}/character_dna.json'))['dna']
        motion = dna.get('elasticity',50)*0.45 + dna.get('chaos',50)*0.30 + dna.get('speed',50)*0.25
        print(f"── {cid.upper()}   {rig['_bone_count']} bones · {len(rig['parts'])} parts"
              f"   motion score {motion:.0f}")
        for l in log: print(f"     {l}")
        sec = [b for b in rig['bones'] if 'follow' in b]
        if sec:
            f = sec[0]['follow']
            print(f"     secondary motion: stiffness {f['stiffness']} damping {f['damping']} on {len(sec)} bones")
        if miss: print(f"     WARN parts missing from drawOrder: {miss}"); ok = False
        if orph: print(f"     WARN drawOrder entries with no part: {orph}"); ok = False
        if not check:
            json.dump(rig, open(f'{OUT}/{cid}/rig.json', 'w'), indent=2)
        print()
    print("check only — nothing written." if check else "written.")
    sys.exit(0 if ok else 1)

if __name__ == '__main__':
    main()
